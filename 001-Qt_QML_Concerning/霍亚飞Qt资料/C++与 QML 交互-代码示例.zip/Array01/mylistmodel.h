#ifndef MYLISTMODEL_H
#define MYLISTMODEL_H

#include <QObject>
#include <QAbstractListModel>

class MyListModel : public QAbstractListModel
{
    Q_OBJECT
public:

    /*列名*/
    enum Roles{
        NameRole = Qt::UserRole + 1,
        AgeRole
    };

    explicit MyListModel(QObject *parent = 0);


    // 记录条数
    int rowCount(const QModelIndex &parent) const;

    // 某条记录的属性（列）值
    QVariant data(const QModelIndex &index, int role) const;

    // 记录的属性集（列名集合）
    QHash<int, QByteArray> roleNames() const;

signals:

public slots:

};

#endif // MYLISTMODEL_H
