#include <QApplication>
#include <QQmlApplicationEngine>
#include <QtQml>

#include "foo.h"
#include "mylistmodel.h"

static QObject *example_qobject_singletontype_provider(QQmlEngine *engine, QJSEngine *scriptEngine)
{
    Q_UNUSED(engine)
    Q_UNUSED(scriptEngine)

    Foo *example = new Foo();
    return example;
}

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    qmlRegisterSingletonType<Foo>("qyvlik",
                                  1, 0,
                                  "Foo",
                                  example_qobject_singletontype_provider);


    qmlRegisterType<MyListModel>("qyvlik", 1,0,"MyListModel");

    QQmlApplicationEngine engine;

    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    engine.rootContext()->setContextProperty("MyFoo", new Foo());

    return app.exec();
}

