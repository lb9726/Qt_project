#include "mylistmodel.h"

MyListModel::MyListModel(QObject *parent)
    : QAbstractListModel(parent)
{
// 例如这里可以连接数据库
}

int MyListModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent)
    return 10;
}

QVariant MyListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() < 0)
        return QVariant();


    // 这里直接查询数据库。
    switch (role)
    {
    case NameRole:
        return "Name Role";
    case AgeRole:
        return "Age Role";
    default:
        break;
    }
    return QVariant();
}

QHash<int, QByteArray> MyListModel::roleNames() const
{
    QHash<int, QByteArray> roleNames;
    roleNames.insert(NameRole, "NameRole");
    roleNames.insert(AgeRole, "AgeRole");
    return roleNames;
}

