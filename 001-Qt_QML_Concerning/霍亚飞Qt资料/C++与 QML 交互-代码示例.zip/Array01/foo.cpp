#include "foo.h"

Foo::Foo(QObject *parent) :
    QObject(parent)
{
    qRegisterMetaType<ArrayData>("ArrayData");
    qRegisterMetaType<QList<ArrayData> >("QList<ArrayData>");
}

