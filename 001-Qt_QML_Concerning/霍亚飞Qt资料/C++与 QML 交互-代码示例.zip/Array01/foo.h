#ifndef FOO_H
#define FOO_H

#include <QObject>
#include <QVariant>
/*
 * 如果数据是Json结构的直接使用
 * QJsonArray
 * QJsonObject
 *
*/

/*
 * 定义一个结构体
*/
struct ArrayData
{
    Q_GADGET
    Q_PROPERTY(double data READ data WRITE setData)

public:
    ArrayData(){}
    ArrayData (double v):
        m_data(v)
    {

    }

    double data()const {
        return m_data;
    }

    void setData(const double& value) {
        m_data = value;
    }

private:
    double m_data;
};

Q_DECLARE_METATYPE(ArrayData)

Q_DECLARE_METATYPE(QList<ArrayData>)

/*
 * @QList<ArrayData>
*/

class Foo : public QObject
{
    Q_OBJECT
public:
    explicit Foo(QObject *parent = 0);

    Q_INVOKABLE ArrayData getArrayData() const {

        return ArrayData(10);
    }

/*
 * 建议将自定义结构体数组进行转换，转换成 QList<QVariant>
 * 然后就可以在 QML 中直接使用。如果用户传参的话，就可以不转换成 QList<ArrayData>
 * 如果序列长度很长的话，就使用 QAbstractListModel
*/

    Q_INVOKABLE QList<ArrayData> getArray() const {
        QList<ArrayData> l;
        l << ArrayData(qrand()) << ArrayData(qrand()) << ArrayData(qrand());
        return l;
    }

    Q_INVOKABLE QList<QVariant> getArray2() const {
        QList<QVariant> l;
        QVariant v1;
        v1.setValue(ArrayData(qrand()));
        QVariant v2;
        v2.setValue(ArrayData(qrand()));
        QVariant v3;
        v3.setValue(ArrayData(qrand()));

        l << v1 << v2 << v3;
        return l;
    }

signals:

public slots:
};

/*
 * 注册新类型有三类
 * QObject
 * QQuickItem (绘制图元) Image
 * QAbstractItemModel（数据模型）
*/

#endif // FOO_H
