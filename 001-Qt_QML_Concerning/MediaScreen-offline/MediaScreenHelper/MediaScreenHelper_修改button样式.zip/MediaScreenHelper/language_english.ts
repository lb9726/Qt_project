<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>Area1</name>
    <message>
        <location filename="Area1.qml" line="22"/>
        <location filename="Area1.qml" line="259"/>
        <source>亮度&amp;音量</source>
        <translation>Brightness &amp; volume</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="39"/>
        <location filename="Area1.qml" line="260"/>
        <source>亮度</source>
        <translation>Brightness</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="44"/>
        <location filename="Area1.qml" line="261"/>
        <source>音量</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="149"/>
        <location filename="Area1.qml" line="262"/>
        <source>滚动文字</source>
        <translation>Scrolling text</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="156"/>
        <location filename="Area1.qml" line="164"/>
        <location filename="Area1.qml" line="269"/>
        <source>隐藏滚动文字</source>
        <translation>Hide scroll text</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="160"/>
        <location filename="Area1.qml" line="265"/>
        <source>显示滚动文字</source>
        <translation>Show scrolling text</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="183"/>
        <location filename="Area1.qml" line="280"/>
        <source>请输入字幕文字</source>
        <translation>Please enter a caption text</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="199"/>
        <location filename="Area1.qml" line="281"/>
        <source>标题</source>
        <translation>Title</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="206"/>
        <location filename="Area1.qml" line="214"/>
        <location filename="Area1.qml" line="277"/>
        <source>隐藏标题</source>
        <translation>Hide title</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="210"/>
        <location filename="Area1.qml" line="273"/>
        <source>显示标题</source>
        <translation>Show title</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="234"/>
        <location filename="Area1.qml" line="282"/>
        <location filename="Area1.qml" line="296"/>
        <source>请输入标题文字</source>
        <translation>Please enter a title text</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="292"/>
        <source>请输入滚动字幕文字</source>
        <translation>Please enter a scrolling caption text</translation>
    </message>
</context>
<context>
    <name>Area2</name>
    <message>
        <location filename="Area2.qml" line="37"/>
        <location filename="Area2.qml" line="300"/>
        <source>显示时间和日期</source>
        <translation>Show time and date</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="56"/>
        <location filename="Area2.qml" line="306"/>
        <source>时间格式</source>
        <translation>Time format</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="275"/>
        <location filename="Area2.qml" line="283"/>
        <source>音频关</source>
        <translation>Audio Off</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="279"/>
        <source>音频开</source>
        <translation>Audio On</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="307"/>
        <source>12上午下午  </source>
        <translation>12 AM/PM</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="97"/>
        <location filename="Area2.qml" line="308"/>
        <source>24小时</source>
        <translation>24 hours</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="25"/>
        <location filename="Area2.qml" line="42"/>
        <location filename="Area2.qml" line="304"/>
        <source>隐藏时间和日期</source>
        <translation>Hide time and date</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="61"/>
        <location filename="Area2.qml" line="309"/>
        <source>日期格式</source>
        <translation>Date format</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="71"/>
        <source>12上午下午</source>
        <translation>12AM/PM</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="82"/>
        <location filename="Area2.qml" line="310"/>
        <source>yyyy:mm:dd</source>
        <translation>yyyy:mm:dd</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="101"/>
        <location filename="Area2.qml" line="311"/>
        <source>mm:dd:yyyy</source>
        <translation>mm:dd:yyyy</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="111"/>
        <location filename="Area2.qml" line="312"/>
        <source>屏保</source>
        <translation>Screensaver</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="126"/>
        <location filename="Area2.qml" line="313"/>
        <source>一阶段周期(S)</source>
        <translation>One stage cycle(S)</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="145"/>
        <location filename="Area2.qml" line="221"/>
        <location filename="Area2.qml" line="314"/>
        <location filename="Area2.qml" line="316"/>
        <source>亮度</source>
        <translation>Brightness</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="202"/>
        <location filename="Area2.qml" line="315"/>
        <source>二阶段周期(S)</source>
        <translation>Two stage cycle(S)</translation>
    </message>
</context>
<context>
    <name>Area3</name>
    <message>
        <location filename="Area3.qml" line="24"/>
        <location filename="Area3.qml" line="501"/>
        <source>多媒体更新</source>
        <translation>Multimedia update</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="45"/>
        <location filename="Area3.qml" line="502"/>
        <source>正常显示</source>
        <translation>Normal display</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="57"/>
        <location filename="Area3.qml" line="503"/>
        <source>全屏显示</source>
        <translation>Fullscreen display</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="83"/>
        <location filename="Area3.qml" line="504"/>
        <source>视频</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="101"/>
        <source>音频</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="119"/>
        <location filename="Area3.qml" line="505"/>
        <source>图片</source>
        <translation>Picture</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="164"/>
        <location filename="Area3.qml" line="506"/>
        <source>选择视频</source>
        <translation>Select video</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="215"/>
        <source>选择音频</source>
        <translation>Select Audio</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="249"/>
        <location filename="Area3.qml" line="507"/>
        <source>选择图片</source>
        <translation>Select Picture</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="291"/>
        <location filename="Area3.qml" line="513"/>
        <source>间隔</source>
        <translation>interval</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="356"/>
        <location filename="Area3.qml" line="508"/>
        <source>添加</source>
        <translation>Add</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="362"/>
        <location filename="Area3.qml" line="509"/>
        <source>删除</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="367"/>
        <location filename="Area3.qml" line="510"/>
        <source>清空</source>
        <translation>Clear</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="420"/>
        <location filename="Area3.qml" line="511"/>
        <source>请选择一个视频文件</source>
        <translation>Please select pictures</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="431"/>
        <source>请选择一个音频文件</source>
        <translation>Please select audio</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="457"/>
        <location filename="Area3.qml" line="512"/>
        <source>请选取图片</source>
        <translation>Please select pictures</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="480"/>
        <source>请选择一个视频</source>
        <translation>Please select a video</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="486"/>
        <source>请选择一个音频</source>
        <translation>Please select audio</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="492"/>
        <source>请选择图片</source>
        <translation>Please select pictures</translation>
    </message>
</context>
<context>
    <name>Area4</name>
    <message>
        <location filename="Area4.qml" line="18"/>
        <location filename="Area4.qml" line="200"/>
        <source>语言切换</source>
        <translation>Language switching</translation>
    </message>
    <message>
        <location filename="Area4.qml" line="35"/>
        <location filename="Area4.qml" line="201"/>
        <source>中文</source>
        <translation>Chinese</translation>
    </message>
    <message>
        <location filename="Area4.qml" line="58"/>
        <location filename="Area4.qml" line="202"/>
        <source>繁体</source>
        <translation>Traditional</translation>
    </message>
    <message>
        <location filename="Area4.qml" line="82"/>
        <location filename="Area4.qml" line="203"/>
        <source>英语</source>
        <translation>English</translation>
    </message>
    <message>
        <location filename="Area4.qml" line="103"/>
        <location filename="Area4.qml" line="204"/>
        <source>俄语</source>
        <translation>Russian</translation>
    </message>
</context>
<context>
    <name>Area5</name>
    <message>
        <location filename="Area5.qml" line="14"/>
        <location filename="Area5.qml" line="264"/>
        <source>升级盘制作</source>
        <translation>Upgrade disk production</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="33"/>
        <location filename="Area5.qml" line="265"/>
        <source>重置为默认配置</source>
        <translation>Reset default configuration</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="63"/>
        <source>界面预览</source>
        <translation>Screen Preview</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="81"/>
        <location filename="Area5.qml" line="266"/>
        <source>制作升级盘</source>
        <translation>Make update disk</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="94"/>
        <location filename="Area5.qml" line="267"/>
        <source>制作</source>
        <translation>Making</translation>
    </message>
    <message>
        <source>正在格式化U盘...</source>
        <translation type="vanished">Formatting U disk.....</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="268"/>
        <source>拷贝文件...</source>
        <translation>Copy file...</translation>
    </message>
    <message>
        <source>正在生成配置参数</source>
        <translation type="vanished">Generating configuration parameters...</translation>
    </message>
    <message>
        <source>升级盘制作成功</source>
        <translation type="vanished">Upgrade disk production success</translation>
    </message>
</context>
<context>
    <name>Horizontal_ImageOrVideo</name>
    <message>
        <location filename="Horizontal_ImageOrVideo.qml" line="39"/>
        <source>界面预览</source>
        <translation>Screen Preview</translation>
    </message>
    <message>
        <location filename="Horizontal_ImageOrVideo.qml" line="65"/>
        <source>横屏显示</source>
        <translation>Horizontal Show</translation>
    </message>
    <message>
        <location filename="Horizontal_ImageOrVideo.qml" line="86"/>
        <source>竖屏显示</source>
        <translation>Vertical Show</translation>
    </message>
    <message>
        <location filename="russian/Horizontal_ImageOrVideo.qml" line="39"/>
        <source>интерфейс просмотр</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Horizontal_ImageOrVideo.qml" line="65"/>
        <source>кросс экраном</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Horizontal_ImageOrVideo.qml" line="86"/>
        <source>вертикальный экран</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MakeDisk</name>
    <message>
        <source>重置为默认配置</source>
        <translation type="obsolete">Reset default configuration</translation>
    </message>
    <message>
        <source>制作升级盘</source>
        <translation type="obsolete">Make upgrade disk</translation>
    </message>
    <message>
        <source>制作</source>
        <translation type="obsolete">Making</translation>
    </message>
    <message>
        <source>正在格式化U盘...</source>
        <translation type="obsolete">Formatting U disk.....</translation>
    </message>
    <message>
        <source>拷贝文件...</source>
        <translation type="obsolete">Copy file...</translation>
    </message>
    <message>
        <source>正在生成配置参数</source>
        <translation type="obsolete">Generating configuration parameters...</translation>
    </message>
    <message>
        <source>升级盘制作成功</source>
        <translation type="obsolete">Upgrade disk production success</translation>
    </message>
</context>
<context>
    <name>ModifyCheckBox</name>
    <message>
        <source>重置为默认配置</source>
        <translation type="obsolete">Reset default configuration</translation>
    </message>
</context>
<context>
    <name>MultiMedia</name>
    <message>
        <source>视频</source>
        <translation type="obsolete">Video</translation>
    </message>
    <message>
        <source>图片</source>
        <translation type="obsolete">Picture</translation>
    </message>
    <message>
        <source>正常显示</source>
        <translation type="obsolete">Normal display</translation>
    </message>
    <message>
        <source>全屏显示</source>
        <translation type="obsolete">Fullscreen display</translation>
    </message>
    <message>
        <source>选择视频</source>
        <translation type="obsolete">Select video</translation>
    </message>
    <message>
        <source>选择图片</source>
        <translation type="obsolete">Select Picture</translation>
    </message>
    <message>
        <source>添加</source>
        <translation type="obsolete">Add</translation>
    </message>
    <message>
        <source>删除</source>
        <translation type="obsolete">Delete</translation>
    </message>
    <message>
        <source>清空</source>
        <translation type="obsolete">Clear</translation>
    </message>
    <message>
        <source>请选择一个视频文件</source>
        <translation type="obsolete">Please select pictures</translation>
    </message>
    <message>
        <source>请选取图片</source>
        <translation type="obsolete">Please select pictures</translation>
    </message>
</context>
<context>
    <name>Parameter</name>
    <message>
        <source>亮度&amp;音量</source>
        <translation type="obsolete">Brightness &amp; volume</translation>
    </message>
    <message>
        <source>滚动文字</source>
        <translation type="obsolete">Scrolling text</translation>
    </message>
    <message>
        <source>标题</source>
        <translation type="obsolete">Title</translation>
    </message>
    <message>
        <source>屏保</source>
        <translation type="obsolete">Screensaver</translation>
    </message>
    <message>
        <source>亮度</source>
        <translation type="obsolete">Brightness</translation>
    </message>
    <message>
        <source>音量</source>
        <translation type="obsolete">Volume</translation>
    </message>
    <message>
        <source>请输入字幕文字</source>
        <translation type="obsolete">Please enter a caption text</translation>
    </message>
    <message>
        <source>时间格式</source>
        <translation type="obsolete">Time format</translation>
    </message>
    <message>
        <source>日期格式</source>
        <translation type="obsolete">Date format</translation>
    </message>
    <message>
        <source>显示标题</source>
        <translation type="obsolete">Show title</translation>
    </message>
    <message>
        <source>隐藏标题</source>
        <translation type="obsolete">Hide title</translation>
    </message>
    <message>
        <source>请输入标题文字</source>
        <translation type="obsolete">Please enter a title text</translation>
    </message>
</context>
<context>
    <name>RussianArea1</name>
    <message>
        <location filename="russian/RussianArea1.qml" line="23"/>
        <source>Яркость &amp; Громкость</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="41"/>
        <source>Яркость</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="47"/>
        <source>Громкость</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="153"/>
        <location filename="russian/RussianArea1.qml" line="165"/>
        <source>Прокрутка текста</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="161"/>
        <location filename="russian/RussianArea1.qml" line="169"/>
        <source>Скрытие прокрутки текста</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="188"/>
        <source>Введите субтитра</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="205"/>
        <source>Заголовок</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="212"/>
        <location filename="russian/RussianArea1.qml" line="221"/>
        <source>Скрытие заголовка</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="217"/>
        <source>Индикация заголовка</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="241"/>
        <location filename="russian/RussianArea1.qml" line="270"/>
        <source>Введите заголовок</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="265"/>
        <source>Введите прокрутку субтитра</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RussianArea2</name>
    <message>
        <location filename="russian/RussianArea2.qml" line="26"/>
        <location filename="russian/RussianArea2.qml" line="42"/>
        <source>Скрыть времни и даты</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="38"/>
        <source>Индикация времни и даты</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="57"/>
        <source>Формат времени</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="63"/>
        <source>Формат даты</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="74"/>
        <source>12 Часов</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="85"/>
        <source>yyyy:mm:dd</source>
        <translation type="unfinished">yyyy:mm:dd</translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="100"/>
        <source>24 Часов</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="104"/>
        <source>mm:dd:yyyy</source>
        <translation type="unfinished">mm:dd:yyyy</translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="115"/>
        <source>Охранение экрана</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="131"/>
        <source>Цикл первого этапа</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="151"/>
        <location filename="russian/RussianArea2.qml" line="229"/>
        <source>Яркость</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="209"/>
        <source>Цикл второго этапа</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="283"/>
        <location filename="russian/RussianArea2.qml" line="291"/>
        <source>аудио гуань</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="287"/>
        <source>аудио открыть</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RussianArea3</name>
    <message>
        <location filename="russian/RussianArea3.qml" line="25"/>
        <source>Обновление мультимедиа</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="47"/>
        <source>Нормальная индикация</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="61"/>
        <source>Полноэкранная индикация</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="88"/>
        <source>Видео</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="107"/>
        <source>аудио</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="125"/>
        <source>Картина</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="171"/>
        <source>Выбор видео</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="222"/>
        <location filename="russian/RussianArea3.qml" line="448"/>
        <location filename="russian/RussianArea3.qml" line="499"/>
        <source>выбрать аудио</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="257"/>
        <source>Выбор картины</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="299"/>
        <source>интервал</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="371"/>
        <source>Добавить</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="377"/>
        <source>Удалить</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="383"/>
        <source>Очистить</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="436"/>
        <location filename="russian/RussianArea3.qml" line="492"/>
        <source>Выберите видео</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="475"/>
        <location filename="russian/RussianArea3.qml" line="505"/>
        <source>Выберите картину</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="514"/>
        <source>多媒体更新</source>
        <translation type="unfinished">Multimedia update</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="515"/>
        <source>正常显示</source>
        <translation type="unfinished">Normal display</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="516"/>
        <source>全屏显示</source>
        <translation type="unfinished">Fullscreen display</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="517"/>
        <source>视频</source>
        <translation type="unfinished">Video</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="518"/>
        <source>图片</source>
        <translation type="unfinished">Picture</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="519"/>
        <source>选择视频</source>
        <translation type="unfinished">Select video</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="520"/>
        <source>选择图片</source>
        <translation type="unfinished">Select Picture</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="521"/>
        <source>添加</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="522"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="523"/>
        <source>清空</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="524"/>
        <source>请选择一个视频文件</source>
        <translation type="unfinished">Please select pictures</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="525"/>
        <source>请选取图片</source>
        <translation type="unfinished">Please select pictures</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="526"/>
        <source>间隔</source>
        <translation type="unfinished">interval</translation>
    </message>
</context>
<context>
    <name>RussianArea4</name>
    <message>
        <location filename="russian/RussianArea4.qml" line="19"/>
        <source>Переключатель языка</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="37"/>
        <source>Китайский язык</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="58"/>
        <source>традиционный</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="81"/>
        <source>Английский язык</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="101"/>
        <source>Русский язык</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RussianArea5</name>
    <message>
        <location filename="russian/RussianArea5.qml" line="15"/>
        <source>Поделка обновления диска </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea5.qml" line="35"/>
        <source>Вновь установления настройки по умолчанию</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea5.qml" line="65"/>
        <source>интерфейс просмотр</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea5.qml" line="84"/>
        <source>Поделка обновления диска</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea5.qml" line="98"/>
        <source>Поделка</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RussianMain</name>
    <message>
        <location filename="russian/RussianMain.qml" line="34"/>
        <source>MediaScreenHelper</source>
        <translation type="unfinished">MediaScreenHelper</translation>
    </message>
    <message>
        <source>  V1.7.0</source>
        <translation type="obsolete">  V1.7.0</translation>
    </message>
    <message>
        <source>  V1.2.0</source>
        <translation type="obsolete">  V1.2.0</translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="34"/>
        <source>  V2.0.0</source>
        <translation type="unfinished">  V2.0.0</translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="48"/>
        <source>Настройка параметров</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="179"/>
        <source>Включите этот параметр переключателя, на экране будет восстановлена настройка параметров по умолчанию. Мультимедиа, прокрутка субтитров, заголовок, времени и даты, параметры конфигурации системы буду
т восстановлены по умолчанию.</source>
        <oldsource>Включите этот параметр переключателя, на экране будет восстановлена настройка параметров по умолчанию. Мультимедиа, прокрутка субтитров, заголовок, времени и даты, параметры конфигурации системы буду
т восстановлены по умолчанию.</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="192"/>
        <location filename="russian/RussianMain.qml" line="236"/>
        <location filename="russian/RussianMain.qml" line="388"/>
        <source>Уточнение</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="200"/>
        <location filename="russian/RussianMain.qml" line="398"/>
        <source>Отмена</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="294"/>
        <source>Нажмите, чтобы закончить поделку</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="316"/>
        <source>Копирование файла...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="376"/>
        <source>Нажмите, чтобы подтвердить.Размещение страницы будет перезагружен.Необходимо перезагрузить USB!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="424"/>
        <source>Создание параметров конфигурации</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="427"/>
        <source>Успех в поделке обновлении диска</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="442"/>
        <source>Форматирование диска...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Vertical_ImageOrVideo</name>
    <message>
        <location filename="Vertical_ImageOrVideo.qml" line="38"/>
        <source>界面预览</source>
        <translation>Screen Preview</translation>
    </message>
    <message>
        <location filename="Vertical_ImageOrVideo.qml" line="62"/>
        <source>横屏显示</source>
        <translation>Horizontal Show</translation>
    </message>
    <message>
        <location filename="Vertical_ImageOrVideo.qml" line="89"/>
        <source>竖屏显示</source>
        <translation>Vertical Show</translation>
    </message>
    <message>
        <location filename="russian/Vertical_ImageOrVideo.qml" line="38"/>
        <source>интерфейс просмотр</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Vertical_ImageOrVideo.qml" line="62"/>
        <source>кросс экраном</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Vertical_ImageOrVideo.qml" line="89"/>
        <source>вертикальный экран</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="33"/>
        <source>MediaScreenHelper</source>
        <translation>MediaScreenHelper</translation>
    </message>
    <message>
        <source>  V1.6.0</source>
        <translation type="vanished">  V1.6.0</translation>
    </message>
    <message>
        <source>  V1.7.0</source>
        <translation type="vanished">  V1.7.0</translation>
    </message>
    <message>
        <source>  V1.2.0</source>
        <translation type="vanished">  V1.2.0</translation>
    </message>
    <message>
        <location filename="main.qml" line="33"/>
        <source>  V2.0.0</source>
        <translation>  V2.0.0</translation>
    </message>
    <message>
        <location filename="main.qml" line="46"/>
        <location filename="main.qml" line="426"/>
        <source>参数设置</source>
        <translation>Parameter setting</translation>
    </message>
    <message>
        <location filename="main.qml" line="180"/>
        <location filename="main.qml" line="427"/>
        <source>打开此开关选项,屏幕将恢复默认的参数配置.多媒体,滚动字幕,标题,时间和日期,系统配置参数都将恢复为默认.</source>
        <translation>Open this switch option, the screen will restore the default parameter configuration. Multimedia, scrolling subtitles, title, time and date, system configuration parameters will be restored to default</translation>
    </message>
    <message>
        <location filename="main.qml" line="191"/>
        <location filename="main.qml" line="389"/>
        <location filename="main.qml" line="428"/>
        <location filename="main.qml" line="434"/>
        <source>确认</source>
        <translation>Confirm</translation>
    </message>
    <message>
        <location filename="main.qml" line="198"/>
        <location filename="main.qml" line="399"/>
        <location filename="main.qml" line="429"/>
        <location filename="main.qml" line="435"/>
        <source>取消</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="main.qml" line="233"/>
        <location filename="main.qml" line="430"/>
        <source>确定</source>
        <translation>Confirm</translation>
    </message>
    <message>
        <location filename="main.qml" line="289"/>
        <location filename="main.qml" line="431"/>
        <source>点击以结束制作</source>
        <translation>Clicked and ended making</translation>
    </message>
    <message>
        <location filename="main.qml" line="311"/>
        <location filename="main.qml" line="432"/>
        <source>拷贝文件...</source>
        <translation>Copy file...</translation>
    </message>
    <message>
        <location filename="main.qml" line="378"/>
        <location filename="main.qml" line="433"/>
        <source>点击确认，将重新加载界面布局，Usb设备需要重新插拔!</source>
        <oldsource>点击确认，将重新加载界面布局，Usb设备需要重新插拔！.</oldsource>
        <translation>Click OK to reload the interface layout, and the Usb device needs to be reinserted!</translation>
    </message>
    <message>
        <location filename="main.qml" line="440"/>
        <source>正在生成配置参数</source>
        <translation>Generating configuration parameters...</translation>
    </message>
    <message>
        <location filename="main.qml" line="442"/>
        <source>升级盘制作成功</source>
        <translation>Upgrade disk production success</translation>
    </message>
    <message>
        <location filename="main.qml" line="456"/>
        <source>正在格式化U盘...</source>
        <translation>Formatting U disk.....</translation>
    </message>
</context>
</TS>
