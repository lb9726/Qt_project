#include "mediascreen.h"

MediaScreen::MediaScreen(QObject *parent) : QObject(parent)
  , index(-1)
{

}

void MediaScreen::changeUi()
{
    switch (index) {
    case 0: case 1: case 2:
        CTranslator::instance()->load(index);
        emit clearAudioParament(index);
        engine.load(QUrl(QLatin1String("qrc:/main.qml")));
        break;
    case 3:
//        qApp->exit(1);
        emit clearAudioParament(index);
        engine.load(QUrl(QLatin1String("qrc:///russian/RussianMain.qml")));
        break;
    default:
        break;
    }
}

void MediaScreen::setIndex(int i)
{
    qDebug()<<"i = "<< i;
    index = i;
    qDebug()<<"index = "<< index;
}

QVariant MediaScreen::getIndex()
{
    qDebug()<<__FUNCTION__<<"index = "<<index;
    return index;
}

void MediaScreen::getScrollTextLength()
{
    emit getScrollTextLengthSignal();
}

MediaScreen::~MediaScreen()
{
    delete nativeFilter;
    delete configureSerialer;
}

UsbEventFilter *MediaScreen::getPoint()
{
    if (NULL != nativeFilter)
        return nativeFilter;
    return NULL;
}

void MediaScreen::init()
{
    configureSerialer = new ConfigureHolder(&engine);
    nativeFilter = new UsbEventFilter();
    content = engine.rootContext();
    // 设置Qml的上下文属性，可以直接在qml中引用
    content->setContextProperty("UsbHelper", nativeFilter->usbHelper);
    content->setContextProperty("ConfigureSerialer", configureSerialer);
    content->setContextProperty("Ctranslator", CTranslator::instance());
    content->setContextProperty("MediaScreen", this);
    engine.load(QUrl(QLatin1String("qrc:/main.qml")));
}
