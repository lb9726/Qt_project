/****************************************************************************
** Meta object code from reading C++ file 'configureholder.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "F:/offline_new/MediaScreenHelper-CN/configureholder.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'configureholder.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ConfigureHolder_t {
    QByteArrayData data[51];
    char stringdata0[624];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ConfigureHolder_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ConfigureHolder_t qt_meta_stringdata_ConfigureHolder = {
    {
QT_MOC_LITERAL(0, 0, 15), // "ConfigureHolder"
QT_MOC_LITERAL(1, 16, 16), // "copyFileProgress"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 3), // "pro"
QT_MOC_LITERAL(4, 38, 9), // "createXml"
QT_MOC_LITERAL(5, 48, 3), // "dir"
QT_MOC_LITERAL(6, 52, 15), // "clearParameters"
QT_MOC_LITERAL(7, 68, 9), // "startJobs"
QT_MOC_LITERAL(8, 78, 9), // "orderFile"
QT_MOC_LITERAL(9, 88, 15), // "copyReourceFile"
QT_MOC_LITERAL(10, 104, 3), // "src"
QT_MOC_LITERAL(11, 108, 3), // "dst"
QT_MOC_LITERAL(12, 112, 13), // "copyFileMulti"
QT_MOC_LITERAL(13, 126, 11), // "GetFilePath"
QT_MOC_LITERAL(14, 138, 9), // "pFilePath"
QT_MOC_LITERAL(15, 148, 16), // "copyProgressMult"
QT_MOC_LITERAL(16, 165, 2), // "id"
QT_MOC_LITERAL(17, 168, 9), // "copyBytes"
QT_MOC_LITERAL(18, 178, 11), // "jobFinished"
QT_MOC_LITERAL(19, 190, 11), // "resetScreen"
QT_MOC_LITERAL(20, 202, 7), // "isReset"
QT_MOC_LITERAL(21, 210, 16), // "updateMultiMedia"
QT_MOC_LITERAL(22, 227, 21), // "isMediaContentEnabled"
QT_MOC_LITERAL(23, 249, 14), // "videoOrPicture"
QT_MOC_LITERAL(24, 264, 12), // "isfullscreen"
QT_MOC_LITERAL(25, 277, 5), // "paths"
QT_MOC_LITERAL(26, 283, 20), // "updateParameterBasic"
QT_MOC_LITERAL(27, 304, 19), // "bConfigureParameter"
QT_MOC_LITERAL(28, 324, 17), // "bBrightnessVolume"
QT_MOC_LITERAL(29, 342, 11), // "bScrollText"
QT_MOC_LITERAL(30, 354, 6), // "bTitle"
QT_MOC_LITERAL(31, 361, 9), // "bDateTime"
QT_MOC_LITERAL(32, 371, 8), // "bStandby"
QT_MOC_LITERAL(33, 380, 12), // "isScrollText"
QT_MOC_LITERAL(34, 393, 7), // "isTitle"
QT_MOC_LITERAL(35, 401, 10), // "isDateTime"
QT_MOC_LITERAL(36, 412, 22), // "updateBrightnessVolume"
QT_MOC_LITERAL(37, 435, 11), // "vBrightness"
QT_MOC_LITERAL(38, 447, 7), // "vVolume"
QT_MOC_LITERAL(39, 455, 16), // "updateScrollText"
QT_MOC_LITERAL(40, 472, 11), // "vScrollText"
QT_MOC_LITERAL(41, 484, 11), // "updateTitle"
QT_MOC_LITERAL(42, 496, 6), // "vTitle"
QT_MOC_LITERAL(43, 503, 14), // "updateDateTime"
QT_MOC_LITERAL(44, 518, 11), // "vTimeFormat"
QT_MOC_LITERAL(45, 530, 11), // "vDateFormat"
QT_MOC_LITERAL(46, 542, 13), // "updateStandby"
QT_MOC_LITERAL(47, 556, 15), // "vStage1Interval"
QT_MOC_LITERAL(48, 572, 17), // "vStage1Brightness"
QT_MOC_LITERAL(49, 590, 15), // "vStage2Interval"
QT_MOC_LITERAL(50, 606, 17) // "vStage2Brightness"

    },
    "ConfigureHolder\0copyFileProgress\0\0pro\0"
    "createXml\0dir\0clearParameters\0startJobs\0"
    "orderFile\0copyReourceFile\0src\0dst\0"
    "copyFileMulti\0GetFilePath\0pFilePath\0"
    "copyProgressMult\0id\0copyBytes\0jobFinished\0"
    "resetScreen\0isReset\0updateMultiMedia\0"
    "isMediaContentEnabled\0videoOrPicture\0"
    "isfullscreen\0paths\0updateParameterBasic\0"
    "bConfigureParameter\0bBrightnessVolume\0"
    "bScrollText\0bTitle\0bDateTime\0bStandby\0"
    "isScrollText\0isTitle\0isDateTime\0"
    "updateBrightnessVolume\0vBrightness\0"
    "vVolume\0updateScrollText\0vScrollText\0"
    "updateTitle\0vTitle\0updateDateTime\0"
    "vTimeFormat\0vDateFormat\0updateStandby\0"
    "vStage1Interval\0vStage1Brightness\0"
    "vStage2Interval\0vStage2Brightness"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ConfigureHolder[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  104,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    1,  107,    2, 0x0a /* Public */,
       6,    0,  110,    2, 0x0a /* Public */,
       7,    0,  111,    2, 0x0a /* Public */,
       8,    1,  112,    2, 0x0a /* Public */,
       9,    2,  115,    2, 0x0a /* Public */,
      12,    2,  120,    2, 0x0a /* Public */,
      13,    1,  125,    2, 0x0a /* Public */,
      15,    2,  128,    2, 0x0a /* Public */,
      18,    1,  133,    2, 0x0a /* Public */,
      19,    1,  136,    2, 0x0a /* Public */,
      21,    4,  139,    2, 0x0a /* Public */,
      26,    9,  148,    2, 0x0a /* Public */,
      36,    2,  167,    2, 0x0a /* Public */,
      39,    1,  172,    2, 0x0a /* Public */,
      41,    1,  175,    2, 0x0a /* Public */,
      43,    2,  178,    2, 0x0a /* Public */,
      46,    4,  183,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,

 // slots: parameters
    QMetaType::Bool, QMetaType::QString,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Bool, QMetaType::QString, QMetaType::QString,   10,   11,
    QMetaType::Bool, QMetaType::QString, QMetaType::QString,   10,   11,
    QMetaType::QString, QMetaType::QString,   14,
    QMetaType::Void, QMetaType::Int, QMetaType::LongLong,   16,   17,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Bool, QMetaType::Bool,   20,
    QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::QString,   22,   23,   24,   25,
    QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool,   27,   28,   29,   30,   31,   32,   33,   34,   35,
    QMetaType::Bool, QMetaType::Int, QMetaType::Int,   37,   38,
    QMetaType::Bool, QMetaType::QString,   40,
    QMetaType::Bool, QMetaType::QString,   42,
    QMetaType::Bool, QMetaType::QString, QMetaType::QString,   44,   45,
    QMetaType::Bool, QMetaType::UInt, QMetaType::UChar, QMetaType::UInt, QMetaType::UChar,   47,   48,   49,   50,

       0        // eod
};

void ConfigureHolder::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ConfigureHolder *_t = static_cast<ConfigureHolder *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->copyFileProgress((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: { bool _r = _t->createXml((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 2: _t->clearParameters(); break;
        case 3: _t->startJobs(); break;
        case 4: _t->orderFile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: { bool _r = _t->copyReourceFile((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 6: { bool _r = _t->copyFileMulti((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 7: { QString _r = _t->GetFilePath((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 8: _t->copyProgressMult((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< qint64(*)>(_a[2]))); break;
        case 9: _t->jobFinished((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: { bool _r = _t->resetScreen((*reinterpret_cast< bool(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 11: { bool _r = _t->updateMultiMedia((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 12: { bool _r = _t->updateParameterBasic((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< bool(*)>(_a[6])),(*reinterpret_cast< bool(*)>(_a[7])),(*reinterpret_cast< bool(*)>(_a[8])),(*reinterpret_cast< bool(*)>(_a[9])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 13: { bool _r = _t->updateBrightnessVolume((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 14: { bool _r = _t->updateScrollText((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 15: { bool _r = _t->updateTitle((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 16: { bool _r = _t->updateDateTime((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 17: { bool _r = _t->updateStandby((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< quint8(*)>(_a[2])),(*reinterpret_cast< quint32(*)>(_a[3])),(*reinterpret_cast< quint8(*)>(_a[4])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (ConfigureHolder::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::copyFileProgress)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject ConfigureHolder::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_ConfigureHolder.data,
      qt_meta_data_ConfigureHolder,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ConfigureHolder::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ConfigureHolder::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ConfigureHolder.stringdata0))
        return static_cast<void*>(const_cast< ConfigureHolder*>(this));
    return QObject::qt_metacast(_clname);
}

int ConfigureHolder::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
    return _id;
}

// SIGNAL 0
void ConfigureHolder::copyFileProgress(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
