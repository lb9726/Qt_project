#include <QGuiApplication>
#include <QMessageBox>
#include <QFont>
#include "usbeventfilter.h"
#if defined Q_OS_WIN32
#include <windows.h>
#include "mediascreen.h"

bool checkOnly()
{
    HANDLE m_hMutex  =  CreateMutex(NULL, FALSE,  L"MediascreenHelper_2017_06_04" );
    if  (GetLastError()  ==  ERROR_ALREADY_EXISTS)  {
        CloseHandle(m_hMutex);
        m_hMutex  =  NULL;
        return  false;
    }
    else{
        return true;
    }}
#endif

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QGuiApplication app(argc, argv);

//    if(!checkOnly()){
//        QMessageBox msgBox;
//        msgBox.setText("An instance already running, this will quit.");
//        msgBox.exec();
//        return 1;
//    }

    QFont font("KONE Information_v12");
    app.setFont(font);

    MediaScreen *mediascreen = new MediaScreen();
    mediascreen->init();
    app.installNativeEventFilter(mediascreen->getPoint());
    int ret = app.exec();
    delete mediascreen;
    return ret;
}
