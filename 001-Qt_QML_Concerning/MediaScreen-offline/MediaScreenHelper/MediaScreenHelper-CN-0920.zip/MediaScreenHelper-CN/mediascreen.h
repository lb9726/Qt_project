#ifndef MEDIASCREEN_H
#define MEDIASCREEN_H

#include <QObject>
#include "usbeventfilter.h"
#include "configureholder.h"
#include "ctranslator.h"
#include <QQmlContext>
#include <QQmlApplicationEngine>
#include "usbeventfilter.h"
#include <QVariant>

class MediaScreen : public QObject
{
    Q_OBJECT
public:
    explicit MediaScreen(QObject *parent = 0);
    void init();
    ~MediaScreen();
    UsbEventFilter* getPoint();

signals:

public slots:
    void changeUi();
    void setIndex(int i);
    QVariant getIndex();

private:
    int index;
    QQmlContext *content;
    QQmlApplicationEngine engine;
    UsbEventFilter *nativeFilter;
    ConfigureHolder *configureSerialer;
};

#endif // MEDIASCREEN_H
