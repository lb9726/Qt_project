#include "logicbase.h"

LogicBase::LogicBase(QObject *parent) :
    QObject(parent)
{
}


bool LogicBase::initDevice(LG_Type pPHType, QDomElement pElement)
{

}
