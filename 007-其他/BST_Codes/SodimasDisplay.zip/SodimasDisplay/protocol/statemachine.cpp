#include "statemachine.h"

StateMachine::StateMachine(QObject *parent) :
    QObject(parent)
{
}
