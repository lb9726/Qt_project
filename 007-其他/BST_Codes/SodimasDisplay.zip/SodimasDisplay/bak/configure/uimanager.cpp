#include "uimanager.h"

uiManager::uiManager(QObject *parent) :
    QObject(parent)
{
}
