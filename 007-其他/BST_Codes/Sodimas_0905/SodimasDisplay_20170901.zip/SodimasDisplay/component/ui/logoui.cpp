#include "logoui.h"

LogoUi::LogoUi(QObject *parent) :
    UiBase(parent)
{
}

LogoUi::LogoUi(ThemeParser *pthemeManager, QDomElement &pElement)
{

}
