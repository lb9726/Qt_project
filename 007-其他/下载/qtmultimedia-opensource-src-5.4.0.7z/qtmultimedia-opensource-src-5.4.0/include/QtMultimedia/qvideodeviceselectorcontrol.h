#include "../../src/multimedia/controls/qvideodeviceselectorcontrol.h"
