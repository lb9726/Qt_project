#include "../../src/multimedia/controls/qcamerafeedbackcontrol.h"
