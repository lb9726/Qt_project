#include "../../src/multimedia/controls/qmediaavailabilitycontrol.h"
