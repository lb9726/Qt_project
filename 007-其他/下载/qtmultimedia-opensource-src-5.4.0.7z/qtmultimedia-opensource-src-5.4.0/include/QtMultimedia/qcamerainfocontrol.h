#include "../../src/multimedia/controls/qcamerainfocontrol.h"
