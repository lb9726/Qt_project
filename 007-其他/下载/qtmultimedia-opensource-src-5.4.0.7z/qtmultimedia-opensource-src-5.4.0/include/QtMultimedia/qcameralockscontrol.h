#include "../../src/multimedia/controls/qcameralockscontrol.h"
