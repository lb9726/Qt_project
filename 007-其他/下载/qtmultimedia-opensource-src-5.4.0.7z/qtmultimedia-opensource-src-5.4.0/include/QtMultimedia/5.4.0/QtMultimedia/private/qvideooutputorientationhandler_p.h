#include "../../../../../src/multimedia/video/qvideooutputorientationhandler_p.h"
