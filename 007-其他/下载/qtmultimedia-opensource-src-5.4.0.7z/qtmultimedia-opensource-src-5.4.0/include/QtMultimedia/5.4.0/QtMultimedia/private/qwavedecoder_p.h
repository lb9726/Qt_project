#include "../../../../../src/multimedia/audio/qwavedecoder_p.h"
