#include "../../src/multimedia/controls/qmetadatareadercontrol.h"
