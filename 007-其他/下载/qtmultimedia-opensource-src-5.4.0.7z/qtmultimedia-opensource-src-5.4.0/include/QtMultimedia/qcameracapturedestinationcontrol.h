#include "../../src/multimedia/controls/qcameracapturedestinationcontrol.h"
