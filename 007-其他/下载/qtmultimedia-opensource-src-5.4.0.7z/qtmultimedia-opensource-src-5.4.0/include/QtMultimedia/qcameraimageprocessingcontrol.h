#include "../../src/multimedia/controls/qcameraimageprocessingcontrol.h"
