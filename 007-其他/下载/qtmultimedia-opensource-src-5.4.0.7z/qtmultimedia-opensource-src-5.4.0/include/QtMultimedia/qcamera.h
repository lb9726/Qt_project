#include "../../src/multimedia/camera/qcamera.h"
