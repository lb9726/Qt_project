#include "../../src/multimedia/controls/qmediaplayercontrol.h"
