#include "../../src/multimediawidgets/qvideowidgetcontrol.h"
