#include "../../src/multimediawidgets/qcameraviewfinder.h"
