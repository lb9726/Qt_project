#include "thread1.h"
#include <QDebug>
Thread1::Thread1(QObject *parent) :
    QThread(parent)
{
}

void Thread1::run()
{
    while(1)
    {
        qDebug()<<"this is thread 1";
        emit this->sendString("this is thread 1");
        sleep(1);
    }
}
