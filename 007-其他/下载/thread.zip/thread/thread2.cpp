#include "thread2.h"
#include <QDebug>
Thread2::Thread2(QObject *parent) :
    QThread(parent)
{
}
void Thread2::run()
{
    while(1)
    {
        sleep(1);
        qDebug()<<"this is thread 2";
        emit this->sendString("this is thread 2");
    }
}
