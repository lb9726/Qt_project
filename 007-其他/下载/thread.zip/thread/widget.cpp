#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    thread1 = new Thread1(this);
    thread2 = new Thread2(this);

    connect(thread1,SIGNAL(sendString(QString)),this,SLOT(recvString(QString)));
    connect(thread2,SIGNAL(sendString(QString)),this,SLOT(recvString(QString)));
    this->thread1->start();
    this->thread2->start();
}

Widget::~Widget()
{
    delete ui;
}

void Widget::recvString(QString text)
{
    ui->label->setText(text);
}
