#ifndef THREAD2_H
#define THREAD2_H

#include <QThread>

class Thread2 : public QThread
{
    Q_OBJECT
public:
    explicit Thread2(QObject *parent = 0);
    void run();
signals:
    void sendString(QString);
public slots:

};

#endif // THREAD2_H
