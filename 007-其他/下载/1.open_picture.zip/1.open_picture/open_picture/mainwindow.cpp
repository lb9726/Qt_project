#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_OpenPicture_clicked()
{
    QPixmap  image; //����һ��ͼƬ
    image.load("Example1.jpg");//����
    ui->ShowPicture->clear();//���
    ui->ShowPicture->setPixmap(image);//���ص�Label��ǩ
    ui->ShowPicture->show();//��ʾ
}
