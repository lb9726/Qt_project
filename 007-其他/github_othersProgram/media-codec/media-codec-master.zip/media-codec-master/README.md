# media-codec
Video and audio decode/encode libraries.
