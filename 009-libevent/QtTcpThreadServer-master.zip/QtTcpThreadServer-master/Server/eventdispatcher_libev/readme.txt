 此来自大牛的封装，我根据需求进行了部分改动和精简，源代码库地址：https://github.com/sjinks/qt_eventdispatcher_libev
