#ifndef SCREENSAVER_H
#define SCREENSAVER_H

#include <QObject>
#include <QTimer>

class ScreenSaver : public QObject
{
    Q_OBJECT
public:
    explicit ScreenSaver(QObject *parent = 0);
    void setScreenSaverTime(int ptime);
    void setScreenSaveHoldTime(int ptime);
    void setStandyByFlag(bool flag);
    void exitScreenSaver();

signals:
    void sigSetBlackPicture(bool flag);

public slots:
    void enterStandBy();

private slots:
    void startCoverBlackGroundTimer();
    void removeBlackGround();

private:
    void remainStatus();

private:
    int                            mScreenSaverTime;
    int                            mChangeBackTime;
    volatile   bool                mIsStanyBy;
    QTimer                         qtimer_mScreenSaverTime;
    QTimer                         qtimer_mChangeBackTime;
};

#endif // SCREENSAVER_H
