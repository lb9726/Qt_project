#ifndef GRAPHICSFUNCTION_H
#define GRAPHICSFUNCTION_H

#include "graphicsoperate.h"

#endif

