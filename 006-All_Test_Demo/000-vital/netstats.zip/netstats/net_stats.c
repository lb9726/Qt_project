#include <stdio.h>
#include <string.h>

#include "net_stats.h"

static char * get_name(char * name, char * p)
{
    char * t = NULL;

    /*interface only contains lowercase letters*/
    while((*p<'a') || (*p>'z')) p++;

    if ((t =  strchr(p, ':')))
    {
        memcpy(name, p, t-p);
        return t+1;
    }
    else 
		return NULL;
}

#define PROC_NET_DEV_FNAME "/proc/net/dev"
int get_devstats(char * ifname, struct netdev_stats * pstats)
{
    FILE * fp;
    char name[256] = {0};
    char buf[256] = {0};
    char * s = NULL;
    int found = 0;

    if (!ifname || !pstats) 
		return -1;

    fp = fopen(PROC_NET_DEV_FNAME, "r");

    if (!fp) 
		return -1;
    else 
    {
        /*by pass the first 2 lines, they are titles*/
        fgets(buf, sizeof(buf), fp );
        fgets(buf, sizeof(buf), fp );

        memset(buf, 0 ,sizeof(buf));
        while (fgets(buf, sizeof(buf), fp )) 
        {
            memset(name, 0, sizeof(name));
            s = get_name(name, buf);

            if(s) 
            {
                sscanf(s, "%llu%llu%lu%lu%lu%lu%lu%lu%llu%llu%lu%lu%lu%lu%lu%lu",
                       &pstats->rx_bytes_m, /* missing for 0 */
                       &pstats->rx_packets_m,
                       &pstats->rx_errors_m,
                       &pstats->rx_dropped_m,
                       &pstats->rx_fifo_errors_m,
                       &pstats->rx_frame_errors_m,
                       &pstats->rx_compressed_m, /* missing for <= 1 */
                       &pstats->rx_multicast_m, /* missing for <= 1 */
                       &pstats->tx_bytes_m, /* missing for 0 */
                       &pstats->tx_packets_m,
                       &pstats->tx_errors_m,
                       &pstats->tx_dropped_m,
                       &pstats->tx_fifo_errors_m,
                       &pstats->collisions_m,
                       &pstats->tx_carrier_errors_m,
                       &pstats->tx_compressed_m /* missing for <= 1 */
                    );

                if(!strncmp(name, ifname, strlen(ifname)))  
                {
                    found = 1;
                    break;

                    printf("name :%s\n", name);
                    printf("%llu:%llu:%lu:%lu:%lu:%lu:%lu:%lu:%llu:%llu:%lu:%lu:%lu:%lu:%lu:%lu:\n",
                           pstats->rx_bytes_m, /* missing for 0 */
                           pstats->rx_packets_m,
                           pstats->rx_errors_m,
                           pstats->rx_dropped_m,
                           pstats->rx_fifo_errors_m,
                           pstats->rx_frame_errors_m,
                           pstats->rx_compressed_m, /* missing for <= 1 */
                           pstats->rx_multicast_m, /* missing for <= 1 */
                           pstats->tx_bytes_m, /* missing for 0 */
                           pstats->tx_packets_m,
                           pstats->tx_errors_m,
                           pstats->tx_dropped_m,
                           pstats->tx_fifo_errors_m,
                           pstats->collisions_m,
                           pstats->tx_carrier_errors_m,
                           pstats->tx_compressed_m /* missing for <= 1 */
                        );

					
					
                }
            }
            else continue;
        } 
        fclose(fp);
    }
    if (!found) 
		return -1;
    else  
		return 0;
}