#ifndef __NET_STATS_H__
#define __NET_STATS_H__

struct netdev_stats {
    unsigned long long rx_packets_m;    /* total packets received       */
    unsigned long long tx_packets_m;        /* total packets transmitted    */
    unsigned long long rx_bytes_m;  /* total bytes received         */
    unsigned long long tx_bytes_m;  /* total bytes transmitted      */
    unsigned long rx_errors_m;      /* bad packets received         */
    unsigned long tx_errors_m;      /* packet transmit problems     */
    unsigned long rx_dropped_m;     /* no space in linux buffers    */
    unsigned long tx_dropped_m;     /* no space available in linux  */
    unsigned long rx_multicast_m;   /* multicast packets received   */
    unsigned long rx_compressed_m;
    unsigned long tx_compressed_m;
    unsigned long collisions_m;

    /* detailed rx_errors: */
    unsigned long rx_fifo_errors_m; /* recv'r fifo overrun          */
	unsigned long rx_frame_errors_m;
    /* detailed tx_errors */
    unsigned long tx_fifo_errors_m;
	unsigned long tx_carrier_errors_m;
};

int get_devstats(char * ifname, struct netdev_stats * pstats);

#endif