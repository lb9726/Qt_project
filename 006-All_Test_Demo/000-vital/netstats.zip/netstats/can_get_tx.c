#include <stdio.h>

#include "net_stats.h"

void main(void)
{
	struct netdev_stats stats;
	get_devstats("can0", &stats);
	
	/*
	*	warning:
	*			if tx_packets_m for printf, format must be %lld, 
	*			otherwise display 0!!
	*/
	printf("CAN0 TX packets:%llu\n", stats.tx_packets_m);
}