#ifndef SCREEN_H
#define SCREEN_H

#include <QWidget>
#include "dataaggregation.h"
#include <QTimer>

namespace Ui {
class Screen;
}

class Screen : public QWidget
{
    Q_OBJECT

public:
    explicit Screen(QWidget *parent = 0);
    ~Screen();
    void countAll();
    void paintEvent(QPaintEvent *event);

private slots:
    void sltStartCountUseTime();
    void sltSetUserNum(int num);
    void sltSetObserveObjNum(int num);
    void sltEndedCountTime();
    void sltTimeOut();
    void sltTellResult(QString str);
private:
    void setPromptStr(QString str);
    void setFreq(int freq);

private:
    Ui::Screen *ui;
    DataAggregation mDataAggregation;
    QTimer mTimer;
    int mFreq;
    qint64 mUserTime;
};

#endif // SCREEN_H
