#include "screen.h"
#include "ui_screen.h"
#include <QDebug>
#include <QPixmap>
#include <QPainter>

Screen::Screen(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Screen)
{
    ui->setupUi(this);
    this->setFixedWidth(this->width());
    this->setFixedHeight(this->height());
    mFreq = 100;
    mUserTime = 0;
    connect(&mDataAggregation, &DataAggregation::sigStartCount, this, &Screen::sltStartCountUseTime, Qt::QueuedConnection);
    connect(&mDataAggregation, &DataAggregation::sigCountEnded, this, &Screen::sltEndedCountTime, Qt::QueuedConnection);
    connect(&mDataAggregation, &DataAggregation::sigSendObserveObj, this, &Screen::sltSetObserveObjNum, Qt::QueuedConnection);
    connect(&mDataAggregation, &DataAggregation::sigSendUserNum, this, &Screen::sltSetUserNum, Qt::QueuedConnection);
    connect(&mDataAggregation, &DataAggregation::sigTellResult, this, &Screen::sltTellResult, Qt::QueuedConnection);
    connect(&mTimer, &QTimer::timeout, this, &Screen::sltTimeOut);
}

Screen::~Screen()
{
    delete ui;
}

void Screen::countAll()
{
    mDataAggregation.start();
}

void Screen::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPixmap tmpPicture(":/images/bg.png");
    QPainter p(this);
    p.drawPixmap(rect(), tmpPicture);
}

void Screen::sltStartCountUseTime()
{
    setPromptStr(QString("正在获取用户数和观测对象数..."));
    setFreq(100);
    mTimer.start(mFreq);
}

void Screen::sltSetUserNum(int num)
{
    ui->label_userNum->setText(QString::number(num));
}

void Screen::sltSetObserveObjNum(int num)
{
    ui->label_observerNum->setText(QString::number(num));
    setPromptStr(QString("数据聚合中，请稍后...."));
}

void Screen::sltEndedCountTime()
{
    if (mTimer.isActive())
    {
        mTimer.stop();
    }
    ui->label_Prompt->setStyleSheet("QLabel {color:red}");

    int minute = mUserTime / 1000 / 60;
    int second = (mUserTime - minute * 60000) / 1000;
    int msecond = mUserTime % 1000;

    setPromptStr(QString("数据聚合结束，用时 ") + QString::number(minute) + "分"
                 + QString::number(second) + "秒" + QString::number(msecond) + "毫秒");
}

void Screen::sltTimeOut()
{
    mUserTime += mFreq;
    QString tmp = QString::number(mUserTime);
    ui->label_usedTime->setText(tmp);
    static int flag = 0;
    ++flag;
    if (1 == flag)
    {
        ui->label_Prompt->setStyleSheet("QLabel {color:red}");
        setPromptStr(QString("数据聚合中，请稍后."));
    }
    else if (2 == flag)
    {
        ui->label_Prompt->setStyleSheet("QLabel {color:green}");
        setPromptStr(QString("数据聚合中，请稍后.."));
    }
    else if (3 == flag)
    {
        ui->label_Prompt->setStyleSheet("QLabel {color:blue}");
        setPromptStr(QString("数据聚合中，请稍后..."));
        flag = 0;
    }
}

void Screen::sltTellResult(QString str)
{
    ui->label_result->setStyleSheet("QLabel {color:red}");
    ui->label_result->setText("运算结果保存在:" + str);
}

//运算中，请稍后....
void Screen::setPromptStr(QString str)
{
    ui->label_Prompt->setText(str);
}

void Screen::setFreq(int freq)
{
    mFreq = freq;
}
