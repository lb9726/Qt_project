#include "mygraphicview.h"

MyGraphicView::MyGraphicView(QObject *parent) : QObject(parent)
{

}
