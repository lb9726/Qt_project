<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_AS">
<context>
    <name>IpSetUp</name>
    <message>
        <location filename="qmlComponent/IpSetUp.qml" line="12"/>
        <location filename="qmlComponent/IpSetUp.qml" line="84"/>
        <source>IP地址:</source>
        <translation>IPAddress:</translation>
    </message>
    <message>
        <location filename="qmlComponent/IpSetUp.qml" line="31"/>
        <location filename="qmlComponent/IpSetUp.qml" line="85"/>
        <source>子网掩码:</source>
        <translation>SubNetMask:</translation>
    </message>
    <message>
        <location filename="qmlComponent/IpSetUp.qml" line="50"/>
        <location filename="qmlComponent/IpSetUp.qml" line="86"/>
        <source>默认网关:</source>
        <translation>DefaultRoute:</translation>
    </message>
    <message>
        <location filename="qmlComponent/IpSetUp.qml" line="69"/>
        <location filename="qmlComponent/IpSetUp.qml" line="87"/>
        <source>首选DNS服务器:</source>
        <translation>DNSService</translation>
    </message>
</context>
<context>
    <name>MainScreen</name>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="31"/>
        <location filename="qmlComponent/MainScreen.qml" line="362"/>
        <source>参数配置</source>
        <translation>Parameter Setting</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="44"/>
        <location filename="qmlComponent/MainScreen.qml" line="363"/>
        <source>亮度,声音,日期格式</source>
        <translation>Brightness,sound,date format</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="54"/>
        <location filename="qmlComponent/MainScreen.qml" line="364"/>
        <source>资源配置</source>
        <translation>Resource Setting</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="67"/>
        <location filename="qmlComponent/MainScreen.qml" line="365"/>
        <source>媒体资源,公告信息</source>
        <translation>Media Resource,notice information</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="76"/>
        <location filename="qmlComponent/MainScreen.qml" line="366"/>
        <source>高级配置</source>
        <translation>Senior Setting</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="89"/>
        <location filename="qmlComponent/MainScreen.qml" line="367"/>
        <source>系统时间,APN,IP设定</source>
        <translation>SystemTime,APN,IPSetting</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="99"/>
        <location filename="qmlComponent/MainScreen.qml" line="368"/>
        <source>制作升级盘</source>
        <translation>Select device</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="106"/>
        <location filename="qmlComponent/MainScreen.qml" line="369"/>
        <source>选择升级U盘</source>
        <translation>Upgrade content on USB</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="129"/>
        <location filename="qmlComponent/MainScreen.qml" line="370"/>
        <source>制作</source>
        <translation>UPLOAD</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="144"/>
        <location filename="qmlComponent/MainScreen.qml" line="371"/>
        <source>预览</source>
        <translation>Preview</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="152"/>
        <location filename="qmlComponent/MainScreen.qml" line="372"/>
        <source>重置为默认设置</source>
        <translation>Reset default configuration</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="174"/>
        <source>打开此开关选项,屏幕将恢复默认的参数配置.多媒体,滚动字幕,标题,时间和日期,系统配置参数都将恢复为默认.</source>
        <translation>If you confirm this selection,the screen will restore the default settings.All parameters including scrolling text,time and date and multimedia will be restored to default settings.</translation>
    </message>
</context>
<context>
    <name>ParaMeterConfig</name>
    <message>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="23"/>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="208"/>
        <source>亮度设置</source>
        <translation>Brightness Setting</translation>
    </message>
    <message>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="48"/>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="209"/>
        <source>声音设置</source>
        <translation>Volume Setting</translation>
    </message>
    <message>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="73"/>
        <source>时间格式</source>
        <translation>Time Format</translation>
    </message>
    <message>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="107"/>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="210"/>
        <source>选择日期格式</source>
        <translation>Select date Format</translation>
    </message>
    <message>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="139"/>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="211"/>
        <source>隐藏时间和日期</source>
        <translation>Hide time and date</translation>
    </message>
</context>
<context>
    <name>ParaMeterConfigWindow</name>
    <message>
        <location filename="qmlComponent/ParaMeterConfigWindow.qml" line="13"/>
        <location filename="qmlComponent/ParaMeterConfigWindow.qml" line="145"/>
        <source>参数配置</source>
        <translation>Parameter setting</translation>
    </message>
    <message>
        <location filename="qmlComponent/ParaMeterConfigWindow.qml" line="36"/>
        <location filename="qmlComponent/ParaMeterConfigWindow.qml" line="146"/>
        <source>保存</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="qmlComponent/ParaMeterConfigWindow.qml" line="52"/>
        <location filename="qmlComponent/ParaMeterConfigWindow.qml" line="147"/>
        <source>取消</source>
        <translation>Cancel</translation>
    </message>
</context>
<context>
    <name>PopUpDefine</name>
    <message>
        <location filename="qmlComponent/PopUpDefine.qml" line="28"/>
        <location filename="qmlComponent/PopUpDefine.qml" line="57"/>
        <source>确认</source>
        <translation>Confirm</translation>
    </message>
    <message>
        <location filename="qmlComponent/PopUpDefine.qml" line="41"/>
        <location filename="qmlComponent/PopUpDefine.qml" line="58"/>
        <source>取消</source>
        <translation>Cancel</translation>
    </message>
</context>
<context>
    <name>PopUpProgress</name>
    <message>
        <location filename="qmlComponent/PopUpProgress.qml" line="128"/>
        <source>点击以结束制作</source>
        <translation>Clicked and ended making</translation>
    </message>
    <message>
        <location filename="qmlComponent/PopUpProgress.qml" line="161"/>
        <source>拷贝文件...</source>
        <translation>Copying file...</translation>
    </message>
    <message>
        <location filename="qmlComponent/PopUpProgress.qml" line="198"/>
        <source>正在生成配置参数</source>
        <translation>Configuration parameters are being generated</translation>
    </message>
    <message>
        <location filename="qmlComponent/PopUpProgress.qml" line="200"/>
        <source>升级盘制作成功</source>
        <translation>Upgrade disk production success</translation>
    </message>
    <message>
        <location filename="qmlComponent/PopUpProgress.qml" line="219"/>
        <source>正在检查U盘...</source>
        <translation>Checking Udisk...</translation>
    </message>
</context>
<context>
    <name>PreviewWindow_horizontal</name>
    <message>
        <location filename="qmlComponent/PreviewWindow_horizontal.qml" line="10"/>
        <location filename="qmlComponent/PreviewWindow_horizontal.qml" line="278"/>
        <source>界面预览</source>
        <translation>Screen Preview</translation>
    </message>
    <message>
        <location filename="qmlComponent/PreviewWindow_horizontal.qml" line="36"/>
        <location filename="qmlComponent/PreviewWindow_horizontal.qml" line="279"/>
        <source>横屏显示</source>
        <translation>Horizontal show</translation>
    </message>
    <message>
        <location filename="qmlComponent/PreviewWindow_horizontal.qml" line="51"/>
        <location filename="qmlComponent/PreviewWindow_horizontal.qml" line="280"/>
        <source>竖屏显示</source>
        <translation>Vertical Show</translation>
    </message>
</context>
<context>
    <name>PreviewWindow_vertical</name>
    <message>
        <location filename="qmlComponent/PreviewWindow_vertical.qml" line="10"/>
        <location filename="qmlComponent/PreviewWindow_vertical.qml" line="272"/>
        <source>界面预览</source>
        <translation>Screen Preview</translation>
    </message>
    <message>
        <location filename="qmlComponent/PreviewWindow_vertical.qml" line="35"/>
        <location filename="qmlComponent/PreviewWindow_vertical.qml" line="273"/>
        <source>横屏显示</source>
        <translation>Horizontal show</translation>
    </message>
    <message>
        <location filename="qmlComponent/PreviewWindow_vertical.qml" line="50"/>
        <location filename="qmlComponent/PreviewWindow_vertical.qml" line="274"/>
        <source>竖屏显示</source>
        <translation>Vertical Show</translation>
    </message>
</context>
<context>
    <name>ResourceConfigWindow</name>
    <message>
        <location filename="qmlComponent/ResourceConfigWindow.qml" line="13"/>
        <location filename="qmlComponent/ResourceConfigWindow.qml" line="204"/>
        <source>资源配置</source>
        <translation>Resource Configuration</translation>
    </message>
    <message>
        <location filename="qmlComponent/ResourceConfigWindow.qml" line="39"/>
        <location filename="qmlComponent/ResourceConfigWindow.qml" line="205"/>
        <source>保存</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="qmlComponent/ResourceConfigWindow.qml" line="55"/>
        <location filename="qmlComponent/ResourceConfigWindow.qml" line="206"/>
        <source>取消</source>
        <translation>Cancel</translation>
    </message>
</context>
<context>
    <name>Self_TextField</name>
    <message>
        <location filename="qmlComponent/Self_TextField.qml" line="29"/>
        <location filename="qmlComponent/Self_TextField.qml" line="273"/>
        <source>年</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="qmlComponent/Self_TextField.qml" line="40"/>
        <location filename="qmlComponent/Self_TextField.qml" line="274"/>
        <source>月</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="qmlComponent/Self_TextField.qml" line="51"/>
        <location filename="qmlComponent/Self_TextField.qml" line="275"/>
        <source>日</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="qmlComponent/Self_TextField.qml" line="62"/>
        <location filename="qmlComponent/Self_TextField.qml" line="276"/>
        <source>时</source>
        <translation>H</translation>
    </message>
    <message>
        <location filename="qmlComponent/Self_TextField.qml" line="73"/>
        <location filename="qmlComponent/Self_TextField.qml" line="277"/>
        <source>分</source>
        <translation>m</translation>
    </message>
    <message>
        <location filename="qmlComponent/Self_TextField.qml" line="84"/>
        <location filename="qmlComponent/Self_TextField.qml" line="278"/>
        <source>秒</source>
        <translation>s</translation>
    </message>
</context>
<context>
    <name>SeniorConfigWindow</name>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="14"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="363"/>
        <source>高级配置</source>
        <translation>Senior Configuration</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="36"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="364"/>
        <source>云端APN设置</source>
        <translation>APN SETTING FOR CLOUD</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="44"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="365"/>
        <source>国家:</source>
        <translation>Country:</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="59"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="366"/>
        <source>运营商:</source>
        <translation>NetWork:</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="73"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="367"/>
        <source>接入点:</source>
        <translation>APN:</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="87"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="368"/>
        <source>用户名:</source>
        <translation>UserName:</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="131"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="369"/>
        <source>密码:</source>
        <translation>Password:</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="147"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="370"/>
        <source>隐藏APN</source>
        <translation>Hide Apn</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="158"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="371"/>
        <source>系统时间设置</source>
        <translation>System TimeSetting</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="173"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="372"/>
        <source>局域网设置</source>
        <translation>LAN SETTING</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="188"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="200"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="375"/>
        <source>自动获取</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="193"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="380"/>
        <source>手动获取</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="216"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="382"/>
        <source>保存</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="237"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="383"/>
        <source>取消</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="258"/>
        <source>APN信息不完整</source>
        <translation>Lack of APN information</translation>
    </message>
</context>
<context>
    <name>SystemTimeEdit</name>
    <message>
        <location filename="qmlComponent/SystemTimeEdit.qml" line="25"/>
        <location filename="qmlComponent/SystemTimeEdit.qml" line="45"/>
        <source>隐藏系统时间</source>
        <translation>Hide SystemTime</translation>
    </message>
</context>
<context>
    <name>TextEditDefined</name>
    <message>
        <location filename="qmlComponent/TextEditDefined.qml" line="15"/>
        <location filename="qmlComponent/TextEditDefined.qml" line="35"/>
        <source>编辑...</source>
        <translation>Edit...</translation>
    </message>
</context>
<context>
    <name>TextEditPasswordDefined</name>
    <message>
        <location filename="qmlComponent/TextEditPasswordDefined.qml" line="15"/>
        <location filename="qmlComponent/TextEditPasswordDefined.qml" line="35"/>
        <source>编辑...</source>
        <translation>Edit...</translation>
    </message>
</context>
<context>
    <name>VideoAndPicture</name>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="31"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="554"/>
        <source>资源类型</source>
        <translation>Resource type</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="43"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="557"/>
        <source>全屏播放</source>
        <translation>FullScreen media</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="47"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="55"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="561"/>
        <source>正常播放</source>
        <translation>With elevator information</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="64"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="563"/>
        <source>视频</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="72"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="564"/>
        <source>音频</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="80"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="565"/>
        <source>图片</source>
        <translation>Picture</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="109"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="566"/>
        <source>选择视频</source>
        <translation>Select Video</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="142"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="567"/>
        <source>选择音频</source>
        <translation>Select Audio</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="158"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="568"/>
        <source>选择图片</source>
        <translation>Select Picture</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="174"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="569"/>
        <source>间隔</source>
        <translation>interval</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="233"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="570"/>
        <source>添加</source>
        <translation>Add</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="244"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="571"/>
        <source>删除</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="255"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="572"/>
        <source>清空</source>
        <translation>Clear</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="266"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="573"/>
        <source>标题</source>
        <translation>Title</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="274"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="574"/>
        <source>公告</source>
        <translation>Notice</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="283"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="575"/>
        <source>请输入标题文字</source>
        <translation>Please enter text here.2 to 16 characters.</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="300"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="576"/>
        <source>请输入字幕文字</source>
        <translation>Please enter text here.At least 2 characters.</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="314"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="577"/>
        <source>请选择一个视频文件</source>
        <translation>Please select an video file</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="325"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="578"/>
        <source>请选择一个音频文件</source>
        <translation>Please select an audio file</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="336"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="579"/>
        <source>请选取图片</source>
        <translation>Please select picture</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="qmlComponent/main.qml" line="16"/>
        <source>MediaScreen ContentMgmt V3.0</source>
        <translation>MediaScreen ContentMgmt V3.0</translation>
    </message>
</context>
</TS>
