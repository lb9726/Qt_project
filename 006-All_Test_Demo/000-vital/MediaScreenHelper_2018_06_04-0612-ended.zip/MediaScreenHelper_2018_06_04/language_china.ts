<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>IpSetUp</name>
    <message>
        <location filename="qmlComponent/IpSetUp.qml" line="12"/>
        <location filename="qmlComponent/IpSetUp.qml" line="84"/>
        <source>IP地址:</source>
        <translation>IP地址:</translation>
    </message>
    <message>
        <location filename="qmlComponent/IpSetUp.qml" line="31"/>
        <location filename="qmlComponent/IpSetUp.qml" line="85"/>
        <source>子网掩码:</source>
        <translation>子网掩码:</translation>
    </message>
    <message>
        <location filename="qmlComponent/IpSetUp.qml" line="50"/>
        <location filename="qmlComponent/IpSetUp.qml" line="86"/>
        <source>默认网关:</source>
        <translation>默认网关:</translation>
    </message>
    <message>
        <location filename="qmlComponent/IpSetUp.qml" line="69"/>
        <location filename="qmlComponent/IpSetUp.qml" line="87"/>
        <source>首选DNS服务器:</source>
        <translation>首选DNS服务器:</translation>
    </message>
</context>
<context>
    <name>MainScreen</name>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="31"/>
        <location filename="qmlComponent/MainScreen.qml" line="362"/>
        <source>参数配置</source>
        <translation>参数配置</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="44"/>
        <location filename="qmlComponent/MainScreen.qml" line="363"/>
        <source>亮度,声音,日期格式</source>
        <translation>亮度,声音,日期格式</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="54"/>
        <location filename="qmlComponent/MainScreen.qml" line="364"/>
        <source>资源配置</source>
        <translation>资源配置</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="67"/>
        <location filename="qmlComponent/MainScreen.qml" line="365"/>
        <source>媒体资源,公告信息</source>
        <translation>媒体资源,公告信息</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="76"/>
        <location filename="qmlComponent/MainScreen.qml" line="366"/>
        <source>高级配置</source>
        <translation>高级配置</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="89"/>
        <location filename="qmlComponent/MainScreen.qml" line="367"/>
        <source>系统时间,APN,IP设定</source>
        <translation>系统时间,APN,IP设定</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="99"/>
        <location filename="qmlComponent/MainScreen.qml" line="368"/>
        <source>制作升级盘</source>
        <translation>制作升级盘</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="106"/>
        <location filename="qmlComponent/MainScreen.qml" line="369"/>
        <source>选择升级U盘</source>
        <translation>选择升级盘</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="129"/>
        <location filename="qmlComponent/MainScreen.qml" line="370"/>
        <source>制作</source>
        <translation>制作</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="144"/>
        <location filename="qmlComponent/MainScreen.qml" line="371"/>
        <source>预览</source>
        <translation>预览</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="152"/>
        <location filename="qmlComponent/MainScreen.qml" line="372"/>
        <source>重置为默认设置</source>
        <translation>重置为默认设置</translation>
    </message>
    <message>
        <location filename="qmlComponent/MainScreen.qml" line="174"/>
        <source>打开此开关选项,屏幕将恢复默认的参数配置.多媒体,滚动字幕,标题,时间和日期,系统配置参数都将恢复为默认.</source>
        <translation>打开此开关选项,屏幕将恢复默认的参数配置.多媒体,滚动字幕,标题,时间和日期,系统配置参数都将恢复为默认.</translation>
    </message>
</context>
<context>
    <name>ParaMeterConfig</name>
    <message>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="23"/>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="208"/>
        <source>亮度设置</source>
        <translation>亮度设置</translation>
    </message>
    <message>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="48"/>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="209"/>
        <source>声音设置</source>
        <translation>声音设置</translation>
    </message>
    <message>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="73"/>
        <source>时间格式</source>
        <translation>时间格式</translation>
    </message>
    <message>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="107"/>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="210"/>
        <source>选择日期格式</source>
        <translation>选择日期格式</translation>
    </message>
    <message>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="139"/>
        <location filename="qmlComponent/ParaMeterConfig.qml" line="211"/>
        <source>隐藏时间和日期</source>
        <translation>隐藏时间和日期</translation>
    </message>
</context>
<context>
    <name>ParaMeterConfigWindow</name>
    <message>
        <location filename="qmlComponent/ParaMeterConfigWindow.qml" line="13"/>
        <location filename="qmlComponent/ParaMeterConfigWindow.qml" line="145"/>
        <source>参数配置</source>
        <translation>参数配置</translation>
    </message>
    <message>
        <location filename="qmlComponent/ParaMeterConfigWindow.qml" line="36"/>
        <location filename="qmlComponent/ParaMeterConfigWindow.qml" line="146"/>
        <source>保存</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="qmlComponent/ParaMeterConfigWindow.qml" line="52"/>
        <location filename="qmlComponent/ParaMeterConfigWindow.qml" line="147"/>
        <source>取消</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>PopUpDefine</name>
    <message>
        <location filename="qmlComponent/PopUpDefine.qml" line="28"/>
        <location filename="qmlComponent/PopUpDefine.qml" line="57"/>
        <source>确认</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="qmlComponent/PopUpDefine.qml" line="41"/>
        <location filename="qmlComponent/PopUpDefine.qml" line="58"/>
        <source>取消</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>PopUpProgress</name>
    <message>
        <location filename="qmlComponent/PopUpProgress.qml" line="128"/>
        <source>点击以结束制作</source>
        <translation>点击以结束制作</translation>
    </message>
    <message>
        <location filename="qmlComponent/PopUpProgress.qml" line="161"/>
        <source>拷贝文件...</source>
        <translation>拷贝文件...</translation>
    </message>
    <message>
        <location filename="qmlComponent/PopUpProgress.qml" line="198"/>
        <source>正在生成配置参数</source>
        <translation>正在生成配置参数</translation>
    </message>
    <message>
        <location filename="qmlComponent/PopUpProgress.qml" line="200"/>
        <source>升级盘制作成功</source>
        <translation>升级盘制作成功</translation>
    </message>
    <message>
        <location filename="qmlComponent/PopUpProgress.qml" line="219"/>
        <source>正在检查U盘...</source>
        <translation>正在检查U盘...</translation>
    </message>
</context>
<context>
    <name>PreviewWindow_horizontal</name>
    <message>
        <location filename="qmlComponent/PreviewWindow_horizontal.qml" line="10"/>
        <location filename="qmlComponent/PreviewWindow_horizontal.qml" line="278"/>
        <source>界面预览</source>
        <translation>界面预览</translation>
    </message>
    <message>
        <location filename="qmlComponent/PreviewWindow_horizontal.qml" line="36"/>
        <location filename="qmlComponent/PreviewWindow_horizontal.qml" line="279"/>
        <source>横屏显示</source>
        <translation>横屏显示</translation>
    </message>
    <message>
        <location filename="qmlComponent/PreviewWindow_horizontal.qml" line="51"/>
        <location filename="qmlComponent/PreviewWindow_horizontal.qml" line="280"/>
        <source>竖屏显示</source>
        <translation>竖屏显示</translation>
    </message>
</context>
<context>
    <name>PreviewWindow_vertical</name>
    <message>
        <location filename="qmlComponent/PreviewWindow_vertical.qml" line="10"/>
        <location filename="qmlComponent/PreviewWindow_vertical.qml" line="272"/>
        <source>界面预览</source>
        <translation>界面预览</translation>
    </message>
    <message>
        <location filename="qmlComponent/PreviewWindow_vertical.qml" line="35"/>
        <location filename="qmlComponent/PreviewWindow_vertical.qml" line="273"/>
        <source>横屏显示</source>
        <translation>横屏显示</translation>
    </message>
    <message>
        <location filename="qmlComponent/PreviewWindow_vertical.qml" line="50"/>
        <location filename="qmlComponent/PreviewWindow_vertical.qml" line="274"/>
        <source>竖屏显示</source>
        <translation>竖屏显示</translation>
    </message>
</context>
<context>
    <name>ResourceConfigWindow</name>
    <message>
        <location filename="qmlComponent/ResourceConfigWindow.qml" line="13"/>
        <location filename="qmlComponent/ResourceConfigWindow.qml" line="204"/>
        <source>资源配置</source>
        <translation>资源配置</translation>
    </message>
    <message>
        <location filename="qmlComponent/ResourceConfigWindow.qml" line="39"/>
        <location filename="qmlComponent/ResourceConfigWindow.qml" line="205"/>
        <source>保存</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="qmlComponent/ResourceConfigWindow.qml" line="55"/>
        <location filename="qmlComponent/ResourceConfigWindow.qml" line="206"/>
        <source>取消</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>Self_TextField</name>
    <message>
        <location filename="qmlComponent/Self_TextField.qml" line="29"/>
        <location filename="qmlComponent/Self_TextField.qml" line="273"/>
        <source>年</source>
        <translation>年</translation>
    </message>
    <message>
        <location filename="qmlComponent/Self_TextField.qml" line="40"/>
        <location filename="qmlComponent/Self_TextField.qml" line="274"/>
        <source>月</source>
        <translation>月</translation>
    </message>
    <message>
        <location filename="qmlComponent/Self_TextField.qml" line="51"/>
        <location filename="qmlComponent/Self_TextField.qml" line="275"/>
        <source>日</source>
        <translation>日</translation>
    </message>
    <message>
        <location filename="qmlComponent/Self_TextField.qml" line="62"/>
        <location filename="qmlComponent/Self_TextField.qml" line="276"/>
        <source>时</source>
        <translation>时</translation>
    </message>
    <message>
        <location filename="qmlComponent/Self_TextField.qml" line="73"/>
        <location filename="qmlComponent/Self_TextField.qml" line="277"/>
        <source>分</source>
        <translation>分</translation>
    </message>
    <message>
        <location filename="qmlComponent/Self_TextField.qml" line="84"/>
        <location filename="qmlComponent/Self_TextField.qml" line="278"/>
        <source>秒</source>
        <translation>秒</translation>
    </message>
</context>
<context>
    <name>SeniorConfigWindow</name>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="14"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="363"/>
        <source>高级配置</source>
        <translation>高级配置</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="36"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="364"/>
        <source>云端APN设置</source>
        <translation>云端APN设置</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="44"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="365"/>
        <source>国家:</source>
        <translation>国家:</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="59"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="366"/>
        <source>运营商:</source>
        <translation>运营商:</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="73"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="367"/>
        <source>接入点:</source>
        <translation>接入点:</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="87"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="368"/>
        <source>用户名:</source>
        <translation>用户名:</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="131"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="369"/>
        <source>密码:</source>
        <translation>密码:</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="147"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="370"/>
        <source>隐藏APN</source>
        <translation>隐藏APN</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="158"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="371"/>
        <source>系统时间设置</source>
        <translation>系统时间设置</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="173"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="372"/>
        <source>局域网设置</source>
        <translation>局域网设置</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="188"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="200"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="375"/>
        <source>自动获取</source>
        <translation>自动获取</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="193"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="380"/>
        <source>手动获取</source>
        <translation>手动获取</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="216"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="382"/>
        <source>保存</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="237"/>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="383"/>
        <source>取消</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="qmlComponent/SeniorConfigWindow.qml" line="258"/>
        <source>APN信息不完整</source>
        <translation>APN信息不完整</translation>
    </message>
</context>
<context>
    <name>SystemTimeEdit</name>
    <message>
        <location filename="qmlComponent/SystemTimeEdit.qml" line="25"/>
        <location filename="qmlComponent/SystemTimeEdit.qml" line="45"/>
        <source>隐藏系统时间</source>
        <translation>隐藏系统时间</translation>
    </message>
</context>
<context>
    <name>TextEditDefined</name>
    <message>
        <location filename="qmlComponent/TextEditDefined.qml" line="15"/>
        <location filename="qmlComponent/TextEditDefined.qml" line="35"/>
        <source>编辑...</source>
        <translation>编辑...</translation>
    </message>
</context>
<context>
    <name>TextEditPasswordDefined</name>
    <message>
        <location filename="qmlComponent/TextEditPasswordDefined.qml" line="15"/>
        <location filename="qmlComponent/TextEditPasswordDefined.qml" line="35"/>
        <source>编辑...</source>
        <translation>编辑...</translation>
    </message>
</context>
<context>
    <name>VideoAndPicture</name>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="31"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="554"/>
        <source>资源类型</source>
        <translation>资源类型</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="43"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="557"/>
        <source>全屏播放</source>
        <translation>全屏播放</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="47"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="55"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="561"/>
        <source>正常播放</source>
        <translation>正常播放</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="64"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="563"/>
        <source>视频</source>
        <translation>视频</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="72"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="564"/>
        <source>音频</source>
        <translation>音频</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="80"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="565"/>
        <source>图片</source>
        <translation>图片</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="109"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="566"/>
        <source>选择视频</source>
        <translation>选择视频</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="142"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="567"/>
        <source>选择音频</source>
        <translation>选择音频</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="158"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="568"/>
        <source>选择图片</source>
        <translation>选择图片</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="174"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="569"/>
        <source>间隔</source>
        <translation>间隔</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="233"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="570"/>
        <source>添加</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="244"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="571"/>
        <source>删除</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="255"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="572"/>
        <source>清空</source>
        <translation>清空</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="266"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="573"/>
        <source>标题</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="274"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="574"/>
        <source>公告</source>
        <translation>公告</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="283"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="575"/>
        <source>请输入标题文字</source>
        <translation>请输入标题文字</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="300"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="576"/>
        <source>请输入字幕文字</source>
        <translation>请输入字幕文字</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="314"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="577"/>
        <source>请选择一个视频文件</source>
        <translation>请选择一个视频文件</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="325"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="578"/>
        <source>请选择一个音频文件</source>
        <translation>请选择一个音频文件</translation>
    </message>
    <message>
        <location filename="qmlComponent/VideoAndPicture.qml" line="336"/>
        <location filename="qmlComponent/VideoAndPicture.qml" line="579"/>
        <source>请选取图片</source>
        <translation>请选取图片</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="qmlComponent/main.qml" line="16"/>
        <source>MediaScreen ContentMgmt V3.0</source>
        <translation>MediaScreen ContentMgmt V3.0</translation>
    </message>
</context>
</TS>
