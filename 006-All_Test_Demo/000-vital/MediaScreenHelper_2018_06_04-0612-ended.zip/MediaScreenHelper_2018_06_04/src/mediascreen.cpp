#include "mediascreen.h"
#include <QLocale>
#include <QHostInfo>
#include <QList>
#include <QHostAddress>
#include <QNetworkInterface>
#include <QDateTime>
#include <QFontDatabase>
#include <QCoreApplication>
#include <QFont>

MediaScreen::MediaScreen(QObject *parent) : QObject(parent)
  , index(-1)
  , preIndex(-1)
  , isInsertUdiskFlag(false)
{
    content = nullptr;
    engine = nullptr;
    nativeFilter = nullptr;
    configureSerialer = nullptr;
    mApp = nullptr;
    getLocalIp();
}

void MediaScreen::changeUi()
{
    ConfigureHolder* tmpconfigure = configureSerialer;
    QQmlApplicationEngine* tmpEngine = engine;

    engine = new QQmlApplicationEngine();
    configureSerialer = new ConfigureHolder(engine);
    content = engine->rootContext();

    tmpconfigure->deleteLater();
    tmpEngine->deleteLater();

    if (content)
    {
        content->setContextProperty("UsbHelper", nativeFilter->usbHelper); // 设置Qml的上下文属性，可以直接在qml中引用
        content->setContextProperty("ConfigureSerialer", configureSerialer);
        content->setContextProperty("Ctranslator", CTranslator::instance());
        content->setContextProperty("MediaScreen", this);
    }

    if(0 == index || 1 == index || 2 == index)
    {
        CTranslator::instance()->load(index);
        emit clearAudioParament(index);
        if (engine)
        {
            engine->load(QUrl(QLatin1String("qrc:///qmlComponent/main.qml")));
        }
    }
    else if (3 == index)
    {
        emit clearAudioParament(index);
        if (content)
        {
            engine->load(QUrl(QLatin1String("qrc:///Country_russian/RussianMain.qml")));
        }
    }
}

void MediaScreen::setIndex(int i)
{
    qDebug()<<__PRETTY_FUNCTION__<<"()parament i = "<< i;
    index = i;
    qDebug()<<__PRETTY_FUNCTION__<<"SetIndex index = "<< index;
}

QVariant MediaScreen::getIndex()
{
    qDebug()<<__PRETTY_FUNCTION__<<"()index = "<<index;
    return index;
}

void MediaScreen::getScrollTextLength()
{
    emit getScrollTextLengthSignal();
}

int MediaScreen::getSystemLanguage()
{
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__;
    QLocale local;
    if (QLocale::English == local.language())
    {
        qDebug()<<"is English";
        return 2;
    }
    else if (QLocale::Chinese == local.language())
    {
        qDebug()<<"is Chinese";
        return 0;
    }
    else
    {
        return 2;
    }
}

void MediaScreen::setPreIndex(int i)
{
    qDebug()<<__PRETTY_FUNCTION__<<" before PreIndex is "<< preIndex;
    preIndex = index; // 记录上一次的preIndex的值
    qDebug()<<__PRETTY_FUNCTION__<<" after PreIndex is "<< preIndex;
    setIndex(i);
}

QVariant MediaScreen::getPreIndex()
{
    qDebug()<<__PRETTY_FUNCTION__<<" PreIndex is "<< preIndex;
    return preIndex;
}

QString MediaScreen::getIndexIpString(int index)
{
    if (ipString.isEmpty())
    {
        return QString();
    }
    else
    {
        QStringList tmpList = ipString.split(".");
        if (index < 1)
        {
            return QString();
        }
        else if (index <= tmpList.length())
        {
            qDebug()<<"tmpList.at(index -1 ) = " << tmpList.at(index - 1);
            return tmpList.at(index - 1);
        }
        else
        {
            return QString();
        }
    }
}

MediaScreen::~MediaScreen()
{
    if (nativeFilter)
    {
        delete nativeFilter;
        nativeFilter = 0;
    }
    if (configureSerialer)
    {
        configureSerialer->deleteLater();
        configureSerialer = 0;
    }
    if (engine)
    {
        delete engine;
        engine = 0;
    }
    if (CTranslator::instance())
    {
        delete CTranslator::instance();
    }
}

UsbEventFilter *MediaScreen::getPoint()
{
    if (nullptr != nativeFilter)
    {
        return nativeFilter;
    }
    return nullptr;
}

void MediaScreen::setApplication(QGuiApplication *app)
{
    mApp = app;
    QString fontDir = QCoreApplication::applicationDirPath() + "/font/KONE Information_v12.otf";
    int ret = QFontDatabase::addApplicationFont(fontDir);
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"ret = "<<ret;
    QFont font("KONE Information_v12");
    mApp->setFont(font);
}

void MediaScreen::getLocalIp()
{
    QString ipAddress;
    QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();
    // use the first non-localhost IPv4 address
    for (int i = 0; i < ipAddressesList.size(); ++i)
    {
        if (ipAddressesList.at(i) != QHostAddress::LocalHost &&
            ipAddressesList.at(i).toIPv4Address())
        {
            ipAddress = ipAddressesList.at(i).toString();
            break;
        }
    }
    // if we did not find one, use IPv4 localhost
    if (ipAddress.isEmpty())
    {
        ipAddress = QHostAddress(QHostAddress::LocalHost).toString();
    }
    ipString = ipAddress;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"ipString = "<<ipString;
}

QVariant MediaScreen::getModel(int index)
{
    QStringList tmpVar;
    switch (index) {
    case 0:
        tmpVar<<"China Mobile"<<"China Unicom";
        break;
    case 1:
        tmpVar<<"M1"<<"SingTel"<<"Starhub";
        break;
    case 2:
        break;
    case 3:
        break;
    case 4:
        break;
    case 5:
        break;
    default:
        break;
    }
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"tmpVar = "<<tmpVar;
    return tmpVar;
}

QString MediaScreen::getSplitTime(int index)
{
    QString timeStr = getTimeFormat(false);
    QStringList list = timeStr.split(":");
    if (index > list.length())
    {
        return QString();
    }
    else if (index < 1)
    {
        return QString();
    }
    else
    {
        qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<list.at(index - 1);
        return list.at(index - 1);
    }
}

QString MediaScreen::getSplitDate(int index)
{
    QString dateStr = getDateFormat(true);
    QStringList list = dateStr.split("-");
    if (index > list.length())
    {
        return QString();
    }
    else if (index < 1)
    {
        return QString();
    }
    else
    {
        qDebug()<<list.at(index - 1);
        return list.at(index - 1);
    }
}

QString MediaScreen::getDateFormat(bool isYmd)
{
    QString date = "";
    date.clear();
    if (isYmd)
    {
        date = QDateTime::currentDateTime().toString("yyyy-MM-dd");
    }
    else
    {
        date = QDateTime::currentDateTime().toString("MM-dd-yyyy");
    }
    //    qDebug()<< "date = "<< date;
    return date;
}

QString MediaScreen::getTimeFormat(bool is12)
{
    QString timelocal = "";
    timelocal.clear();
    if (is12)
    {
        timelocal = QDateTime::currentDateTime().toString("hh:mm:ss a");
        timelocal =  timelocal.split(" ").at(0);
    }
    else
    {
        timelocal = QDateTime::currentDateTime().toString("HH:mm:ss");
    }
    //    qDebug()<< "timelocal = "<< timelocal;
    return timelocal;
}

void MediaScreen::setUdiskIsInsertFlag(bool flag, QString udiskIndex)
{
    isInsertUdiskFlag = flag;
    udiskIndexStr = udiskIndex;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<" isInsertUdiskFlag = "<< isInsertUdiskFlag<<"udiskIndexStr = "<< udiskIndexStr;
}

void MediaScreen::sendUdiskInformation()
{
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<" isInsertUdiskFlag = "<< isInsertUdiskFlag<<" udiskIndexStr = "<< udiskIndexStr;
    if (isInsertUdiskFlag)
    {
        emit hasUdiskInsertToComputer(udiskIndexStr);
    }
}

void MediaScreen::init()
{
    engine = new QQmlApplicationEngine();
    configureSerialer = new ConfigureHolder(engine);
    nativeFilter = new UsbEventFilter();
    content = engine->rootContext();
    if (content)
    {
        // 设置Qml的上下文属性，可以直接在qml中引用
        content->setContextProperty("UsbHelper", nativeFilter->usbHelper);
        content->setContextProperty("ConfigureSerialer", configureSerialer);
        content->setContextProperty("Ctranslator", CTranslator::instance());
        content->setContextProperty("MediaScreen", this);
    }
    if (engine)
    {
        engine->load(QUrl(QLatin1String("qrc:///qmlComponent/main.qml")));
    }
    if (mApp)
    {
        mApp->installNativeEventFilter(getPoint());
    }
}
