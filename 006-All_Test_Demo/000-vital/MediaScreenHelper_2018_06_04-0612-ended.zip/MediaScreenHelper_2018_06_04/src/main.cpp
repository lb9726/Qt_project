#include <QGuiApplication>
#include "usbeventfilter.h"
#include "mediascreen.h"

#if defined Q_OS_WIN32
    #include <windows.h>

bool checkOnly()
{
    HANDLE m_hMutex = CreateMutex(NULL, FALSE,  L"MediascreenHelper_2018_06_08" );
    if (GetLastError() == ERROR_ALREADY_EXISTS)
    {
        CloseHandle(m_hMutex);
        m_hMutex  =  NULL;
        return  false;
    }
    else
    {
        return true;
    }
}
#endif

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QGuiApplication app(argc, argv);

    MediaScreen *mediascreen = new MediaScreen();
    mediascreen->setApplication(&app);
    mediascreen->init();

    int ret = app.exec();

    delete mediascreen;
    mediascreen = 0;
    return ret;
}
