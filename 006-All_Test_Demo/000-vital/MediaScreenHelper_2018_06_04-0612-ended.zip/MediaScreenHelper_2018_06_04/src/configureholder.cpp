﻿#include "configureholder.h"
#include "define.h"
#include <QCoreApplication>
#include <QDate>
#include <QChar>
#include <QDomDocument>
#include <QDomElement>
#include <QFile>
#include <QFileInfo>
#include <QDir>
#include <QDebug>

ConfigureHolder::ConfigureHolder(QObject *parent) : QObject(parent)
{
    clearParameters();
}

QString ConfigureHolder::GetFilePath(QString pFilePath)
{
    if (pFilePath.isEmpty())
    {
        return QString();
    }
    pFilePath.replace("\\", "/");
    if (pFilePath.endsWith('/'))
    {
        return QString();
    }
    int index = pFilePath.lastIndexOf('/');
    if (index < 0)
    {
        return QString();
    }
    return pFilePath.mid(0, index + 1);
}

void ConfigureHolder::clearParameters()
{
    mUsbPath = QString();
    mResetFlag = false;
    // parameterConfig model
    mParameterCfgSaveFlag = false;
    mParaBrightness = 60;
    mParaVolume = 20;
    mParaHideDateTimeFlag = false;
    mParaYearFormat = false;
    mParaTimeFormat24 = true;

    // Resource Config model
    mResourceCfgSaveFlag = false;
    mResourceVideoSelectFlag = false;
    mResourcePictureSelectFlag = false;
    mResourceFullScreenFlag = false;
    mResourceVideoPath = QString();
    mResourceAudioPath = QString();
    mResourcePicturePath = QString();
    mResourcePictureList1 = QStringList();
    mResourcePictureList2 = QStringList();
    mResourcePictureIntervalSecond = 3;
    mResourceScrollTextShowFlag = false;
    mResourceTitletShowFlag = false;
    mResourceScrollText = QString();
    mResourceTitleText = QString();

    // seniorconfig model
    mSeniorCfgSaveFlag = false;
    mSeniorHideApnFlag = false;
    mSeniorContry = QString();
    mSeniorYys = QString();
    mSeniorJrd = QString();
    mSeniorUserName = QString();
    mSeniorPassword = QString();
    mSeniorMcc = QString();
    mSeniorMnc = QString();
    mSeniorSystimeHideFlag = false;
    mSeniorSystemTime = QString();
    mSeniorAutoAcquireFlag = false;
    mSeniorIpAddress = QString();
    mSeniorSubNetMask = QString();
    mSeniorDefaultGateWay = QString();
    mSeniorDnsServer = QString();
}

void ConfigureHolder::setUsbPath(const QString &usbPath)
{
    mUsbPath = usbPath;
}

void ConfigureHolder::setResetFlag(bool resetFlag)
{
    mResetFlag = resetFlag;
}

void ConfigureHolder::setParameterCfgSaveFlag(bool parameterCfgSaveFlag)
{
    mParameterCfgSaveFlag = parameterCfgSaveFlag;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mParameterCfgSaveFlag = "<<mParameterCfgSaveFlag;
}

void ConfigureHolder::setParaBrightnessOrVolumeChanged(bool paraBrightnessOrVolumeChanged)
{
    mParaBrightnessOrVolumeChanged = paraBrightnessOrVolumeChanged;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mParaBrightnessOrVolumeChanged = "<<mParaBrightnessOrVolumeChanged;
}

void ConfigureHolder::setParaHideDateTimeFlag(bool paraHideDateTimeFlag)
{
    mParaHideDateTimeFlag = paraHideDateTimeFlag;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mParaHideDateTimeFlag = "<<mParaHideDateTimeFlag;
}

void ConfigureHolder::setParaBrightness(int paraBrightness)
{
    mParaBrightness = paraBrightness;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mParaBrightness = "<<mParaBrightness;
}

void ConfigureHolder::setParaVolume(int paraVolume)
{
    mParaVolume = paraVolume;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mParaVolume = "<<mParaVolume;
}

void ConfigureHolder::setParaYearFormat(bool paraYearFormat)
{
    mParaYearFormat = paraYearFormat;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mParaYearFormat = "<<mParaYearFormat;
}

void ConfigureHolder::setParaTimeFormat24(bool paraTimeFormat24)
{
    mParaTimeFormat24 = paraTimeFormat24;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mParaTimeFormat24 = "<<mParaTimeFormat24;
}

void ConfigureHolder::setResourceCfgSaveFlag(bool resourceCfgSaveFlag)
{
    mResourceCfgSaveFlag = resourceCfgSaveFlag;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourceCfgSaveFlag = "<<mResourceCfgSaveFlag;
}

void ConfigureHolder::setResourcePictureSelectFlag(bool resourcePictureSelectFlag)
{
    mResourcePictureSelectFlag = resourcePictureSelectFlag;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourcePictureSelectFlag = "<<mResourcePictureSelectFlag;
}

void ConfigureHolder::setResourceAudioSelectFlag(bool resourceAudioSelectFlag)
{
    mResourceAudioSelectFlag = resourceAudioSelectFlag;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourceAudioSelectFlag = "<<mResourceAudioSelectFlag;
}

void ConfigureHolder::setResourceVideoSelectFlag(bool resourceVideoSelectFlag)
{
    mResourceVideoSelectFlag = resourceVideoSelectFlag;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourceVideoSelectFlag = "<<mResourceVideoSelectFlag;
}
void ConfigureHolder::setResourceFullScreenFlag(bool resourceFullScreenFlag)
{
    mResourceFullScreenFlag = resourceFullScreenFlag;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourceFullScreenFlag = "<<mResourceFullScreenFlag;
}

void ConfigureHolder::setResourceVideoPath(const QString &resourceVideoPath)
{
    mResourceVideoPath = resourceVideoPath;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourceVideoPath = "<<mResourceVideoPath;
}

void ConfigureHolder::setResourceAudioPath(const QString &resourceAudioPath)
{
    mResourceAudioPath = resourceAudioPath;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourceAudioPath = "<<mResourceAudioPath;    
}

void ConfigureHolder::setResourcePicturePath(const QString &resourcePicturePath)
{
    mResourcePicturePath = resourcePicturePath;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourcePicturePath = "<<mResourcePicturePath;
    QStringList tmpList = resourcePicturePath.split("*");
    mResourcePictureList1.clear();
    for (int i = 0; i < tmpList.size(); ++i)
    {
        QString img = tmpList.at(i);
        if(!img.isEmpty())
        {
            mResourcePictureList1.append(toWindwosPath(img));
        }
    }
}

QString ConfigureHolder::toWindwosPath(QString pFilePath)
{
    if (pFilePath.isEmpty())
    {
        return QString();
    }

    return pFilePath.replace("/", "\\");
}

//void ConfigureHolder::setResourcePictureList1(const QStringList &resourcePictureList1)
//{
//    mResourcePictureList1 = resourcePictureList1;
//    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourcePictureList1 = "<<mResourcePictureList1;
//}

//void ConfigureHolder::setResourcePictureList2(const QStringList &resourcePictureList2)
//{
//    mResourcePictureList2 = resourcePictureList2;
//    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourcePictureList2 = "<<mResourcePictureList2;
//}

void ConfigureHolder::setResourcePictureIntervalSecond(int resourcePictureIntervalSecond)
{
    mResourcePictureIntervalSecond = resourcePictureIntervalSecond;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourcePictureIntervalSecond = "<<mResourcePictureIntervalSecond;
}

void ConfigureHolder::setResourceScrollTextShowFlag(bool resourceScrollTextShowFlag)
{
    mResourceScrollTextShowFlag = resourceScrollTextShowFlag;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourceScrollTextShowFlag = "<<mResourceScrollTextShowFlag;
}

void ConfigureHolder::setResourceTitletShowFlag(bool resourceTitletShowFlag)
{
    mResourceTitletShowFlag = resourceTitletShowFlag;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourceTitletShowFlag = "<<mResourceTitletShowFlag;
}

void ConfigureHolder::setResourceScrollText(const QString &resourceScrollText)
{
    mResourceScrollText = resourceScrollText;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourceScrollText = "<<mResourceScrollText;
}

void ConfigureHolder::setResourceTitleText(const QString &resourceTitleText)
{
    mResourceTitleText = resourceTitleText;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mResourceTitleText = "<<mResourceTitleText;
}

void ConfigureHolder::setSeniorCfgSaveFlag(bool seniorCfgSaveFlag)
{
    mSeniorCfgSaveFlag = seniorCfgSaveFlag;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorCfgSaveFlag = "<<mSeniorCfgSaveFlag;
}

void ConfigureHolder::setSeniorHideApnFlag(bool seniorHideApnFlag)
{
    mSeniorHideApnFlag = seniorHideApnFlag;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorHideApnFlag = "<<mSeniorHideApnFlag;
}

void ConfigureHolder::setSeniorContry(const QString &seniorContry)
{
    mSeniorContry = seniorContry;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorContry = "<<mSeniorContry;
}

void ConfigureHolder::setSeniorYys(const QString &seniorYys)
{
    mSeniorYys = seniorYys;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorYys = "<<mSeniorYys;
}

void ConfigureHolder::setSeniorJrd(const QString &seniorJrd)
{
    mSeniorJrd = seniorJrd;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorJrd = "<<mSeniorJrd;
}

void ConfigureHolder::setSeniorUserName(const QString &seniorUserName)
{
    mSeniorUserName = seniorUserName;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorUserName = "<<mSeniorUserName;
}

void ConfigureHolder::setSeniorPassword(const QString &seniorPassword)
{
    mSeniorPassword = seniorPassword;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorPassword = "<<mSeniorPassword;
}

void ConfigureHolder::setSeniorMcc(const QString &seniorMcc)
{
    mSeniorMcc = seniorMcc;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorMcc = "<<mSeniorMcc;
}

void ConfigureHolder::setSeniorMnc(const QString &seniorMnc)
{
    mSeniorMnc = seniorMnc;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorMnc = "<<mSeniorMnc;
}

void ConfigureHolder::setSeniorSystimeHideFlag(bool seniorSystimeHideFlag)
{
    mSeniorSystimeHideFlag = seniorSystimeHideFlag;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorSystimeHideFlag = "<<mSeniorSystimeHideFlag;
}

void ConfigureHolder::setSeniorSystemTime(const QString &seniorSystemTime)
{
    mSeniorSystemTime = seniorSystemTime;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorSystemTime = "<<mSeniorSystemTime;
}

void ConfigureHolder::setSeniorAutoAcquireFlag(bool seniorAutoAcquireFlag)
{
    mSeniorAutoAcquireFlag = seniorAutoAcquireFlag;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorAutoAcquireFlag = "<<mSeniorAutoAcquireFlag;
}

void ConfigureHolder::setSeniorIpAddress(const QString &seniorIpAddress)
{
    mSeniorIpAddress = seniorIpAddress;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorIpAddress = "<<mSeniorIpAddress;
}

void ConfigureHolder::setSeniorSubNetMask(const QString &seniorSubNetMask)
{
    mSeniorSubNetMask = seniorSubNetMask;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorSubNetMask = "<<mSeniorSubNetMask;
}

void ConfigureHolder::setSeniorDefaultGateWay(const QString &seniorDefaultGateWay)
{
    mSeniorDefaultGateWay = seniorDefaultGateWay;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorDefaultGateWay = "<<mSeniorDefaultGateWay;
}

void ConfigureHolder::setSeniorDnsServer(const QString &seniorDnsServer)
{
    mSeniorDnsServer = seniorDnsServer;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"mSeniorDnsServer = "<<mSeniorDnsServer;
}

void ConfigureHolder::onSigPreviewLayoutChange(QString pLayout)
{
    emit sigPreviewLayoutChange(pLayout);
}

void ConfigureHolder::onIsFullScreenSignal(bool isflag)
{
    emit isFullScreenChanges(isflag);
}

bool ConfigureHolder::createXml()
{
    QDomDocument cfgXml;
    QDomElement rootElement = cfgXml.createElement("root");
    cfgXml.appendChild(rootElement);
    QDate currentDate = QDate::currentDate();
    rootElement.setAttribute("releasedate", currentDate.toString("yyyy/MM/dd"));
    if (mResetFlag)
    {
        QDomElement resetElement = cfgXml.createElement("reset");
        resetElement.appendChild(cfgXml.createTextNode("true"));
        rootElement.appendChild(resetElement);
    }
    else
    {
        QDomElement parameterElement = cfgXml.createElement("parameter");
        if (mResourceFullScreenFlag)  // fullscreen
        {
            QDomElement fullscreenElement = cfgXml.createElement("fullscreen");
            fullscreenElement.appendChild(cfgXml.createTextNode("true"));
            parameterElement.appendChild(fullscreenElement);
        }
        else   // normal screen
        {
            QDomElement fullscreenElement = cfgXml.createElement("fullscreen");
            fullscreenElement.appendChild(cfgXml.createTextNode("false"));
            parameterElement.appendChild(fullscreenElement);
        }
        if (mParaHideDateTimeFlag) // hide
        {
            QDomElement timeareaElement = cfgXml.createElement("timearea");
            timeareaElement.appendChild(cfgXml.createTextNode("false"));
            parameterElement.appendChild(timeareaElement);
        }
        else
        {
            QDomElement timeElement = cfgXml.createElement("time");
            QDomElement tformatElement = cfgXml.createElement("format");
            if (mParaTimeFormat24)
            {
                tformatElement.appendChild(cfgXml.createTextNode(QString("24")));
            }
            else
            {
                tformatElement.appendChild(cfgXml.createTextNode(QString("12")));
            }
            timeElement.appendChild(tformatElement);
            parameterElement.appendChild(timeElement);

            QDomElement dateElement = cfgXml.createElement("date");
            QDomElement dformatElement = cfgXml.createElement("format");
            if (mParaYearFormat) // yyyy:mm:dd
            {
                dformatElement.appendChild(cfgXml.createTextNode(QString("yyyy.MM.dd")));
            }
            else
            {
                dformatElement.appendChild(cfgXml.createTextNode(QString("MM.dd.yyyy")));
            }
            dateElement.appendChild(dformatElement);
            parameterElement.appendChild(dateElement);

            QDomElement timeareaElement = cfgXml.createElement("timearea");
            timeareaElement.appendChild(cfgXml.createTextNode("true"));
            parameterElement.appendChild(timeareaElement);
        }

        QDomElement resourceElement = cfgXml.createElement("resource");
        int tret = judgeString(mResourceTitleText);
        qDebug()<<"xml vTitle = "<< tret;
        if (mResourceTitletShowFlag)  //  title show
        {
            QDomElement titleareaElement = cfgXml.createElement("titlearea");
            titleareaElement.appendChild(cfgXml.createTextNode("true"));
            parameterElement.appendChild(titleareaElement);
            if (2 == tret) // 不为空也不全为空格时
            {
                QDomElement titleElement = cfgXml.createElement("title");
                titleElement.appendChild(cfgXml.createTextNode(mResourceTitleText));
                resourceElement.appendChild(titleElement);
            }
        }
        else
        {
            QDomElement titleareaElement = cfgXml.createElement("titlearea");
            titleareaElement.appendChild(cfgXml.createTextNode("false"));
            parameterElement.appendChild(titleareaElement);
        }

        int ret = judgeString(mResourceScrollText);
        qDebug()<<"xml vScrollText = "<< ret;
        if (mResourceScrollTextShowFlag) //  scorll show
        {
            QDomElement scrollingareaElement = cfgXml.createElement("scrollingarea");
            scrollingareaElement.appendChild(cfgXml.createTextNode("true"));
            parameterElement.appendChild(scrollingareaElement);

            if (2 == ret)// 不为空也不全为空格时
            {
                QDomElement scrollingtextElement = cfgXml.createElement("scrollingtext");
                scrollingtextElement.appendChild(cfgXml.createTextNode(mResourceScrollText));
                resourceElement.appendChild(scrollingtextElement);
            }
        }
        else
        {
            QDomElement scrollingareaElement = cfgXml.createElement("scrollingarea");
            scrollingareaElement.appendChild(cfgXml.createTextNode("false"));
            parameterElement.appendChild(scrollingareaElement);
        }

        if (mParameterCfgSaveFlag)  // save clicked
        {
            if (mParaBrightnessOrVolumeChanged)
            {
                QDomElement volumeElement = cfgXml.createElement("volume");
                volumeElement.appendChild(cfgXml.createTextNode(QString("%1").arg(mParaVolume)));
                parameterElement.appendChild(volumeElement);

                QDomElement brightnessElement = cfgXml.createElement("brightness");
                brightnessElement.appendChild(cfgXml.createTextNode(QString("%1").arg(mParaBrightness)));
                parameterElement.appendChild(brightnessElement);
            }
        }

        if (mResourceCfgSaveFlag)   // save clicked
        {
            if (mResourceVideoSelectFlag)  // video selected
            {
                QFileInfo videoInfo(mResourceVideoPath);
                QString dstName = "0." + videoInfo.suffix();

                QDomElement videoElement = cfgXml.createElement("video");
                videoElement.appendChild(cfgXml.createTextNode(dstName));
                resourceElement.appendChild(videoElement);
            }
            else if (mResourceAudioSelectFlag)  // music selected
            {
                QFileInfo audioInfo(mResourceAudioPath);
                QString dstName = "0." + audioInfo.suffix();

                QDomElement AudioElement = cfgXml.createElement("audio");
                AudioElement.appendChild(cfgXml.createTextNode(dstName));
                resourceElement.appendChild(AudioElement);
            }
            else if (mResourcePictureSelectFlag) // picture selected
            {
                QDomElement pictureElement = cfgXml.createElement("picture");
                pictureElement.setAttribute("interval", mResourcePictureIntervalSecond);

                for (int i = 0; i < mResourcePictureList1.count(); ++i)
                {
                    QString pa = mResourcePictureList1.at(i);
                    QFileInfo imageInfo(pa);
                    QString dstName = QString("%1.%2").arg(i).arg(imageInfo.suffix());
                    QDomElement element = cfgXml.createElement("item");
                    element.setAttribute("index", i);
                    element.appendChild(cfgXml.createTextNode(dstName));
                    pictureElement.appendChild(element);
                }
                resourceElement.appendChild(pictureElement);
            }
            if(resourceElement.hasChildNodes())
            {
                rootElement.appendChild(resourceElement);
            }
        }

        if (mSeniorCfgSaveFlag)     // save clicked
        {
            if (!mSeniorHideApnFlag)  // if hideApn is false
            {
                QDomElement apnElement = cfgXml.createElement("APN");

                QDomElement yysElement = cfgXml.createElement("network");// 运营商
                apnElement.appendChild(yysElement);
                yysElement.appendChild(cfgXml.createTextNode(mSeniorYys));

                QDomElement jrdElement = cfgXml.createElement("apn"); // 接入点
                apnElement.appendChild(jrdElement);
                jrdElement.appendChild(cfgXml.createTextNode(mSeniorJrd));

                QDomElement mccElement = cfgXml.createElement("mcc");
                apnElement.appendChild(mccElement);
                mccElement.appendChild(cfgXml.createTextNode(mSeniorMcc));

                QDomElement mncElement = cfgXml.createElement("mnc");
                apnElement.appendChild(mncElement);
                mncElement.appendChild(cfgXml.createTextNode(mSeniorMnc));

                QDomElement nameElement = cfgXml.createElement("user");
                apnElement.appendChild(nameElement);
                nameElement.appendChild(cfgXml.createTextNode(mSeniorUserName));

                QDomElement passwdElement = cfgXml.createElement("password");
                apnElement.appendChild(passwdElement);
                passwdElement.appendChild(cfgXml.createTextNode(mSeniorPassword));

                parameterElement.appendChild(apnElement);
            }

            if (!mSeniorSystimeHideFlag) // hidesystime is false
             {
                QDomElement systimeElement = cfgXml.createElement("systemtime");
                systimeElement.appendChild(cfgXml.createTextNode(mSeniorSystemTime));
                parameterElement.appendChild(systimeElement);
            }
            if (mSeniorAutoAcquireFlag)  // Auto Acquire IP ...
            {
                QDomElement ipElement = cfgXml.createElement("IP");
                QDomElement typeElement = cfgXml.createElement("type");
                typeElement.appendChild(cfgXml.createTextNode("0"));
                ipElement.appendChild(typeElement);
                parameterElement.appendChild(ipElement);
            }
            else  // manual
            {
                QDomElement ipElement = cfgXml.createElement("IP");

                QDomElement typeElement = cfgXml.createElement("type");
                typeElement.appendChild(cfgXml.createTextNode("1"));
                ipElement.appendChild(typeElement);

                QDomElement ipAddressElement = cfgXml.createElement("ip");
                ipAddressElement.appendChild(cfgXml.createTextNode(mSeniorIpAddress));
                ipElement.appendChild(ipAddressElement);

                QDomElement subnetMaskElement = cfgXml.createElement("netmask");
                subnetMaskElement.appendChild(cfgXml.createTextNode(mSeniorSubNetMask));
                ipElement.appendChild(subnetMaskElement);

                QDomElement defaultGateWayElement = cfgXml.createElement("route");
                defaultGateWayElement.appendChild(cfgXml.createTextNode(mSeniorDefaultGateWay));
                ipElement.appendChild(defaultGateWayElement);

                QDomElement dnsServiceElement = cfgXml.createElement("dns");
                dnsServiceElement.appendChild(cfgXml.createTextNode(mSeniorDnsServer));
                ipElement.appendChild(dnsServiceElement);
                parameterElement.appendChild(ipElement);
            }
        }
        rootElement.appendChild(parameterElement);
    }
    QString strPath = mUsbPath + "\\update\\" + "mediascreen.xml";
    QString tmpDstString = GetFilePath(strPath);
    QDir tmpDstDir;
    if(!tmpDstDir.mkpath(tmpDstString))
    {
        IDE_TRACE();
        return false;
    }

    QFile xmlFile(strPath);
    if(!xmlFile.open(QIODevice::WriteOnly))
    {
        return false;
    }
    QTextStream out(&xmlFile);
    out.setCodec("UTF-8");
    cfgXml.save(out, 4, QDomNode::EncodingFromTextStream);
    xmlFile.close();
    return true;
}

bool ConfigureHolder::delDir(const QString path)
{
    qDebug()<<__PRETTY_FUNCTION__<<"is call ";
    if (path.isEmpty())
    {
        return false;
    }
    QDir dir(path);
    if (!dir.exists())
    {
        qDebug()<<"path is not exists";
        return true;
    }
    dir.setFilter(QDir::AllEntries | QDir::NoDotAndDotDot); //设置过滤
    QFileInfoList fileList = dir.entryInfoList(); // 获取所有的文件信息
    foreach (QFileInfo file, fileList) //遍历文件信息
    {
        if (file.isFile())
        { // 是文件，删除
            file.dir().remove(file.fileName());
        }
        else
        { // 递归删除
            delDir(file.absoluteFilePath());
        }
    }
    return dir.rmpath(dir.absolutePath()); // 删除文件夹
}

void ConfigureHolder::orderFileAndCopy(QString dir)
{
    if (!(mResourceVideoSelectFlag) && (!mResourceAudioSelectFlag)
        && (!mResourcePictureSelectFlag)) // all is false return
    {
        qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<"multiMedia has no choice";
        return;
    }
    QString usbdir  = dir + "\\update\\multimedia\\";

    if (mResourceVideoSelectFlag)
    {
        IDE_TRACE_STR(mResourceVideoPath);
        QFileInfo videoInfo(mResourceVideoPath);
        if(!videoInfo.exists())
        {
            IDE_TRACE();
            return;
        }
        QString dstName = "0." + videoInfo.suffix();
        IDE_TRACE_STR(usbdir + dstName);
        copyReourceFile(mResourceVideoPath, usbdir + dstName);
    }
    else if (mResourceAudioSelectFlag)
    {
        IDE_TRACE_STR(mResourceAudioPath);
        QFileInfo videoInfo(mResourceAudioPath);
        if(!videoInfo.exists())
        {
            IDE_TRACE();
            return;
        }
        QString dstName = "0." + videoInfo.suffix();
        IDE_TRACE_STR(usbdir + dstName);
        copyReourceFile(mResourceAudioPath, usbdir + dstName);
    }
    else if (mResourcePictureSelectFlag)
    {
        for (int i = 0; i < mResourcePictureList1.count(); ++i)
        {
            QString pa = mResourcePictureList1.at(i);
            QFileInfo imageInfo(pa);
            QString dstName = QString("%1.%2").arg(i).arg(imageInfo.suffix());
            copyReourceFile(pa, usbdir + dstName);
        }
    }
}

bool ConfigureHolder::copyReourceFile(QString src, QString dst)
{
    if (0 == src.compare(dst, Qt::CaseInsensitive))
    {
        return true;
    }

    QFileInfo tmpSrcFileInfo(src);
    if (!tmpSrcFileInfo.isFile())
    {
        qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__;
        return false;
    }
    QString tmpDstString = GetFilePath(dst);
    if (tmpDstString.isEmpty())
    {
        qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__;
        return false;
    }
    QDir tmpDstDir;
    if (!tmpDstDir.mkpath(tmpDstString))
    {
        qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<tmpDstString;
        return false;
    }

    bool flag = false;
    qint64 tmpSize = tmpSrcFileInfo.size();

    if (tmpSize > D_FILE_10M)
    {
        flag = false;
        qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"file > 10M";
        QFile tmpSrcFile(src);
        QFile tmpDstFile(dst);
        if (!tmpSrcFile.open(QIODevice::ReadOnly))
        {
            qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"open error!";
            return false;
        }
        if (!tmpDstFile.open(QIODevice::WriteOnly))
        {
            qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"open error!";
            return false;
        }

        qint64 count = 0;
        qreal copyProgress = 0.0;
        qreal pro = 0.0;

        while (!tmpSrcFile.atEnd())
        {
            QByteArray ba = tmpSrcFile.read(D_FILE_PER_BUFFER);
            tmpDstFile.write(ba);
            count += ba.size();
            pro = count / (qreal)tmpSize;
            if (pro - copyProgress >= 0.01)
            {
                emit copyFileProgress(pro*100);
            }
            if (pro == 1.0)
            {
                emit copyFileProgress(100);
                pro = 0.0;
            }
            QCoreApplication::processEvents();
        }
        tmpSrcFile.close();
        tmpDstFile.close();
        flag = true;
    }
    else
    {
        flag = QFile::copy(src, dst);
    }
    return flag;
}

QVariant ConfigureHolder::retPicturePath(QString paths)
{
    QStringList tmpList = paths.split("*");
    mResourcePictureList2.clear();
    for (int i = 0; i < tmpList.size(); ++i)
    {
        QString img = tmpList.at(i);
        if (!img.isEmpty())
        {
            mResourcePictureList2.append(img);
        }
    }
    qDebug()<<__PRETTY_FUNCTION__<<"mResourcePictureList2 = "<<mResourcePictureList2;
    return mResourcePictureList2;
}

int ConfigureHolder::judgeString(QString str)
{
    int ret = -1;
    if (str.isEmpty())
    {
        ret = 0;
        qDebug()<<__PRETTY_FUNCTION__<<"ret = "<< ret <<" isEmpty";
        return ret;
    }
    else
    {
        for (int i = 0; i < str.length(); i++)
        {
            if (QChar(' ') != str.at(i)) // 不全为空格
            {
                ret = 2;
                qDebug()<<__PRETTY_FUNCTION__<<"ret = "<< ret <<" no all Space";
                return ret;
            }
            else
            {
                if (i == str.length() - 1)  // 全部为空格
                {
                    ret = 1; // 全部为空格
                    qDebug()<<__PRETTY_FUNCTION__<<"ret = "<< ret <<"all Space";
                    return ret;
                }
            }
        }
    }
    return ret;
}








