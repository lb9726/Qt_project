﻿#ifndef CONGFIGUREHOLDER_H
#define CONGFIGUREHOLDER_H

#include <QObject>
#include <QStringList>
#include <QVariant>

class ConfigureHolder : public QObject
{
    Q_OBJECT

public:
    explicit ConfigureHolder(QObject *parent = 0);
    QString GetFilePath(QString pFilePath);
    QString toWindwosPath(QString path);

public slots:

    void setUsbPath(const QString &usbPath);
    // parameterConfig model
    void setResetFlag(bool value);
    void setParameterCfgSaveFlag(bool parameterCfgSaveFlag);   
    void setParaBrightnessOrVolumeChanged(bool parameterBrightnessOrVolumeChanged);
    void setParaHideDateTimeFlag(bool paraHideDateTimeFlag);
    void setParaBrightness(int paraBrightness);
    void setParaVolume(int paraVolume);
    void setParaYearFormat(bool paraDateTimeFormat);
    void setParaTimeFormat24(bool paraTimeFormat24);

    // Resource Config model
    void setResourceCfgSaveFlag(bool resourceCfgSaveFlag);
    void setResourceVideoSelectFlag(bool resourceVideoSelectFlag);
    void setResourceAudioSelectFlag(bool resourceAudioSelectFlag);
    void setResourcePictureSelectFlag(bool resourcePictureSelectFlag);
    void setResourceFullScreenFlag(bool resourceFullScreenFlag);
    void setResourceVideoPath(const QString &resourceVideoPath);
    void setResourceAudioPath(const QString &resourceAudioPath);
    void setResourcePicturePath(const QString &resourcePicturePath);
//    void setResourcePictureList1(const QStringList &resourcePictureList);
//    void setResourcePictureList2(const QStringList &resourcePictureList2);
    void setResourcePictureIntervalSecond(int resourcePictureIntervalSecond);
    void setResourceScrollTextShowFlag(bool resourceScrollTextShowFlag);
    void setResourceTitletShowFlag(bool resourceTitletShowFlag);
    void setResourceScrollText(const QString &resourceScrollText);
    void setResourceTitleText(const QString &resourceTitleText);

    // seniorconfig model
    void setSeniorCfgSaveFlag(bool seniorCfgSaveFlag);
    void setSeniorHideApnFlag(bool seniorHideApnFlag);
    void setSeniorContry(const QString &seniorContry);
    void setSeniorYys(const QString &seniorYys);
    void setSeniorJrd(const QString &seniorJrd);
    void setSeniorUserName(const QString &seniorUserName);
    void setSeniorPassword(const QString &seniorPassword);
    void setSeniorMcc(const QString &seniorMcc);
    void setSeniorMnc(const QString &seniorMnc);
    void setSeniorSystimeHideFlag(bool seniorSystimeHideFlag);
    void setSeniorSystemTime(const QString &seniorSystemTime);
    void setSeniorAutoAcquireFlag(bool seniorAutoAcquireFlag);
    void setSeniorIpAddress(const QString &seniorIpAddress);
    void setSeniorSubNetMask(const QString &seniorSubNetMask);
    void setSeniorDefaultGateWay(const QString &seniorDefaultGateWay);
    void setSeniorDnsServer(const QString &seniorDnsServer);

signals:
    void copyFileProgress(int pro);
    void isFullScreenChanges(bool isfull);
    void sigPreviewLayoutChange(QString pLayout);

public slots:
    void onSigPreviewLayoutChange(QString pLayout);
    void onIsFullScreenSignal(bool isflag);

    bool createXml();
    void clearParameters();

    bool delDir(const QString path);
    void orderFileAndCopy(QString dir);
    bool copyReourceFile(QString src, QString dst);

    QVariant retPicturePath(QString paths);
    int judgeString(QString str);

private:
    ///是否重置设备默认资源配置
    QString mUsbPath;
    bool mResetFlag;

    // parameterConfig model
    bool mParameterCfgSaveFlag;    // select save is true
    bool mParaBrightnessOrVolumeChanged; //
    int mParaBrightness;
    int mParaVolume;
    bool mParaHideDateTimeFlag;    // true is hide dateTime
    bool mParaYearFormat;
    bool mParaTimeFormat24;         // true is 24 else is 12

    // Resource Config model
    bool mResourceCfgSaveFlag;          // select save is true
    bool mResourceVideoSelectFlag;      // video Selected
    bool mResourceAudioSelectFlag;      // music is Selected
    bool mResourcePictureSelectFlag;    // picture is selected
    bool mResourceFullScreenFlag;       // fullScreen is true
    QString mResourceVideoPath;
    QString mResourceAudioPath;
    QString mResourcePicturePath;
    QStringList mResourcePictureList1;
    QStringList mResourcePictureList2;
    int mResourcePictureIntervalSecond;  // interval second default 3s
    bool mResourceScrollTextShowFlag;
    bool mResourceTitletShowFlag;
    QString mResourceScrollText;
    QString mResourceTitleText;

    // seniorconfig model
    bool mSeniorCfgSaveFlag;   // select save is true
    bool mSeniorHideApnFlag;   // true is hide
    QString mSeniorContry;
    QString mSeniorYys;
    QString mSeniorJrd;
    QString mSeniorUserName;
    QString mSeniorPassword;
    QString mSeniorMcc;
    QString mSeniorMnc;
    bool mSeniorSystimeHideFlag;  // true is hide;
    QString mSeniorSystemTime;

    bool mSeniorAutoAcquireFlag;  // auto is true;
    QString mSeniorIpAddress;
    QString mSeniorSubNetMask;
    QString mSeniorDefaultGateWay;
    QString mSeniorDnsServer;

};

#endif // CONGFIGUREHOLDER_H
