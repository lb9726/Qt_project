#include "pchelper.h"
#include "define.h"


PcHelper::PcHelper(QObject *parent) : QObject(parent)
{
    isConnected = false;
}


bool PcHelper::init(){
    m_comPort = new QSerialPort(this);
    m_comPort->setPortName("/dev/ttyGS0");
    if(m_comPort->open(QIODevice::ReadWrite))
    {
        //设置波特率
        m_comPort->setBaudRate(115200);
        //设置数据位
        m_comPort->setDataBits(QSerialPort::Data8);
        //设置校验位
        m_comPort->setParity(QSerialPort::NoParity);
        //设置流控制
        m_comPort->setFlowControl(QSerialPort::NoFlowControl);
        //设置停止位
        m_comPort->setStopBits(QSerialPort::OneStop);
        connect(m_comPort,&QSerialPort::readyRead,this,&PcHelper::readyRead);
        return true;
    }
    else
    {
        IDE_TRACE();
        return false;
    }

}

void PcHelper::startWork(){

}

void PcHelper::readyRead(){
    ///IDE_TRACE();
    QByteArray ba = m_comPort->readAll();
    ParseBuffer(ba);
}

quint32 PcHelper::ParseBuffer(QByteArray& buffer)
{
   /// IDE_TRACE();
    if(buffer.isEmpty())
    {
        buffer.clear();
        return 0;
    }
    quint32 tmpCount = buffer.count();
    char tmpValue = 0;
    char tmpValueNext = 0;
    quint32 i = 0;
    ///qDebug()<<"ParseBuffer :" <<buffer;
    while(i < tmpCount)
    {
        tmpValue = buffer.at(i++);
        if(D_STX == tmpValue){
            m_FrameBuffer.clear();
        }else if(D_ETX == tmpValue){
            ParseFrame();
        }else{
            if(tmpValue != D_ESC){
                m_FrameBuffer.append(tmpValue);
            }else{
                tmpValueNext = buffer.at(i++);
                if(tmpValueNext == D_STX_ESC)
                    m_FrameBuffer.append(D_STX);
                else if(tmpValueNext == D_STX_ETX)
                    m_FrameBuffer.append(D_ETX);
                else if(tmpValueNext == D_ESC_ESC)
                    m_FrameBuffer.append(D_ESC);
            }
        }
    }
    buffer.clear();
    return 1;
}

quint32 PcHelper::ParseFrame()
{
    if(m_FrameBuffer.count() <= 2)
    {
       // qDebug()<<"m_FrameBuffer:"<<m_FrameBuffer;
        m_FrameBuffer.clear();
        return 0;
    }
    char frameType = m_FrameBuffer.at(0);
    //char crc = m_FrameBuffer.at(m_FrameBuffer.count()-1);
    m_FrameBuffer.chop(1);//去掉CRC校验字节
    quint32 tmpDataCount = m_FrameBuffer.count();

    return 1;
}
