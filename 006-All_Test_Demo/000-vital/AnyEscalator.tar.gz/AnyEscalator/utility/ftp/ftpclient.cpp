#include <QSettings>
#include <QUrl>

#include "ftpclient.h"
#include "qftp.h"
#include "qurlinfo.h"
#include "../../define.h"

FtpClient::FtpClient(QObject *parent) : QObject(parent)
{
    ftp = NULL;
    networkSession = NULL;
    m_isConnected =false;
    fileGet = NULL;
    filePut = NULL;
    isUploading = false;

    m_ServerUrl = QUrl();
    m_loginName = "";
    m_passwd = "";

}

bool FtpClient::isConnected(){
    return m_isConnected;
}

void FtpClient::init(QUrl url,QString loginName,QString passwd){
    m_ServerUrl = url;
    m_loginName = loginName;
    m_passwd = passwd;
}

void FtpClient::startWork()
{
    if (ftp) {
        ftp->abort();
        ftp->deleteLater();
        ftp = 0;
        m_isConnected = false;
        emit sigConnected(m_isConnected);
        return;
    }

    if (!networkSession || !networkSession->isOpen()) {
        if (manager.capabilities() & QNetworkConfigurationManager::NetworkSessionRequired) {
            if (!networkSession) {
                // Get saved network configuration
                QSettings settings(QSettings::UserScope, QLatin1String("Trolltech"));
                settings.beginGroup(QLatin1String("QtNetwork"));
                const QString id = settings.value(QLatin1String("DefaultNetworkConfiguration")).toString();
                settings.endGroup();

                // If the saved network configuration is not currently discovered use the system default
                QNetworkConfiguration config = manager.configurationFromIdentifier(id);
                if ((config.state() & QNetworkConfiguration::Discovered) !=
                        QNetworkConfiguration::Discovered) {
                    config = manager.defaultConfiguration();
                }

                networkSession = new QNetworkSession(config, this);
                connect(networkSession, SIGNAL(opened()), this, SLOT(connectToFtpTest()));
                connect(networkSession, SIGNAL(error(QNetworkSession::SessionError)), this, SLOT(enableConnectButton()));
            }
            IDE_TRACE_STR(tr("Opening network session."));
            networkSession->open();
            return;
        }
    }

    connectToFtp();
}

void FtpClient::connectToFtp()
{
    if (ftp) {
        ftp->abort();
        ftp->deleteLater();
        ftp = NULL;
        m_isConnected = false;
    }

    ftp = new QFtp(this);
    connect(ftp, SIGNAL(commandFinished(int,bool)),this, SLOT(ftpCommandFinished(int,bool)));
    connect(ftp, SIGNAL(listInfo(QUrlInfo)),this, SLOT(addToList(QUrlInfo)));
    connect(ftp, SIGNAL(dataTransferProgress(qint64,qint64)),this, SLOT(updateDataTransferProgress(qint64,qint64)));

    //QUrl url("ftp://127.0.0.7/");
    ftp->connectToHost(m_ServerUrl.host(), m_ServerUrl.port(21));
    ftp->login(m_loginName, m_passwd);
}

bool FtpClient::getFile( QString fileName)
{
    fileGet = new QFile(fileName);
    if (!fileGet->open(QIODevice::WriteOnly)) {
        qDebug()<<"Unable to save the file %1: %2.";
        delete fileGet;
        return false;
    }
    ftp->get(fileName, fileGet);
    return true;
}

bool FtpClient::getFile(QString localName,QString remoteName)
{
    IDE_TRACE_STR(localName);
    IDE_TRACE_STR(remoteName);
    fileGet = new QFile(localName);
    if (!fileGet->open(QIODevice::WriteOnly)) {
        IDE_TRACE_STR(QString("Unable to open the file %1.").arg(localName));
        delete fileGet;
        return false;
    }
    ftp->get(remoteName, fileGet);
    return true;
}

bool FtpClient::putFile( QString fileName)
{
    filePut = new QFile(fileName);
    if (!filePut->open(QIODevice::ReadOnly)) {
        IDE_TRACE_STR(QString("Unable to open the file %1.").arg(fileName));
        delete filePut;
        return false;
    }
    ftp->put(filePut,fileName);
    IDE_TRACE();
    return true;
}

bool FtpClient::putFile( QString localName,QString remoteName)
{
    filePut = new QFile(localName);
    if (!filePut->open(QIODevice::ReadOnly)) {
        IDE_TRACE_STR(QString("Unable to open the file %1.").arg(localName));
        delete filePut;
        return false;
    }
    ftp->put(filePut,remoteName);
    return true;
}

void FtpClient::cancelDownload()
{
    if(ftp)
        ftp->abort();
    if (fileGet->exists()) {
        fileGet->close();
        fileGet->remove();
    }
    delete fileGet;
}

void FtpClient::ftpCommandFinished(int, bool error)
{
    if (ftp->currentCommand() == QFtp::ConnectToHost) {
        if (error) {
            IDE_TRACE_STR("Unable to connect to the FTP server.Please check that the host name is correct.");
            startWork();
            return;
        }
        IDE_TRACE_STR("Logged onto succeed");
        ftp->cd("pub");
        ftp->list();

    }
    if (ftp->currentCommand() == QFtp::Login){
        ftp->list();
        m_isConnected = true;
        emit sigConnected(m_isConnected);
    }if (ftp->currentCommand() == QFtp::Get) {
        if (error) {
            IDE_TRACE_STR(QString("Download File %1 Error.").arg(fileGet->fileName()));
            fileGet->close();
            fileGet->remove();
            sigGetFileFinished(fileGet->fileName(),false);
        } else {
            IDE_TRACE_STR(QString("Downloaded %1 Succeed.").arg(fileGet->fileName()));
            fileGet->close();
            sigGetFileFinished(fileGet->fileName(),true);
        }
        IDE_TRACE();
        delete fileGet;
        fileGet = NULL;
    } else if (ftp->currentCommand() == QFtp::List) {
//        if (isDirectory.isEmpty()) {
//            IDE_TRACE_STR("Empty Folder");
//        }
    }else if (ftp->currentCommand() == QFtp::Put) {
        filePut->close();
        if (error) {
            IDE_TRACE_STR(QString("Upload File %1 Error.").arg(filePut->fileName()));
            emit sigPutFileFinished(filePut->fileName(),false);
            uploadFileStatus(filePut->fileName(),false);
        }else{
            IDE_TRACE_STR(QString("Upload %1 Succeed.").arg(filePut->fileName()));
            emit sigPutFileFinished(filePut->fileName(),true);
            uploadFileStatus(filePut->fileName(),true);
        }
        delete filePut;
        filePut = NULL;
    }else if (ftp->currentCommand() == QFtp::Mkdir) {
        if (error) {
            IDE_TRACE_STR(QString("mkdir %1 Error."));
            emit sigMkdirFailed("");
        }else{
            IDE_TRACE_STR(QString("mkdir %1 Succeed."));
        }

    }
}

void FtpClient::addToList(const QUrlInfo &urlInfo)
{
    //Q_UNUSED(urlInfo);
    IDE_TRACE_STR(urlInfo.name());
    //    IDE_TRACE_STR(urlInfo.name());
    //    IDE_TRACE_STR(urlInfo.size());
    //    IDE_TRACE_STR(urlInfo.owner());
    //    IDE_TRACE_STR(urlInfo.group());
    //    IDE_TRACE_STR(urlInfo.lastModified().toString("MMM dd yyyy"));
    //    isDirectory[urlInfo.name()] = urlInfo.isDir();
}

void FtpClient::cdToDir(QString dirName){
    if(dirName.isEmpty())
        ftp->cd("/");
    else
        ftp->cd("/"+dirName);
}

void FtpClient::cdToParent()
{
    isDirectory.clear();
    currentPath = currentPath.left(currentPath.lastIndexOf('/'));
    if (currentPath.isEmpty()) {
        ftp->cd("/");
    } else {
        ftp->cd(currentPath);
    }
    ftp->list();
    //ftp->put()
}

void FtpClient::updateDataTransferProgress(qint64 readBytes,qint64 totalBytes)
{
    Q_UNUSED(readBytes);
    Q_UNUSED(totalBytes);
    //progressDialog->setMaximum(totalBytes);
    //progressDialog->setValue(readBytes);
    //qDebug()<<totalBytes<<","<<readBytes<<endl;
}



bool FtpClient::canUploadFile()
{
    if(!m_isConnected)
        return false;
    if(!isUploading){
        m_uploadList.clear();
    }

    return !isUploading;
}

bool FtpClient::appendUploadFile(QString filePath)
{
    if(filePath.startsWith("/")){
        filePath = filePath.right(filePath.count()-1);
    }
    m_uploadList.append(filePath);
    return true;
}

bool FtpClient::startUploadFile(QString dirPath)
{
    isUploading = true;
    m_uploadDirPath = dirPath;
    if(!m_uploadDirPath.endsWith("/")){
        m_uploadDirPath.append("/");
    }

    if(m_uploadList.isEmpty()){
        return false;
    }
    putOneFile(m_uploadList.first());
    return true;
}

void FtpClient::uploadFileStatus(QString fileName,bool isSucceed)
{
    if(!isSucceed){
        if(fileName.endsWith(m_currentUploadFileName)){
            IDE_TRACE();
            m_uploadList.clear();
            emit sigUploadRawFileCompelete(false);
        }else{
            IDE_TRACE();
            m_uploadList.clear();
            emit sigUploadRawFileCompelete(false);
        }
    }else{
        //m_uploadList.removeOne(m_currentUploadFileName);
        m_uploadList.takeFirst();
        if(m_uploadList.isEmpty()){
            emit sigUploadRawFileCompelete(true);
        }else{
            putOneFile(m_uploadList.first());
        }
    }
}

bool FtpClient::putOneFile(QString fileReletivePath)
{
    QStringList list = fileReletivePath.split("/");
    if(list.count()!=3){
        return false;
    }else{
        ftp->mkdir(list.at(0));
        ftp->mkdir(list.at(1));
    }
    m_currentUploadFileName = list.at(2);
    return putFile(m_uploadDirPath+fileReletivePath,m_currentUploadFileName);

}
