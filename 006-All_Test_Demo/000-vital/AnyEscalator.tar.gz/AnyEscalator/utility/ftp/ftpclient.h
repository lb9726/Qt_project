#ifndef FTPCLIENT_H
#define FTPCLIENT_H

#include <QObject>
#include <QNetworkConfigurationManager>
#include <QNetworkSession>
#include <QNetworkConfiguration>
#include <QFile>
#include <QUrl>

class QFtp;
class QUrlInfo;

class FtpClient : public QObject
{
    Q_OBJECT
public:
    explicit FtpClient(QObject *parent = 0);
    bool isConnected();

signals:
    void sigConnected(bool flag);
    void sigGetFileFinished(QString fileName,bool isSucceed);
    void sigPutFileFinished(QString fileName,bool isSucceed);

    void sigMkdirFailed(QString info);

    void sigUploadRawFileCompelete(bool isSucceed);
public slots:
    void startWork();
    void connectToFtp();

    void cancelDownload();    

    void ftpCommandFinished(int commandId, bool error);
    void updateDataTransferProgress(qint64 readBytes,qint64 totalBytes);

    void addToList(const QUrlInfo &urlInfo);

    void cdToParent();
    void cdToDir(QString dirName="");

    bool getFile(QString localName, QString remoteName);
    bool getFile(QString fileName);
    bool putFile(QString localName);
    bool putFile(QString localName,QString remoteName);

public slots:
    bool canUploadFile();
    bool appendUploadFile(QString filePath);
    bool startUploadFile(QString dirPath);

    void uploadFileStatus(QString fileName,bool isSucceed);
public:
    bool m_isConnected;
    QHash<QString, bool> isDirectory;
    QString currentPath;
    QFtp *ftp;
    QFile *fileGet;
    QFile *filePut;

    QNetworkSession *networkSession;
    QNetworkConfigurationManager manager;

    bool isUploading;
    QString m_uploadDirPath;
    QString m_currentUploadFileName;
    QStringList m_uploadList;

    QUrl m_ServerUrl;
    QString m_loginName;
    QString m_passwd;
    bool putOneFile(QString fileReletivePath);
    void init(QUrl url, QString loginName, QString passwd);
};

#endif // FTPCLIENT_H
