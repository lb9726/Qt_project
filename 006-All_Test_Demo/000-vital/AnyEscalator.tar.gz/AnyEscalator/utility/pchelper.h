#ifndef PCHELPER_H
#define PCHELPER_H

#include <QObject>
#include <QWebSocket>
#include <QWebSocketServer>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMutex>
#include <QThread>
#include <QSerialPort>

class PcHelper : public QObject
{
    Q_OBJECT
public:
    explicit PcHelper(QObject *parent = 0);
    bool init();
    void readyRead();
    quint32 ParseBuffer(QByteArray &buffer);
    quint32 ParseFrame();

signals:
    void sigConnect();
    void sigDisconnect();
    void helperMsg(QJsonObject jsonObj);
public slots:
    void startWork();

public:
    bool isConnected;
    QSerialPort  *m_comPort;
    QByteArray  m_FrameBuffer;
};

#endif // PCHELPER_H
