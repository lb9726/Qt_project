#include "loggerconfigure.h"

LoggerConfigure::LoggerConfigure(QObject *parent) : QObject(parent)
{
    Logger &log = Logger::instance();
    log.setLoggingLevel(TraceLevel);
    QString  filePath = "any_escalator_logger";
    DestinationPtr destinationPtr = DestinationFactory::MakeFileDestination(filePath,EnableLogRotation,
                                                                            MaxSizeBytes(10240),MaxOldLogCount(4));
    log.addDestination(destinationPtr);
}

