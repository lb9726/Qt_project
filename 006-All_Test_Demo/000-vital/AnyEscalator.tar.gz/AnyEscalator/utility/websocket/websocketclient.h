#ifndef WEBSOCKETCLIENT_H
#define WEBSOCKETCLIENT_H

#include <QObject>
#include <QWebSocket>
#include <QTimer>
#include <QDebug>
#include <QJsonParseError>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMutex>
#include <QThread>
#include <QNetworkConfigurationManager>
#include <QNetworkInterface>
#define TEXT_WEBSOCKET_MSG
//#define BINARY_WEBSOCKET_MSG

class WebSocketClient : public QObject
{
    Q_OBJECT
public:
    explicit WebSocketClient(QObject *parent = 0);

    void init(QString serverIP,QString port,QString url);
    void init(QString url);


    bool alive();
    void onConnected();
    void disconnected();
    void reConnectTimeout();
    void networkmanageTimeout();
    void restSlt(QAbstractSocket::SocketError err);
    //void binaryFrameReceived(QByteArray frame, bool isLastFrame);
    void stateChangedSlt(QAbstractSocket::SocketState state);
    void buildJson(const QByteArray &message);
signals:
    void sigWebSocketConnected();
    void sigWebSocketDisconnected();

    void dtuMsg(QJsonObject jsonObj);
    void sigtextMessageArrived(QString message);
    void sigbinaryMessageArrived(QString message);
public slots:
    void connectToServer();
    //bool sendMessage(const QString &message);
    bool sendMessage(QByteArray message);
    bool sendJson(QJsonObject jsonObj);

    void startWork();

private slots:
    void binaryMsgReceived(const QByteArray &message);
    void textMessageReceived(const QString &message);
public:
    QMutex m_Mutex;
    QByteArray receiveBuffer;
    QWebSocket *webSocketClient;
    QUrl m_serverUrl;
    volatile bool isConnected;
    QTimer* m_ReConnectTimer;
    QTimer* m_networkManagerTimer;
    volatile bool isEthnetUp;

    volatile bool isOpeningConnecting;
    ///json
    QJsonParseError m_JsonError;
    QJsonDocument m_JsonDoc;
    QThread *webSocketThread;
    QNetworkConfigurationManager* m_networkConfigurationManager;
    //QNetworkConfiguration* m_networkConfiguration;
    void onlineStateChanged(bool isOnline);
    void webdisconnected();
    bool isConnectedToNetwork();
};

#endif // WEBSOCKETCLIENT_H
