#include "websocketclient.h"
#include "../../define.h"

WebSocketClient::WebSocketClient(QObject *parent) : QObject(parent)
{
    m_ReConnectTimer = new QTimer(this);
    m_ReConnectTimer->setInterval(500);
    connect(m_ReConnectTimer,&QTimer::timeout,this,&WebSocketClient::reConnectTimeout);
    isConnected = false;
    webSocketClient = NULL;
    webSocketThread = NULL;

    m_networkManagerTimer = new QTimer(this);
    m_networkManagerTimer->setInterval(500);
    connect(m_networkManagerTimer,&QTimer::timeout,this,&WebSocketClient::networkmanageTimeout);
}

void WebSocketClient::init(QString serverIP, QString port, QString url)
{
    Q_UNUSED(serverIP);
    Q_UNUSED(port);
    Q_UNUSED(url);
}

void WebSocketClient::init(QString url)
{
    webSocketThread = new QThread();
    m_serverUrl = QUrl(url);
    this->moveToThread(webSocketThread);
    webSocketThread->start();
}


void WebSocketClient::startWork()
{
    m_networkConfigurationManager = new QNetworkConfigurationManager();
    //m_networkConfiguration = m_networkConfigurationManager->defaultConfiguration();
    isEthnetUp = m_networkConfigurationManager->isOnline();
    connect(m_networkConfigurationManager, &QNetworkConfigurationManager::onlineStateChanged, this, &WebSocketClient::onlineStateChanged);
    connectToServer();
    m_networkManagerTimer->start();

}

void WebSocketClient::connectToServer(){

    if(webSocketClient){
        disconnect(webSocketClient, &QWebSocket::connected, this, &WebSocketClient::onConnected);
        disconnect(webSocketClient, &QWebSocket::disconnected, this, &WebSocketClient::webdisconnected);
        disconnect(webSocketClient, &QWebSocket::textMessageReceived, this, &WebSocketClient::textMessageReceived);

        webSocketClient->abort();
        webSocketClient->deleteLater();
        webSocketClient = NULL;
    }

    webSocketClient = new QWebSocket("",QWebSocketProtocol::Version13);
    connect(webSocketClient, &QWebSocket::connected, this, &WebSocketClient::onConnected);
    connect(webSocketClient, &QWebSocket::disconnected, this, &WebSocketClient::webdisconnected);
    connect(webSocketClient, &QWebSocket::stateChanged, this, &WebSocketClient::stateChangedSlt);

    connect(webSocketClient, &QWebSocket::textMessageReceived, this, &WebSocketClient::textMessageReceived);

    webSocketClient->open(m_serverUrl);
    isOpeningConnecting = true;

}

bool WebSocketClient::alive(){
    return isConnected;
}

void WebSocketClient::onConnected(){
    IDE_TRACE();
    if(!isConnected){
        IDE_TRACE();
        isConnected = true;
        emit sigWebSocketConnected();
        m_ReConnectTimer->stop();
    }
    isOpeningConnecting = false;
}

void WebSocketClient::disconnected(){    
    if(isConnected){
        IDE_TRACE();
        isConnected = false;
        emit sigWebSocketDisconnected();
    }
    m_ReConnectTimer->start();
    isOpeningConnecting = false;
    IDE_TRACE();
}

void WebSocketClient::webdisconnected(){
    IDE_TRACE();
    this->disconnected();
}

void WebSocketClient::restSlt(QAbstractSocket::SocketError err){
    IDE_TRACE_STR("restSlt");
    this->disconnected();
}

void WebSocketClient::stateChangedSlt(QAbstractSocket::SocketState state){
    ///IDE_TRACE_STR("stateChangedSlt");
    //webdisconnected();
}

void WebSocketClient::onlineStateChanged(bool isOnline){
    //    if(isOnline){
    //        IDE_TRACE();
    //        this->reConnectTimeout();
    //    }else{
    //        IDE_TRACE();
    //        this->disconnected();
    //    }
}

void WebSocketClient::reConnectTimeout(){
    if(isConnectedToNetwork()){
        if(!isConnected && !isOpeningConnecting){
            IDE_TRACE();
            this->connectToServer();
        }
    }
}

void WebSocketClient::networkmanageTimeout(){
    bool flag = isConnectedToNetwork();///m_networkConfigurationManager->isOnline();
    //IDE_TRACE();
    if(flag != isEthnetUp){
        isEthnetUp = flag;
        IDE_TRACE();
        if(isEthnetUp && !isConnected && !isOpeningConnecting){
             IDE_TRACE();
            this->connectToServer();
        }else{
            IDE_TRACE();
            this->disconnected();
        }
    }
}

bool WebSocketClient::isConnectedToNetwork()
{
    QList<QNetworkInterface> ifaces = QNetworkInterface::allInterfaces();
    bool isConnected = false;

    for (int i = 0; i < ifaces.count(); i++)
    {
        QNetworkInterface iface = ifaces.at(i);
        if ( iface.flags().testFlag(QNetworkInterface::IsUp)
             && iface.flags().testFlag(QNetworkInterface::IsRunning)
             && !iface.flags().testFlag(QNetworkInterface::IsLoopBack)
              )
        {

            // this loop is important
            for (int j=0; j<iface.addressEntries().count(); j++)
            {
                // we have an interface that is up, and has an ip address
                // therefore the link is present

                // we will only enable this check on first positive,
                // all later results are incorrect
                if (isConnected == false)
                    isConnected = true;
            }
        }

    }

    return isConnected;
}

bool WebSocketClient::sendMessage(QByteArray message){
    //QMutexLocker locker(&m_Mutex);
    if(!isConnected||message.isEmpty()){
        IDE_TRACE();
        return false;
    }
    IDE_TRACE();
    webSocketClient->sendBinaryMessage(message);
    return true;
}

bool WebSocketClient::sendJson(QJsonObject jsonObj)
{
    ///qDebug()<<jsonObj;
    if(!isConnected||jsonObj.isEmpty()){
        //IDE_TRACE();
        return false;
    }
    QJsonDocument doc(jsonObj);
    ///IDE_TRACE();
#ifdef TEXT_WEBSOCKET_MSG

    webSocketClient->sendTextMessage(QString(doc.toJson(QJsonDocument::Compact)));
#endif
#ifdef BINARY_WEBSOCKET_MSG
    webSocketClient->sendBinaryMessage(doc.toJson(QJsonDocument::Compact));
#endif
    return true;
}

void WebSocketClient::binaryMsgReceived(const QByteArray &message){
    buildJson(message);
}

void WebSocketClient::textMessageReceived(const QString &message){
    QByteArray ba;
    ba.append(message);
    buildJson(ba);
}

void WebSocketClient::buildJson(const QByteArray & message){
    m_JsonDoc =QJsonDocument::fromJson(message,&m_JsonError);
    if(m_JsonError.error==QJsonParseError::NoError)
    {
        if(m_JsonDoc.isObject())
        {
            emit dtuMsg(m_JsonDoc.object());
        }
    }
    else
    {
        IDE_TRACE_STR(m_JsonError.errorString());
    }
}
