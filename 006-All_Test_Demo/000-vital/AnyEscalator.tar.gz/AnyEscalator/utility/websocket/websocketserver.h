#ifndef WEBSOCKETSERVER_H
#define WEBSOCKETSERVER_H

#include <QObject>
#include <QWebSocket>
#include <QWebSocketServer>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMutex>
#include <QThread>


class WebSocketServer : public QObject
{
    Q_OBJECT
public:
    explicit WebSocketServer(QObject *parent = 0);
    ~WebSocketServer();

    void init();
signals:
    void closed();
    void sigConnect();
    void sigDisconnect();
    void helperMsg(QJsonObject jsonObj);
public slots:
    void startWork();
    void onNewConnection();
    void socketDisconnected();
    void binaryMessageReceived(const QByteArray &message);
    void buildJson(const QByteArray &message);

    bool sendMessage(const QByteArray &message);
    bool sendJson(const QJsonObject &jsonObj);
public:
    QWebSocketServer *m_pWebSocketServer;
    QWebSocket* m_currentClient;
    QJsonParseError m_JsonError;
    QJsonDocument m_JsonDoc;
    bool isConnected;
    QMutex m_Mutex;
    QThread *m_socketThread;
};

#endif // WEBSOCKETSERVER_H
