#include "websocketserver.h"
#include "../../define.h"

WebSocketServer::WebSocketServer(QObject *parent) : QObject(parent)
{
    isConnected = false;
}

WebSocketServer::~WebSocketServer()
{
    if(m_pWebSocketServer)
        m_pWebSocketServer->close();
}

void WebSocketServer::init(){

    m_pWebSocketServer = new QWebSocketServer("Attribute Server", QWebSocketServer::NonSecureMode, this);
    connect(m_pWebSocketServer, &QWebSocketServer::newConnection,this, &WebSocketServer::onNewConnection);
    connect(m_pWebSocketServer, &QWebSocketServer::closed,this, &WebSocketServer::closed);
    m_currentClient = NULL;

    m_socketThread = new QThread();
    this->moveToThread(m_socketThread);
    m_socketThread->start();
}

void WebSocketServer::startWork(){
    //IDE_TRACE();
    m_pWebSocketServer->listen(QHostAddress::Any, 10800);
}

void WebSocketServer::onNewConnection()
{
    if(m_currentClient){
        m_currentClient->close();
        m_currentClient->deleteLater();
    }
    m_currentClient = m_pWebSocketServer->nextPendingConnection();
    connect(m_currentClient, &QWebSocket::binaryMessageReceived, this, &WebSocketServer::binaryMessageReceived);
    connect(m_currentClient, &QWebSocket::disconnected, this, &WebSocketServer::socketDisconnected);
    isConnected = true;
    emit sigConnect();
    //IDE_TRACE();
}

void WebSocketServer::socketDisconnected()
{
    isConnected = false;
    emit sigDisconnect();
    //IDE_TRACE_STR(m_currentClient->errorString());
}

void WebSocketServer::binaryMessageReceived(const QByteArray &message){
    //IDE_TRACE();
    buildJson(message);
}

void WebSocketServer::buildJson(const QByteArray & message){
    m_JsonDoc =QJsonDocument::fromJson(message,&m_JsonError);
    if(m_JsonError.error==QJsonParseError::NoError)
    {
        if(m_JsonDoc.isObject())
        {
            emit helperMsg(m_JsonDoc.object());
        }
    }else
    {
        IDE_TRACE_STR(m_JsonError.errorString());
    }
}

bool WebSocketServer::sendMessage(const QByteArray &message){
    QMutexLocker locker(&m_Mutex);
    if(!isConnected||message.isEmpty()){
        IDE_TRACE();
        return false;
    }
    m_currentClient->sendBinaryMessage(message);
    return true;
}

bool WebSocketServer::sendJson(const QJsonObject &jsonObj)
{
    ///IDE_TRACE();
    QMutexLocker locker(&m_Mutex);
    //m_Mutex.lock();
    if(!isConnected||jsonObj.isEmpty()){
        IDE_TRACE();
        return false;
    }
    ////IDE_TRACE();
    QJsonDocument doc(jsonObj);
    m_currentClient->sendBinaryMessage(doc.toJson(QJsonDocument::Compact));
    //m_Mutex.unlock();
    return true;
}
