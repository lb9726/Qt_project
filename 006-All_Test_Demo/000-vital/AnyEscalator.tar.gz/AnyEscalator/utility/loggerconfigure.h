#ifndef LOGGERCONFIGURE_H
#define LOGGERCONFIGURE_H

#include <QObject>
#include "QsLog.h"
#include "QsLogDest.h"
using namespace QsLogging;
class LoggerConfigure : public QObject
{
    Q_OBJECT
public:
    explicit LoggerConfigure(QObject *parent = 0);

signals:

public slots:
};

#endif // LOGGERCONFIGURE_H
