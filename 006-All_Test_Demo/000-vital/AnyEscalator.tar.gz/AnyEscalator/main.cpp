#include <QCoreApplication>
#include "engine.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    Engine *engine = new Engine();
    engine->initEngine();
    engine->startDevice();
    int ret = a.exec();
    delete engine;

    return ret;
}
