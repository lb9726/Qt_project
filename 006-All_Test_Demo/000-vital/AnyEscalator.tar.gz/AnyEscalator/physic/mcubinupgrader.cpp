#include "mcubinupgrader.h"

mcuBinUpgrader::mcuBinUpgrader(QObject *parent) : QObject(parent)
{
    binFilePath = "/home/root/mcu.bin";
    bytePerFrame = 64;
}

bool mcuBinUpgrader::isNeedUpgrade()
{
    if(!QFile::exists(binFilePath)){
        return false;
    }

    return true;
}

bool mcuBinUpgrader::bindFile()
{
    if(!QFile::exists(binFilePath)){
        return false;
    }

    QFile file(binFilePath);
    if(!file.open(QFile::ReadOnly)){
        return false;
    }
    mcuBinData = file.readAll();
    totalByteSize = mcuBinData.size();
    currentBytePos = 0;
    currentFrameCount= 0;
    return true;
}

bool mcuBinUpgrader::unbindFile()
{
    mcuBinData.clear();
    totalByteSize = 0;
    currentBytePos = 0;
    currentFrameCount= 0;
    return true;
}

QByteArray mcuBinUpgrader::nextFrame(){
    if(totalByteSize == 0){
        m_currentFrame =  QByteArray();
    }else{
        if(currentBytePos + bytePerFrame < totalByteSize){
            m_currentFrame =  mcuBinData.mid(currentBytePos,bytePerFrame);
            currentBytePos += bytePerFrame;
        }else{
            m_currentFrame =  mcuBinData.right(totalByteSize - currentBytePos);
            currentBytePos = totalByteSize-1;
        }
        currentFrameCount ++;
        return m_currentFrame;
    }
}

QByteArray mcuBinUpgrader::currentFrame(){
    if(totalByteSize == 0){
        m_currentFrame =  QByteArray();
    }

    return m_currentFrame;
}
