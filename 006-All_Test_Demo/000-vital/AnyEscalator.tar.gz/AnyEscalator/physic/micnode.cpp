#include "micnode.h"
#include "define.h"
#include <QtMath>
#include <QDate>
#include <QDir>
#include <QDateTime>
#include <QCoreApplication>
#include <stdio.h>
#include "define.h"

#include "wavheader.h"
#include "logic/datalogger.h"

static snd_pcm_t *handle;
static int open_mode = 0;
static int interleaved = 1;
static char *audiobuf = NULL;
static int avail_min = -1;
static int start_delay = 0;
static int stop_delay = 0;
static int verbose = 0;
static int vumeter = VUMETER_NONE;
static size_t bits_per_sample, bits_per_frame;
static size_t chunk_bytes;
static snd_output_t *logfd;
static int fd = -1;
static off64_t fdcount;

MicNode::MicNode()
{
    m_denominator = pow(pow(2,31),2);//POWER(POWER(2,32)-1,2)

    isDebuging = false;
    m_loggingData = false;


    m_loggingFile = NULL;
    m_rmsFile = NULL;

    m_quietMode = true;
    m_chunk_size = 0;
    m_period_time = 0;
    m_buffer_time = 0;
    m_period_frames = 0;
    m_buffer_frames = 0;

    m_recordTimer = new QTimer();
    connect(m_recordTimer,&QTimer::timeout,this,&MicNode::tiggerRecorder);
    m_recordTimer->setInterval(1000*60*60*2);///2 Hours
}

void MicNode::init()
{

}

void MicNode::startWork()
{
    if(initSnd()){
        m_recordTimer->start();
        start(QThread::HighestPriority);
    }
    ///IDE_TRACE();
}

void MicNode::setFreq(int freq)
{
    Q_UNUSED(freq);
}

void MicNode::tiggerRecorder(){
    triggerWavlogger(QString());
}

void MicNode::triggerWavlogger(QString fileName){
    Q_UNUSED(fileName);
    QString m_fileName = getCurrentHourDir() + QDateTime::currentDateTime().toString("yyyyMMdd_hh_mm_ss_");
    m_fileName += "noise.wav";

    m_loggingFile = new QFile;
    m_loggingFile->setFileName(m_fileName);
    if(!m_loggingFile->open(QIODevice::WriteOnly)){
        IDE_TRACE_STR("Error open output file.");
        m_loggingFile = NULL;
        m_loggingData = false;
        return;
    }else{
        begin_wave(10*globalHwparams.rate*bits_per_frame/8);
        m_loggingData = true;
        m_100msCounter = 0;
        IDE_TRACE_STR("Start Record Wav");
    }
}

void MicNode::sltShiftFile(QString filePath){
    Q_UNUSED(filePath);
    if(m_rmsFile){
        m_rmsFile->close();
        delete m_rmsFile;
        m_rmsFile = NULL;
    }
    QString m_fileName = getCurrentHourFileNameBase()+"noise.csv";
    m_rmsFile = new QFile();
    if(m_rmsFile){
        m_rmsFile->setFileName(m_fileName);
        bool isExist;
        isExist =  m_rmsFile->exists() ? true:false;
        if(!m_rmsFile->open(QIODevice::WriteOnly)){
            delete m_rmsFile;
            m_rmsFile = NULL;
            return ;
        }
        if(!isExist){
            QByteArray ba;
            ba.append(getTimeStamp()+",").append("UpperPitNoiseRMS").append("\r\n");
            m_rmsFile->write(ba,ba.count());
        }
    }else{
        m_rmsFile  = NULL;
    }
}

void MicNode::setDebugMode(bool isDebug){
    IDE_TRACE();
    if(isDebuging != isDebug){
        isDebuging = isDebug;
    }else{
        return;
    }

    if(isDebuging){
        IDE_TRACE();
        if(m_rmsFile){
            m_rmsFile->close();
            delete m_rmsFile;
            m_rmsFile = NULL;
            IDE_TRACE();
        }
    }else{
        IDE_TRACE();
        sltShiftFile("");
    }
    IDE_TRACE();
}

void MicNode::run()
{    
    //off64_t tmp1 = 0;
    //off64_t tmp2 = 0;
    off64_t rest;
    volatile qreal rmsdBFS;
    qint32 tmp;
    initParams();
    ssize_t framePer100ms = 4800*4; ///10s dived to 100 timems, each is 100ms
    do {
        rmsdBFS = 0.0;
        rest = framePer100ms;
        while (rest > 0){
            size_t c = (rest <= (off64_t)chunk_bytes) ? (size_t)rest : chunk_bytes;
            ssize_t f = c * 8 / bits_per_frame;
            if (pcm_read(audiobuf, f) == f)
            {
                //tmp1 += f;
                if(m_loggingData&&m_loggingFile->isOpen()){
                    m_loggingFile->write(audiobuf,c);
                    //tmp2 += c;
                }

                QByteArray ba = QByteArray(audiobuf,c);
                for(size_t i = 0;i < c;)
                {
                    tmp = ((unsigned char)ba.at(i+3))*(16777216) + ((unsigned char)ba.at(i+2))*(65536) +  ((unsigned char)ba.at(i+1))*(256) +  (unsigned char)ba.at(i);
                    //tmp = ((unsigned char)(*(audiobuf+3)))*(16777216) + ((unsigned char)(*(audiobuf+2)))*(65536) +  ((unsigned char)(*(audiobuf+1)))*(256) +  (unsigned char)(*audiobuf);
                    rmsdBFS += pow(tmp,2);
                    i += 4;
                    ///qDebug()<<"tmp:"<<tmp;
                }
            }
            rest -= c;
        }
        ///IDE_TRACE_DOUBLE(rmsdBFS);
        //if(rmsdBFS > 0.0){
        rmsdBFS = rmsdBFS/m_denominator;
        rmsdBFS = 20*log10(sqrt(rmsdBFS/4800));
        QByteArray ba;
        ba.append(QString("%1,%2\n").arg(getTimeStamp()).arg(toFixedFloat(rmsdBFS,1)));
        QMutexLocker locker(&m_mutex2);
        if(m_rmsFile&&m_rmsFile->isOpen()){
            m_rmsFile->write(ba,ba.count());
            m_rmsFile->flush();
        }
        emit sigMicData(rmsdBFS);
        //}
        m_100msCounter++;
        if(m_loggingData&&m_100msCounter == 100){
            //IDE_TRACE_INT(tmp1);
            //IDE_TRACE_INT(tmp2);
            m_loggingFile->close();
            delete m_loggingFile;
            m_loggingFile =  NULL;
            m_loggingData = false;
            IDE_TRACE_STR("End Record Wav");
            //tmp1 = 0;
            //tmp2 = 0;
        }
    } while (1);
}

ssize_t MicNode::pcm_read(char *data, size_t rcount)
{
    ssize_t r;
    size_t result = 0;
    size_t count = rcount;
    //if (count != chunk_size) {
    //  count = chunk_size;
    //}

    while (count > 0) {
        r = readi_func(handle, data, count);
        if (r == -EAGAIN || (r >= 0 && (size_t)r < count)) {
            snd_pcm_wait(handle, 1000);
        } else if (r == -EPIPE) {
            xrun();
        } else if (r == -ESTRPIPE) {
            suspend();
        } else if (r < 0) {
            error(_("read error: %s"), snd_strerror(r));
            return -1;
        }
        if (r > 0) {
            if (vumeter)
                compute_max_peak(data, r * globalHwparams.channels);
            result += r;
            count -= r;
            data += r * bits_per_frame / 8;
        }
    }
    return rcount;
}
int MicNode::begin_wave(size_t cnt)
{
    WaveHeader h;
    WaveFmtBody f;
    WaveChunkHeader cf, cd;
    int bits;
    u_int tmp;
    u_short tmp2;

    /* WAVE cannot handle greater than 32bit (signed?) int */
    if (cnt == (size_t)-2)
        cnt = 0x7fffff00;

    bits = 8;
    switch ((unsigned long) globalHwparams.format) {
    case SND_PCM_FORMAT_U8:
        bits = 8;
        break;
    case SND_PCM_FORMAT_S16_LE:
        bits = 16;
        break;
    case SND_PCM_FORMAT_S32_LE:
    case SND_PCM_FORMAT_FLOAT_LE:
        bits = 32;
        break;
    case SND_PCM_FORMAT_S24_LE:
    case SND_PCM_FORMAT_S24_3LE:
        bits = 24;
        break;
    default:
        error(_("Wave doesn't support %s format..."), snd_pcm_format_name(globalHwparams.format));
        exit(EXIT_FAILURE);
    }
    h.magic = WAV_RIFF;
    tmp = cnt + sizeof(WaveHeader) + sizeof(WaveChunkHeader) + sizeof(WaveFmtBody) + sizeof(WaveChunkHeader) - 8;
    h.length = LE_INT(tmp);
    h.type = WAV_WAVE;

    cf.type = WAV_FMT;
    cf.length = LE_INT(16);

    if (globalHwparams.format == SND_PCM_FORMAT_FLOAT_LE)
        f.format = LE_SHORT(WAV_FMT_IEEE_FLOAT);
    else
        f.format = LE_SHORT(WAV_FMT_PCM);
    f.channels = LE_SHORT(globalHwparams.channels);
    f.sample_fq = LE_INT(globalHwparams.rate);

    tmp2 = globalHwparams.channels * snd_pcm_format_physical_width(globalHwparams.format) / 8;
    f.byte_p_spl = LE_SHORT(tmp2);
    tmp = (u_int) tmp2 * globalHwparams.rate;

    f.byte_p_sec = LE_INT(tmp);
    f.bit_p_spl = LE_SHORT(bits);

    cd.type = WAV_DATA;
    cd.length = LE_INT(cnt);

    if (m_loggingFile->write((char*)&h, sizeof(WaveHeader)) != sizeof(WaveHeader) ||
            m_loggingFile->write((char*)&cf, sizeof(WaveChunkHeader)) != sizeof(WaveChunkHeader) ||
            m_loggingFile->write((char*)&f, sizeof(WaveFmtBody)) != sizeof(WaveFmtBody) ||
            m_loggingFile->write((char*)&cd, sizeof(WaveChunkHeader)) != sizeof(WaveChunkHeader)) {
        error(_("write error"));
        ///exit(EXIT_FAILURE);
    }
    IDE_TRACE();
    return 0;
}
int MicNode::end_wave(int fd)
{
    WaveChunkHeader cd;
    off64_t length_seek;
    off64_t filelen;
    u_int rifflen;

    length_seek = sizeof(WaveHeader) +
            sizeof(WaveChunkHeader) +
            sizeof(WaveFmtBody);
    cd.type = WAV_DATA;
    cd.length = fdcount > 0x7fffffff ? LE_INT(0x7fffffff) : LE_INT(fdcount);
    filelen = fdcount + 2*sizeof(WaveChunkHeader) + sizeof(WaveFmtBody) + 4;
    rifflen = filelen > 0x7fffffff ? LE_INT(0x7fffffff) : LE_INT(filelen);
    if (lseek64(fd, 4, SEEK_SET) == 4)
        write(fd, &rifflen, 4);
    if (lseek64(fd, length_seek, SEEK_SET) == length_seek)
        write(fd, &cd, sizeof(WaveChunkHeader));
    if (fd != 1)
        close(fd);
    fd =-1;
    return -1;
}

void MicNode::parseRawData(long long  frames){
    Q_UNUSED(frames);
    //    signed int *dataPtr =  NULL;//(signed int *)m_PCMContainer.data_buf;
    //    long double sum=0;
    //    ////IDE_TRACE_DOUBLE(frames);
    //    for(long i = 0; i < frames;i++){
    //        signed int data = *dataPtr;
    //        sum += pow(data,2)/m_denominator;
    //        dataPtr++;
    //        //IDE_TRACE_DOUBLE(i);
    //    }
    //    double sumSqual = sum/frames;
    //    if(sumSqual < 0.0000001){
    //        return;
    //    }
    //    double dBFS = 20*log10(sqrt(sumSqual));
    //    emit sigMicData(dBFS);

    //    if(m_loggingData && m_100msCounter >= 0 && m_100msCounter < 100){
    //#ifdef USE_KPI_logfdGER
    //        write(m_loggerfd, m_PCMContainer.data_buf, frames*m_PCMContainer.bits_per_frame/8);

    //        QString dateString = QDate::currentDate().toString("yyyy/MM/dd");
    //        QString timeString = QTime::currentTime().toString("hh:mm:ss.zzz");
    //        //IDE_TRACE_STR(dateString+" "+timeString);
    //        QByteArray ba;
    //        ba.append(dateString);
    //        ba.append("");
    //        ba.append(timeString);
    //        ba.append(",");
    //        write(m_kpifd,ba,ba.length());
    //        char buf[30];
    //        int len = sprintf(buf,"%.4lf\n",dBFS);
    //        if(kpiFileOk){
    //            write(m_kpifd,buf,len);
    //        }
    //#endif
    //        m_100msCounter++;
    //        if(m_100msCounter == 100){
    //            m_loggingData = false;
    //            m_100msCounter = 0;
    //            close(m_loggerfd);
    //#ifdef USE_KPI_logfdGER
    //            close(m_kpifd);
    //#endif
    //            IDE_TRACE_STR("logfd finished");
    //        }
    //    }
}
bool MicNode::initSnd(){
    char *pcm_name = (char *)"default";
    int err;
    snd_pcm_info_t *info;
    snd_pcm_info_alloca(&info);
    err = snd_output_stdio_attach(&logfd, stdout, 0);
    m_captureStream = SND_PCM_STREAM_CAPTURE;
    start_delay = 1;
    m_chunk_size = -1;

    globalHwparams.format = DEFAULT_FORMAT;
    globalHwparams.rate = DEFAULT_SPEED;
    globalHwparams.channels = 1;
    globalHwparams.format = SND_PCM_FORMAT_S32_LE ;
    globalHwparams.rate = 48000;
    globalHwparams.channels = 1;

    err = snd_pcm_open(&handle, pcm_name, m_captureStream, open_mode);
    if (err < 0) {
        error(_("audio open error: %s"), snd_strerror(err));
        return false;
    }

    if ((err = snd_pcm_info(handle, info)) < 0) {
        error(_("info error: %s"), snd_strerror(err));
        return false;
    }

    m_chunk_size = 1024;
    audiobuf = (char *)malloc(1024);
    if (audiobuf == NULL) {
        error(_("not enough memory"));
        return false;
    }

    writei_func = snd_pcm_writei;
    readi_func = snd_pcm_readi;
    writen_func = snd_pcm_writen;
    readn_func = snd_pcm_readn;

    return true;
}
int MicNode::initParams()
{
    snd_pcm_hw_params_t *params;
    snd_pcm_sw_params_t *swparams;
    snd_pcm_uframes_t buffer_size;
    int err;
    size_t n;
    unsigned int rate;
    snd_pcm_uframes_t start_threshold, stop_threshold;
    snd_pcm_hw_params_alloca(&params);
    snd_pcm_sw_params_alloca(&swparams);
    err = snd_pcm_hw_params_any(handle, params);
    if (err < 0) {
        error(_("Broken configuration for this PCM: no configurations available"));
        return -1;
    }
    else if (interleaved)
        err = snd_pcm_hw_params_set_access(handle, params,
                                           SND_PCM_ACCESS_RW_INTERLEAVED);
    else
        err = snd_pcm_hw_params_set_access(handle, params,
                                           SND_PCM_ACCESS_RW_NONINTERLEAVED);
    if (err < 0) {
        error(_("Access type not available"));
        return -1;
    }
    err = snd_pcm_hw_params_set_format(handle, params, globalHwparams.format);
    if (err < 0) {
        error(_("Sample format non available"));
        return -1;
    }
    err = snd_pcm_hw_params_set_channels(handle, params, globalHwparams.channels);
    if (err < 0) {
        error(_("Channels count non available"));
        return -1;
    }

    rate = globalHwparams.rate;
    err = snd_pcm_hw_params_set_rate_near(handle, params, &globalHwparams.rate, 0);

    if ((float)rate * 1.05 < globalHwparams.rate || (float)rate * 0.95 > globalHwparams.rate) {
        if (!m_quietMode) {
            char plugex[64];
            const char *pcmname = snd_pcm_name(handle);
            fprintf(stderr, _("Warning: rate is not accurate (requested = %iHz, got = %iHz)\n"), rate, globalHwparams.rate);
            if (! pcmname || strchr(snd_pcm_name(handle), ':'))
                *plugex = 0;
            else
                snprintf(plugex, sizeof(plugex), "(-Dplug:%s)",
                         snd_pcm_name(handle));
            fprintf(stderr, _("         please, try the plug plugin %s\n"),
                    plugex);
        }
    }
    rate = globalHwparams.rate;
    if (m_buffer_time == 0 && m_buffer_frames == 0) {
        err = snd_pcm_hw_params_get_buffer_time_max(params,
                                                    &m_buffer_time, 0);
        assert(err >= 0);
        if (m_buffer_time > 500000)
            m_buffer_time = 500000;
    }
    if (m_period_time == 0 && m_period_frames == 0) {
        if (m_buffer_time > 0)
            m_period_time = m_buffer_time / 4;
        else
            m_period_frames = m_buffer_frames / 4;
    }
    if (m_period_time > 0)
        err = snd_pcm_hw_params_set_period_time_near(handle, params,&m_period_time, 0);
    else
        err = snd_pcm_hw_params_set_period_size_near(handle, params,&m_period_frames, 0);

    if (m_buffer_time > 0) {
        err = snd_pcm_hw_params_set_buffer_time_near(handle, params,&m_buffer_time, 0);
    } else {
        err = snd_pcm_hw_params_set_buffer_size_near(handle, params,&m_buffer_frames);
    }

    err = snd_pcm_hw_params(handle, params);
    if (err < 0) {
        error(_("Unable to install hw params:"));
        snd_pcm_hw_params_dump(params, logfd);
        return -1;
    }
    snd_pcm_hw_params_get_period_size(params, &m_chunk_size, 0);
    snd_pcm_hw_params_get_buffer_size(params, &buffer_size);
    if (m_chunk_size == buffer_size) {
        error(_("Can't use period equal to buffer size (%lu == %lu)"),
              m_chunk_size, buffer_size);
        return -1;
    }
    snd_pcm_sw_params_current(handle, swparams);
    if (avail_min < 0)
        n = m_chunk_size;
    else
        n = (double) rate * avail_min / 1000000;
    err = snd_pcm_sw_params_set_avail_min(handle, swparams, n);

    n = buffer_size;
    if (start_delay <= 0) {
        start_threshold = n + (double) rate * start_delay / 1000000;
    } else
        start_threshold = (double) rate * start_delay / 1000000;
    if (start_threshold < 1)
        start_threshold = 1;
    if (start_threshold > n)
        start_threshold = n;
    err = snd_pcm_sw_params_set_start_threshold(handle, swparams, start_threshold);

    if (stop_delay <= 0)
        stop_threshold = buffer_size + (double) rate * stop_delay / 1000000;
    else
        stop_threshold = (double) rate * stop_delay / 1000000;
    err = snd_pcm_sw_params_set_stop_threshold(handle, swparams, stop_threshold);


    if (snd_pcm_sw_params(handle, swparams) < 0) {
        error(_("unable to install sw params:"));
        snd_pcm_sw_params_dump(swparams, logfd);
        return -1;
    }

    if (verbose)
        snd_pcm_dump(handle, logfd);

    bits_per_sample = snd_pcm_format_physical_width(globalHwparams.format);
    bits_per_frame = bits_per_sample * globalHwparams.channels;
    ////chunk_bytes = m_chunk_size * bits_per_frame / 8;
    chunk_bytes = 4800*4;
    audiobuf = (char*)realloc(audiobuf, chunk_bytes);

    ///IDE_TRACE_INT(chunk_bytes);
    if (audiobuf == NULL) {
        error(_("not enough memory"));
        return -1;
    }
    if (vumeter == VUMETER_STEREO) {
        if (globalHwparams.channels != 2 || !interleaved || verbose > 2)
            vumeter = VUMETER_MONO;
    }

    m_buffer_frames = buffer_size;	/* for position test */
    return 0;
}
bool MicNode::closeSnd(){    
    m_captureStream = (_snd_pcm_stream)-1;
    if (fd > 1) {
        close(fd);
        fd = -1;
    }

    if (handle) {
        snd_pcm_close(handle);
        handle = NULL;
    }

    free(audiobuf);
    snd_output_close(logfd);
    snd_config_update_free_global();
    return false;
}
off64_t MicNode::calc_count(int timelimit)
{
    off64_t count;

    if (timelimit == 0) {
        count = pbrec_count;
    } else {
        count = snd_pcm_format_size(globalHwparams.format, globalHwparams.rate * globalHwparams.channels);
        count *= (off64_t)timelimit;
    }
    return count < pbrec_count ? count : pbrec_count;
}
int MicNode::new_capture_file(char *name, char *namebuf, size_t namelen,int filecount)
{
    /* get a copy of the original filename */
    char *s;
    char buf[PATH_MAX+1];

    strncpy(buf, name, sizeof(buf));

    /* separate extension from filename */
    s = buf + strlen(buf);
    while (s > buf && *s != '.' && *s != '/')
        --s;
    if (*s == '.')
        *s++ = 0;
    else if (*s == '/')
        s = buf + strlen(buf);

    /* upon first jump to this if block rename the first file */
    if (filecount == 1) {
        if (*s)
            snprintf(namebuf, namelen, "%s-01.%s", buf, s);
        else
            snprintf(namebuf, namelen, "%s-01", buf);
        remove(namebuf);
        rename(name, namebuf);
        filecount = 2;
    }

    /* name of the current file */
    if (*s)
        snprintf(namebuf, namelen, "%s-%02i.%s", buf, filecount, s);
    else
        snprintf(namebuf, namelen, "%s-%02i", buf, filecount);

    return filecount;
}
int MicNode::xrun(void)
{
    snd_pcm_status_t *status;
    int res;

    snd_pcm_status_alloca(&status);
    if ((res = snd_pcm_status(handle, status))<0) {
        error(_("status error: %s"), snd_strerror(res));
        return -1;
    }
    if (snd_pcm_status_get_state(status) == SND_PCM_STATE_XRUN) {
        struct timeval now, diff, tstamp;
        gettimeofday(&now, 0);
        snd_pcm_status_get_trigger_tstamp(status, &tstamp);
        timersub(&now, &tstamp, &diff);
        fprintf(stderr, _("%s!!! (at least %.3f ms long)\n"),
                m_captureStream == SND_PCM_STREAM_PLAYBACK ? _("underrun") : _("overrun"),
                diff.tv_sec * 1000 + diff.tv_usec / 1000.0);
        if (verbose) {
            fprintf(stderr, _("Status:\n"));
            snd_pcm_status_dump(status, logfd);
        }
        if ((res = snd_pcm_prepare(handle))<0) {
            error(_("xrun: prepare error: %s"), snd_strerror(res));
            return -1;
        }
        return 0;		/* ok, data should be accepted again */
    } if (snd_pcm_status_get_state(status) == SND_PCM_STATE_DRAINING) {
        if (verbose) {
            fprintf(stderr, _("Status(DRAINING):\n"));
            snd_pcm_status_dump(status, logfd);
        }
        if (m_captureStream == SND_PCM_STREAM_CAPTURE) {
            fprintf(stderr, _("capture stream format change? attempting recover...\n"));
            if ((res = snd_pcm_prepare(handle))<0) {
                error(_("xrun(DRAINING): prepare error: %s"), snd_strerror(res));
                return -1;
            }
        }
        return 0;
    }
    if (verbose) {
        fprintf(stderr, _("Status(R/W):\n"));
        snd_pcm_status_dump(status, logfd);
    }
    error(_("read/write error, state = %s"), snd_pcm_state_name(snd_pcm_status_get_state(status)));
    return 1;
}
int MicNode::suspend(void)
{
    int res;

    if (!m_quietMode)
        fprintf(stderr, _("Suspended. Trying resume. ")); fflush(stderr);
    while ((res = snd_pcm_resume(handle)) == -EAGAIN)
        sleep(1);	/* wait until suspend flag is released */
    if (res < 0) {
        if (!m_quietMode)
            fprintf(stderr, _("Failed. Restarting stream. ")); fflush(stderr);
        if ((res = snd_pcm_prepare(handle)) < 0) {
            error(_("suspend: prepare error: %s"), snd_strerror(res));
            return -1;
        }
    }
    if (!m_quietMode)
        fprintf(stderr, _("Done.\n"));
    return 0;
}
void MicNode::print_vu_meter_mono(int perc, int maxperc)
{
    const int bar_length = 50;
    char line[80];
    int val;

    for (val = 0; val <= perc * bar_length / 100 && val < bar_length; val++)
        line[val] = '#';
    for (; val <= maxperc * bar_length / 100 && val < bar_length; val++)
        line[val] = ' ';
    line[val] = '+';
    for (++val; val <= bar_length; val++)
        line[val] = ' ';
    if (maxperc > 99)
        sprintf(line + val, "| MAX");
    else
        sprintf(line + val, "| %02i%%", maxperc);
    fputs(line, stdout);
    if (perc > 100)
        printf(_(" !clip  "));
}
void MicNode::print_vu_meter_stereo(int *perc, int *maxperc)
{
    const int bar_length = 35;
    char line[80];
    int c;

    memset(line, ' ', sizeof(line) - 1);
    line[bar_length + 3] = '|';

    for (c = 0; c < 2; c++) {
        int p = perc[c] * bar_length / 100;
        char tmp[4];
        if (p > bar_length)
            p = bar_length;
        if (c)
            memset(line + bar_length + 6 + 1, '#', p);
        else
            memset(line + bar_length - p - 1, '#', p);
        p = maxperc[c] * bar_length / 100;
        if (p > bar_length)
            p = bar_length;
        if (c)
            line[bar_length + 6 + 1 + p] = '+';
        else
            line[bar_length - p - 1] = '+';
        if (maxperc[c] > 99)
            sprintf(tmp, "MAX");
        else
            sprintf(tmp, "%02d%%", maxperc[c]);
        if (c)
            memcpy(line + bar_length + 3 + 1, tmp, 3);
        else
            memcpy(line + bar_length, tmp, 3);
    }
    line[bar_length * 2 + 6 + 2] = 0;
    fputs(line, stdout);
}
void MicNode::print_vu_meter(signed int *perc, signed int *maxperc)
{
    if (vumeter == VUMETER_STEREO)
        print_vu_meter_stereo(perc, maxperc);
    else
        print_vu_meter_mono(*perc, *maxperc);
}
void MicNode::compute_max_peak(char *data, size_t count)
{
    signed int val, max, perc[2], max_peak[2];
    static	int	run = 0;
    size_t ocount = count;
    int	format_little_endian = snd_pcm_format_little_endian(globalHwparams.format);
    int ichans, c;

    if (vumeter == VUMETER_STEREO)
        ichans = 2;
    else
        ichans = 1;

    memset(max_peak, 0, sizeof(max_peak));
    switch (bits_per_sample) {
    case 8: {
        signed char *valp = (signed char *)data;
        signed char mask = snd_pcm_format_silence(globalHwparams.format);
        c = 0;
        while (count-- > 0) {
            val = *valp++ ^ mask;
            val = abs(val);
            if (max_peak[c] < val)
                max_peak[c] = val;
            if (vumeter == VUMETER_STEREO)
                c = !c;
        }
        break;
    }
    case 16: {
        signed short *valp = (signed short *)data;
        signed short mask = snd_pcm_format_silence_16(globalHwparams.format);
        signed short sval;

        count /= 2;
        c = 0;
        while (count-- > 0) {
            if (format_little_endian)
                sval = __le16_to_cpu(*valp);
            else
                sval = __be16_to_cpu(*valp);
            sval = abs(sval) ^ mask;
            if (max_peak[c] < sval)
                max_peak[c] = sval;
            valp++;
            if (vumeter == VUMETER_STEREO)
                c = !c;
        }
        break;
    }
    case 24: {
        char *valp = data;
        signed int mask = snd_pcm_format_silence_32(globalHwparams.format);

        count /= 3;
        c = 0;
        while (count-- > 0) {
            if (format_little_endian) {
                val = valp[0] | (valp[1]<<8) | (valp[2]<<16);
            } else {
                val = (valp[0]<<16) | (valp[1]<<8) | valp[2];
            }
            /* Correct signed bit in 32-bit value */
            if (val & (1<<(bits_per_sample-1))) {
                val |= 0xff<<24;	/* Negate upper bits too */
            }
            val = abs(val) ^ mask;
            if (max_peak[c] < val)
                max_peak[c] = val;
            valp += 3;
            if (vumeter == VUMETER_STEREO)
                c = !c;
        }
        break;
    }
    case 32: {
        signed int *valp = (signed int *)data;
        signed int mask = snd_pcm_format_silence_32(globalHwparams.format);
        count /= 4;
        c = 0;
        while (count-- > 0) {
            if (format_little_endian)
                val = __le32_to_cpu(*valp);
            else
                val = __be32_to_cpu(*valp);
            val = abs(val) ^ mask;
            if (max_peak[c] < val)
                max_peak[c] = val;
            valp++;
            if (vumeter == VUMETER_STEREO)
                c = !c;
        }
        break;
    }
    default:
        if (run == 0) {
            fprintf(stderr, _("Unsupported bit size %d.\n"), (int)bits_per_sample);
            run = 1;
        }
        return;
    }
    max = 1 << (bits_per_sample-1);
    if (max <= 0)
        max = 0x7fffffff;

    for (c = 0; c < ichans; c++) {
        if (bits_per_sample > 16)
            perc[c] = max_peak[c] / (max / 100);
        else
            perc[c] = max_peak[c] * 100 / max;
    }

    if (interleaved && verbose <= 2) {
        static int maxperc[2];
        static time_t t=0;
        const time_t tt=time(NULL);
        if(tt>t) {
            t=tt;
            maxperc[0] = 0;
            maxperc[1] = 0;
        }
        for (c = 0; c < ichans; c++)
            if (perc[c] > maxperc[c])
                maxperc[c] = perc[c];

        putchar('\r');
        print_vu_meter(perc, maxperc);
        fflush(stdout);
    }
    else if(verbose==3) {
        printf(_("Max peak (%li samples): 0x%08x "), (long)ocount, max_peak[0]);
        for (val = 0; val < 20; val++)
            if (val <= perc[0] / 5)
                putchar('#');
            else
                putchar(' ');
        printf(" %i%%\n", perc[0]);
        fflush(stdout);
    }
}
