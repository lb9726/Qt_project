#ifndef MICNODE_H
#define MICNODE_H

#include <QObject>
#include <QThread>
#include <QMutex>
#include <QFile>
#include <QTimer>
#include <alsa/asoundlib.h>

//#define USE_KPI_LOGGER
class DataLogger;
class MicNode : public QThread
{
    Q_OBJECT
public:
    explicit MicNode();
    void init();
    void startWork();
    void setFreq(int freq);

    void run();
    bool handleError();

    void record_10S_data();
    bool closeSnd();
    bool initSnd();
    void parseRawData(long long lenBytes);

    int new_capture_file(char *name, char *namebuf, size_t namelen,int filecount);
    int begin_wave(size_t count);
    int end_wave(int fd);
    int xrun(void);
    int suspend(void);
    void print_vu_meter_mono(int perc, int maxperc);
    void print_vu_meter_stereo(int *perc, int *maxperc);
    void print_vu_meter(signed int *perc, signed int *maxperc);
    void compute_max_peak(char *data, size_t count);
    ssize_t pcm_read(char *data, size_t rcount);
    off64_t calc_count(int timelimit);
    int initParams();
signals:
    void sigMicData(qreal noise);
public slots:
    void sltShiftFile(QString filePath);
    void setDebugMode(bool isDebug);
    void triggerWavlogger(QString fileName);
    void tiggerRecorder();
public:
    volatile bool m_loggingData;

    QTimer *m_recordTimer;
    int m_loggerfd;

    double m_denominator;
    int m_100msCounter;

    QMutex  m_mutex1;
    QMutex  m_mutex2;
    QFile *m_loggingFile;
    QFile *m_rmsFile;

#ifdef USE_KPI_LOGGER
    int m_kpifd;
    bool kpiFileOk;
#endif

    bool m_quietMode;
    snd_pcm_stream_t m_captureStream;
    snd_pcm_uframes_t m_chunk_size;
    unsigned m_period_time;
    unsigned m_buffer_time;
    snd_pcm_uframes_t m_period_frames;
    snd_pcm_uframes_t m_buffer_frames;
    volatile bool isDebuging;
//    QQueue<int> m_forwardQueue;
//    QQueue<int> m_lateralQueue;
};

#endif // MICNODE_H
