#include "micnode.h"
#include "define.h"
#include <QtMath>
#include <QDate>
#include <QDir>
#include <QDateTime>
#include <QCoreApplication>
#include <stdio.h>

MicNode::MicNode()
{
    m_Default_Channels = 1;
    m_Default_Sample_Rate = 48000;
    m_Default_Sample_Length = 32;/////
    m_Default_Duration_Time = 10;
    m_denominator = pow(2,m_Default_Sample_Length-1);
    m_denominator = pow(m_denominator,2);

    m_100msCounter = 0;
    m_logData = false;

    m_recordTimer = new QTimer();
    connect(m_recordTimer,&QTimer::timeout,this,&MicNode::tiggerRecorder);
    m_recordTimer->setInterval(2000);

        IDE_TRACE_INT(sizeof(signed int ));
        IDE_TRACE_INT(sizeof(signed long));
}

void MicNode::init()
{

}

void MicNode::startWork()
{
    if(initSnd()){
        m_recordTimer->start();
//        start(QThread::LowPriority);
        start();
    }else{
        IDE_TRACE();
    }

    IDE_TRACE();
}

void MicNode::setFreq(int freq)
{
    Q_UNUSED(freq);
}

void MicNode::tiggerRecorder(){
    triggerWavLogger(QString());
    m_recordTimer->stop();
}

void MicNode::triggerWavLogger(QString fileName){
    Q_UNUSED(fileName);
//    QString m_baseDirPath = QCoreApplication::applicationDirPath()+"/data/";

//    QDate curDate = QDate::currentDate();
//    QString m_curDataDirName = curDate.toString("yyyyMMdd");
//    QString m_curHourDirName = m_curDataDirName + QTime::currentTime().toString("_hh");
//    QDir dir(m_baseDirPath);
//    dir.mkdir(m_curDataDirName);
//    dir.cd(m_curDataDirName);
//    dir.mkdir(m_curHourDirName);

//    QString m_fileName = m_baseDirPath+m_curDataDirName+"/"+m_curHourDirName+"/";
    QString m_fileName = QDateTime::currentDateTime().toString("yyyyMMdd_hh_mm_ss_");
    m_fileName += "noise.wav";
    IDE_TRACE_STR(m_fileName);
    filename.clear();
    filename.append(m_fileName);
    remove(filename.data());

    if ((m_loggerfd = open(filename.data(), O_WRONLY | O_CREAT, 0644)) == -1) {
        IDE_TRACE_STR("Error open output file.");
        QMutexLocker locker(&m_mutex);
        m_logData = false;
        return;
    }else{
        if (WAV_WriteHeader(m_loggerfd, &m_wavContainer) < 0) {
            QMutexLocker locker(&m_mutex);
            m_logData = false;
            return;
        }
#ifdef USE_KPI_LOGGER
        QString tmpName = QDateTime::currentDateTime().toString("yyyyMMdd_hh_mm_ss_");
        tmpName += "noise.csv";
        QByteArray ba;
        ba.append(tmpName);
        if ((m_kpifd = open(ba.data(), O_WRONLY | O_CREAT, 0644)) == -1) {
            IDE_TRACE_STR("Error open output file.");
            kpiFileOk = false;
        }else{
            kpiFileOk = true;
        }
#endif
        QMutexLocker locker(&m_mutex);
        m_logData = true;
        m_100msCounter = 0;
        IDE_TRACE_STR("start log");
    }
}

void MicNode::run()
{    
    ssize_t framePer100ms = 4800; ///10s dived to 100 timems, each is 100ms
    while(1){
        if (SNDWAV_ReadPcm(&m_PCMContainer, framePer100ms) == framePer100ms){
            parseRawData(framePer100ms);
        }else{
            IDE_TRACE();
        }
    }
    closeSnd();
    return ;
}

void MicNode::parseRawData(long long  frames){
    signed int *dataPtr = (signed int *)m_PCMContainer.data_buf;
    long double sum=0;
    ////IDE_TRACE_DOUBLE(frames);
    for(long i = 0; i < frames;i++){
        signed int data = *dataPtr;
        sum += pow(data,2)/m_denominator;
        dataPtr++;
        //IDE_TRACE_DOUBLE(i);
    }
    double sumSqual = sum/frames;
    if(sumSqual < 0.0000001){
        return;
    }
    double dBFS = 20*log10(sqrt(sumSqual));
    emit sigMicData(dBFS);

    if(m_logData && m_100msCounter >= 0 && m_100msCounter < 100){
        write(m_loggerfd, m_PCMContainer.data_buf, frames*m_PCMContainer.bits_per_frame/8);
#ifdef USE_KPI_LOGGER
        QString dateString = QDate::currentDate().toString("yyyy/MM/dd");
        QString timeString = QTime::currentTime().toString("hh:mm:ss.zzz");
        //IDE_TRACE_STR(dateString+" "+timeString);
        QByteArray ba;
        ba.append(dateString);
        ba.append("");
        ba.append(timeString);
        ba.append(",");
        write(m_kpifd,ba,ba.length());
        char buf[30];
        int len = sprintf(buf,"%.4lf\n",dBFS);
        if(kpiFileOk){
            write(m_kpifd,buf,len);
        }
#endif
        m_100msCounter++;
        if(m_100msCounter == 100){
            m_logData = false;
            m_100msCounter = 0;
            close(m_loggerfd);
#ifdef USE_KPI_LOGGER
            close(m_kpifd);
#endif
            IDE_TRACE_STR("Log finished");
        }
    }
}

bool MicNode::initSnd(){
    memset(&m_PCMContainer, 0x0, sizeof(m_PCMContainer));
    if (snd_output_stdio_attach(&m_PCMContainer.log, stderr, 0) < 0) {
        IDE_TRACE_STR(QString("Error snd_output_stdio_attach."));
        return handleError();
    }

    if (snd_pcm_open(&m_PCMContainer.handle, "default", SND_PCM_STREAM_CAPTURE, 0) < 0) {
        IDE_TRACE_STR(QString("Error snd_pcm_open default."));
        return handleError();
    }

    if (initWavParams(&m_wavContainer) < 0) {
        IDE_TRACE_STR("Error SNDWAV_PrepareWAVParams.");
        return handleError();
    }

    if (SNDWAV_SetParams(&m_PCMContainer, &m_wavContainer) < 0) {
        IDE_TRACE_STR("Error set_snd_pcm_params.");
        return handleError();
    }
    return true;
}

bool MicNode::initWavParams(WAVContainer_t *wav)
{
    if(wav == NULL)
        return false;
    uint16_t channels = m_Default_Channels;
    uint16_t sample_rate = m_Default_Sample_Rate;
    uint16_t sample_length = m_Default_Sample_Length;
    uint32_t duration_time = m_Default_Duration_Time;

    /* Const */
    wav->header.magic = WAV_RIFF;
    wav->header.type = WAV_WAVE;
    wav->format.magic = WAV_FMT;
    wav->format.fmt_size = LE_INT(16);
    wav->format.format = LE_SHORT(WAV_FMT_PCM);
    wav->chunk.type = WAV_DATA;

    /* User definition */
    wav->format.channels = LE_SHORT(channels);
    wav->format.sample_rate = LE_INT(sample_rate);
    wav->format.sample_length = LE_SHORT(sample_length);

    /* See format of wav file */
    wav->format.blocks_align = LE_SHORT(channels * sample_length / 8);
    wav->format.bytes_p_second = LE_INT((uint16_t)(wav->format.blocks_align) * sample_rate);

    wav->chunk.length = LE_INT(duration_time * (uint32_t)(wav->format.bytes_p_second));
    wav->header.length = LE_INT((uint32_t)(wav->chunk.length) + \
                                sizeof(wav->chunk) + sizeof(wav->format) + sizeof(wav->header) - 8);
    return true;
}

bool MicNode::closeSnd(){
    snd_pcm_drain(m_PCMContainer.handle);
    free(m_PCMContainer.data_buf);
    snd_output_close(m_PCMContainer.log);
    snd_pcm_close(m_PCMContainer.handle);
    return false;
}

bool MicNode::handleError(){
    close(m_loggerfd);
    remove(filename);
    if (m_PCMContainer.data_buf)
    {
        free(m_PCMContainer.data_buf);
    }

    if (m_PCMContainer.log)
    {
        snd_output_close(m_PCMContainer.log);
    }

    if (m_PCMContainer.handle)
    {
        snd_pcm_close(m_PCMContainer.handle);
    }

    return false;
}
