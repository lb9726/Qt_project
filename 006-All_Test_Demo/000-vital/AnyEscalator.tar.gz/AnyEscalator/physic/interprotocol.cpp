#include "interprotocol.h"
#include "define.h"

InterProtocol::InterProtocol(QObject *parent) : QObject(parent)
{
    m_FrameBuffer.clear();
    m_HBCount = 0;
    isNodeAreConnected = false;
}

void InterProtocol::init(){
    m_HBTimeoutTimer = new QTimer(this);
    m_HBTimeoutTimer->setInterval(1000);//心跳周期
    connect(m_HBTimeoutTimer,&QTimer::timeout,this,&InterProtocol::hbTimerOut);
    isNodeAreConnected = false;
    isIR_Left = false;
    isIR_Right = false;
    isTEMP_Left = false;
    isTEMP_Right = false;
    isRS485 = false;
    mbigVersion = 0;
    mlitteVersion = 0;
    m_upgradStatus = McuUpgrad_Unstart;
}

void InterProtocol::startWork(){
    ///IDE_TRACE();
#ifdef UseNetworkTest
    initTcpTest(19999);
#else
    OpenCom();
///    triggUpgradMcu();
///    IDE_TRACE();
//    m_mcuBinUpgrader = new mcuBinUpgrader();
//    if(m_mcuBinUpgrader->isNeedUpgrade()){
//        triggUpgradMcu();
//    }
    //m_HBTimeoutTimer->start();
#endif
}

bool InterProtocol::OpenCom()
{
    m_comPort = new QSerialPort(this);
    m_comPort->setPortName("/dev/ttymxc3");
    if(m_comPort->open(QIODevice::ReadWrite))
    {
        //设置波特率
        m_comPort->setBaudRate(115200);
        //设置数据位
        m_comPort->setDataBits(QSerialPort::Data8);
        //设置校验位
        m_comPort->setParity(QSerialPort::NoParity);
        //设置流控制
        m_comPort->setFlowControl(QSerialPort::NoFlowControl);
        //设置停止位
        m_comPort->setStopBits(QSerialPort::OneStop);
        connect(m_comPort,&QSerialPort::readyRead,this,&InterProtocol::readyRead);
        return true;
    }
    else
    {
        IDE_TRACE();
        return false;
    }
}

void InterProtocol::readyRead(){
    //IDE_TRACE();
    QByteArray ba = m_comPort->readAll();
    ParseBuffer(ba);
}

quint32 InterProtocol::ParseBuffer(QByteArray& buffer)
{
    //IDE_TRACE();
    if(buffer.isEmpty())
    {
        buffer.clear();
        return 0;
    }
    quint32 tmpCount = buffer.count();
    char tmpValue = 0;
    char tmpValueNext = 0;
    quint32 i = 0;
    ///qDebug()<<"ParseBuffer :" <<buffer;
    while(i < tmpCount)
    {
        tmpValue = buffer.at(i++);
        if(D_STX == tmpValue){
            m_FrameBuffer.clear();
        }else if(D_ETX == tmpValue){
            ParseFrame();
        }else{
            if(tmpValue != D_ESC){
                m_FrameBuffer.append(tmpValue);
            }else{
                tmpValueNext = buffer.at(i++);
                if(tmpValueNext == D_STX_ESC)
                    m_FrameBuffer.append(D_STX);
                else if(tmpValueNext == D_STX_ETX)
                    m_FrameBuffer.append(D_ETX);
                else if(tmpValueNext == D_ESC_ESC)
                    m_FrameBuffer.append(D_ESC);
            }
        }

    }
    buffer.clear();
    return 1;
}

quint32 InterProtocol::ParseFrame()
{
    if(m_FrameBuffer.count() <= 2)
    {
        // qDebug()<<"m_FrameBuffer:"<<m_FrameBuffer;
        m_FrameBuffer.clear();
        return 0;
    }
    char frameType = m_FrameBuffer.at(0);
    //char crc = m_FrameBuffer.at(m_FrameBuffer.count()-1);
    m_FrameBuffer.chop(1);//去掉CRC校验字节
    quint32 tmpDataCount = m_FrameBuffer.count();
    switch (frameType) {
    case HeartBeat:
        if(tmpDataCount != 3 ){
            IDE_TRACE_STR("Ivalide Heart Beat Frame");
        }else{
            quint16 tmpCount = m_FrameBuffer.at(1)+m_FrameBuffer.at(2) * 256;
            return heartBeat(tmpCount);
        }
        break;
    case SensorData:{
        QByteArray ba = m_FrameBuffer.right(tmpDataCount-1);
        sensorData(ba);
    }
        break;
    case ConnectStatus:{
        ///IDE_TRACE();
        QByteArray ba = m_FrameBuffer.right(tmpDataCount-1);
        connectStatus(ba);
    }
        break;
    case ParameterConfigure:{
        //IDE_TRACE();
        QByteArray ba = m_FrameBuffer.right(tmpDataCount-1);
        parameterConfigure(ba);
    }
        break;
    case UpgradCmdAck:{
        //IDE_TRACE();
        QByteArray ba = m_FrameBuffer.right(tmpDataCount-1);
        upgradCmdAck(ba);
    }
        break;
    case UpgradData:{
        //IDE_TRACE();
        QByteArray ba = m_FrameBuffer.right(tmpDataCount-1);
        upgradData(ba);
    }
        break;
    case McuVersion:{
        //IDE_TRACE();
        QByteArray ba = m_FrameBuffer.right(tmpDataCount-1);
        mcuVersion(ba);
    }
        break;
    default:
        break;
    }
    //IDE_TRACE();
    return 1;
}

quint32 InterProtocol::heartBeat(quint16 counter){
    m_HBCount = counter;
    replyHeatBeatFrame(m_HBCount);
    return 0;
}

quint32 InterProtocol::replyHeatBeatFrame(quint16 counter){
    //if((counter-m_HBCount) <=3){
    //m_HBTimeoutTimer->start(1000);
    m_HBCount = counter;
    sendHB(m_HBCount);
    //}
    return 0;
}

quint32 InterProtocol::sensorData(QByteArray &data){
    char sensorType = data.at(0);
    QString content = data.right(data.count()-1);
    switch (sensorType) {
    case THERMOCOUPLE:
        //IDE_TRACE_STR("TC: "+content);
        if(TEMP_Left||TEMP_Right)
            emit sigThermData(content);
        break;
    case INFRARED:
        IDE_TRACE_STR("Infrad: "+content);
        if(IR_Left||IR_Right)
            emit sigInfraData(content);
        break;
    case POWERMETER:
        //IDE_TRACE_STR("Power: "+content);
        if(RS485)
            emit sigPowerData(content);
        break;
    case RUN_SPEED:
        //IDE_TRACE_STR("Speed: "+content);
        emit sigSpeedData(content);
        break;
    case PEOPLECOUNTER:
        //IDE_TRACE_STR("PeopleCount: "+content);
        emit sigPeopleCountData(content);
        break;
    case RUN_DIRECTION:
        //IDE_TRACE_STR("Direction: "+content);
        emit sigDirectionData(content);
        break;
    default:
        break;
    }
    return 0;
}

quint32 InterProtocol::connectStatus(QByteArray &data){
    ///qDebug()<<"connectStatusFrame: "<<data;
    if(data.length() == 10){
        bool flag = data.at(0) == 0x00 ? false:true;
        if(flag != isNodeAreConnected){
            emit sigNodeConnectStatus(AllNodes,flag);
            isNodeAreConnected = flag;
        }

        flag = data.at(1) == 0x00 ? false:true;
        if(flag != isIR_Left){
            emit sigNodeConnectStatus(IR_Left,flag);
            isIR_Left = flag;
        }

        flag = data.at(2) == 0x00 ? false:true;
        if(flag != isIR_Right){
            emit sigNodeConnectStatus(IR_Right,flag);
            isIR_Right = flag;
        }

        flag = data.at(3) == 0x00 ? false:true;
        if(flag != isTEMP_Left){
            emit sigNodeConnectStatus(TEMP_Left,flag);
            isTEMP_Left = flag;
        }

        flag = data.at(4) == 0x00 ? false:true;
        if(flag != isTEMP_Right){
            emit sigNodeConnectStatus(TEMP_Right,flag);
            isTEMP_Right = flag;
        }

        flag = data.at(5) == 0x00 ? false:true;
        if(flag != isRS485){
            emit sigNodeConnectStatus(RS485,flag);
            isRS485 = flag;
        }
    }else{
        //IDE_TRACE();
    }
}

quint32 InterProtocol::upgradCmdAck(QByteArray &data)
{
    ///qDebug()<<"upgradCmdAck: "<<data;
    if(data.length() == 1){
        if(m_upgradStatus == McuUpgrad_Start){
            if(data.at(0) == 0x01){
                IDE_TRACE_STR("Start upgrad comfirmed");
                m_upgradStatus = McuUpgrad_Data;
            }
        }else if(m_upgradStatus == McuUpgrad_Data){
            if(data.at(0) == 0x02){
                IDE_TRACE_STR("Start upgrad comfirmed");
                m_upgradStatus = McuUpgrad_Data;
            }else if(data.at(0) == 0x03){
                IDE_TRACE_STR("Start upgrad comfirmed");
            }
        }
    }

    return 0;
    ///AnyEscalator_MCU_V1.02
    /// if(McuUpgrad_Start
}

quint32 InterProtocol::upgradData(QByteArray &data)
{
    qDebug()<<"upgradData: "<<data;
    return 0;
}

quint32 InterProtocol::mcuVersion(QByteArray &data)
{
    ///qDebug()<<"mcuVersion: "<<data;
    if(data.length() == 5){
        if(mbigVersion > data.at(0)){
            startUpgrade();
        }else if(mbigVersion == data.at(0) && mlitteVersion >data.at(1) ){
            startUpgrade();
        }else{
            noNeedUpgrade();
        }
    }
}

quint32 InterProtocol::parameterConfigure(QByteArray &data){
    char sensorType = data.at(0);
    QString content = data.right(data.count()-1);
    switch (sensorType) {
    case THERMOCOUPLE:
        emit sigThermCmd(content);
        break;
    case INFRARED:
        emit sigInfraCmd(content);
        break;
    case POWERMETER:
        emit sigPowerCmd(content);
        break;
    default:
        break;
    }
    return 0;
}

quint32 InterProtocol::startUpgrade(){
    QByteArray ba;
    ba.append(UpgradCmd);
    ba.append((char)0x01).append((char)0x00).append((char)0x00).append((char)0x00);
    ba.append((char)0x00).append((char)0x00).append((char)0x00);
    return sendFrame(ba);
    m_upgradStatus = McuUpgrad_Start;
}

quint32 InterProtocol::noNeedUpgrade(){
    QByteArray ba;
    ba.append(UpgradCmd);
    ba.append((char)0x00).append((char)0x00).append((char)0x00).append((char)0x00);
    ba.append((char)0x00).append((char)0x00).append((char)0x00);
    return sendFrame(ba);
}

quint32 InterProtocol::triggUpgradMcu(){
    QByteArray ba;
    ba.append(UpgradCmd);
    ba.append((char)0x01).append((char)0x00).append((char)0x00).append((char)0x00);
    ba.append((char)0x00).append((char)0x00).append((char)0x00);
    return sendFrame(ba);
}

void InterProtocol::hbTimerOut(){
    //IDE_TRACE();
    ///triggUpgradMcu();
}

void InterProtocol::sendHB(quint16 counter){
    QByteArray ba;
    ba.append(HeartBeat);
    ba.append(counter%256);
    ba.append(counter/256);
#ifdef UseNetworkTest
    slotSendMesg(ba);
#else
    sendFrame(ba);
#endif
}

void InterProtocol::sendCmd(QString cmd){
    QByteArray ba;
    ba.append(ParameterConfigure);
    ba.append(cmd);
    sendFrame(ba);
}

void InterProtocol::sendFreq(SENSOR_TYPE sensor,qreal value){
    QByteArray ba;
    ba.append(ParameterConfigure);
    ba.append(sensor);
    ba.append(QString("%1").arg(value));
    sendFrame(ba);
}

qint64 InterProtocol::sendFrame(QByteArray &ba){
    QByteArray buffer;
    quint32 tmpCount = ba.count();
    char tmpValue = 0;
    quint32 i = 0;
    char crc= 0x00;
    buffer.append(D_STX);
    while(i < tmpCount)
    {
        tmpValue = ba.at(i++);
        crc ^= tmpValue;
        if(D_STX == tmpValue){
            buffer.append(D_ESC);
            buffer.append(D_STX_ESC);
        }else if(D_ETX == tmpValue){
            buffer.append(D_ESC);
            buffer.append(D_STX_ETX);
        }else if(D_ESC == tmpValue){
            buffer.append(D_ESC);
            buffer.append(D_ESC_ESC);
        } else{
            buffer.append(tmpValue);
        }
    }
    crc &= 0x7F;
    if(D_STX == crc){
        buffer.append(D_ESC);
        buffer.append(D_STX_ESC);
    }else if(D_ETX == crc){
        buffer.append(D_ESC);
        buffer.append(D_STX_ETX);
    }else if(D_ESC == crc){
        buffer.append(D_ESC);
        buffer.append(D_ESC_ESC);
    } else{
        buffer.append(crc);
    }

    buffer.append(D_ETX);
#ifdef UseNetworkTest
    slotSendMesg(buffer);
#else
    ///qDebug()<<"sendFrame:" <<buffer;
    return m_comPort->write(buffer);
#endif

}

#ifdef UseNetworkTest
void InterProtocol::initTcpTest(int port)
{
    m_pTcpServer = new QTcpServer();
    if(!m_pTcpServer->listen(QHostAddress::Any,port)){
        IDE_TRACE_STR("Test TCP Server Listen Error!");
    }
    connect(m_pTcpServer,SIGNAL(newConnection()),this,SLOT(newConnectSlot()));
    m_pTcpSocket = NULL;
}

void InterProtocol::newConnectSlot()
{
    if(m_pTcpSocket){
        m_pTcpSocket->close();
    }
    m_pTcpSocket = m_pTcpServer->nextPendingConnection();
    connect(m_pTcpSocket,SIGNAL(readyRead()),this,SLOT(readMessage()));
    connect(m_pTcpSocket,SIGNAL(disconnected()),this,SLOT(clientDisconnected()));
    isConnected = true;
    IDE_TRACE();
}

void InterProtocol::clientDisconnected(){
    IDE_TRACE();
    isConnected = false;
}

void InterProtocol::readMessage()
{
    QByteArray ba = m_pTcpSocket->readAll();
    ParseBuffer(ba);
}

void InterProtocol::slotSendMesg(QByteArray &data) //发送消息
{
    if(isConnected && m_pTcpSocket)
        m_pTcpSocket->write(data);
}
#endif
