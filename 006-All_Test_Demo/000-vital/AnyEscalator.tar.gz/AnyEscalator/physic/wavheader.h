#ifndef WAVHEADER
#define WAVHEADER

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <malloc.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <fcntl.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <time.h>
#include <locale.h>
#include <alsa/asoundlib.h>
#include <assert.h>
#include <sys/poll.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/signal.h>
#include <asm/byteorder.h>
#include <libintl.h>
#include <endian.h>
#include <byteswap.h>


//#define _GNU_SOURCE

#define COMPOSE_ID(a,b,c,d)	((a) | ((b)<<8) | ((c)<<16) | ((d)<<24))
#define LE_SHORT(v)		(v)
#define LE_INT(v)		(v)
#define BE_SHORT(v)		bswap_16(v)
#define BE_INT(v)		bswap_32(v)

#define WAV_RIFF		COMPOSE_ID('R','I','F','F')
#define WAV_WAVE		COMPOSE_ID('W','A','V','E')
#define WAV_FMT			COMPOSE_ID('f','m','t',' ')
#define WAV_DATA		COMPOSE_ID('d','a','t','a')

/* WAVE fmt block constants from Microsoft mmreg.h header */
#define WAV_FMT_PCM             0x0001
#define WAV_FMT_IEEE_FLOAT      0x0003

typedef struct
{
    u_int magic;		/* 'RIFF' */
    u_int length;		/* filelen */
    u_int type;		/* 'WAVE' */
} WaveHeader;

typedef struct
{
    u_short format;		/* see WAV_FMT_* */
    u_short channels;
    u_int sample_fq;	/* frequence of sample */
    u_int byte_p_sec;
    u_short byte_p_spl;	/* samplesize; 1 or 2 bytes */
    u_short bit_p_spl;	/* 8, 12 or 16 bit */
} WaveFmtBody;

typedef struct
{
    u_int type;		/* 'data' */
    u_int length;		/* samplecount */
} WaveChunkHeader;

#define _(msgid) gettext (msgid)
#define gettext_noop(msgid) msgid
#define N_(msgid) gettext_noop (msgid)

#ifndef LLONG_MAX
#define LLONG_MAX    9223372036854775807LL
#endif

#define DEFAULT_FORMAT		SND_PCM_FORMAT_U8
#define DEFAULT_SPEED 		8000

#define FORMAT_DEFAULT		-1
#define FORMAT_RAW		0
#define FORMAT_VOC		1
#define FORMAT_WAVE		2
#define FORMAT_AU		3

/* global data */
static snd_pcm_sframes_t (*readi_func)(snd_pcm_t *handle, void *buffer, snd_pcm_uframes_t size);
static snd_pcm_sframes_t (*writei_func)(snd_pcm_t *handle, const void *buffer, snd_pcm_uframes_t size);
static snd_pcm_sframes_t (*readn_func)(snd_pcm_t *handle, void **bufs, snd_pcm_uframes_t size);
static snd_pcm_sframes_t (*writen_func)(snd_pcm_t *handle, void **bufs, snd_pcm_uframes_t size);

enum
{
    VUMETER_NONE,
    VUMETER_MONO,
    VUMETER_STEREO
};


static struct
{
    snd_pcm_format_t format;
    unsigned int channels;
    unsigned int rate;
} globalHwparams;

long long max_filesize = 2147483648LL;
off64_t pbrec_count = LLONG_MAX;
#define error(...) do { } while (0)


#ifdef __cplusplus
}
#endif

#endif // WAVHEADER

