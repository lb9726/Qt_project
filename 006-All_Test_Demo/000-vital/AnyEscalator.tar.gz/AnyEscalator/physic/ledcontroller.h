#ifndef LEDCONTROLLER_H
#define LEDCONTROLLER_H

#include <QObject>
#include <QTimer>

class LedController : public QObject
{
    Q_OBJECT
public:
    explicit LedController(QObject *parent = 0);


    static void powerOnLight(bool flag = true);
    static void onlineLight(bool flag);
    static void deviceModeLight(bool flag);
    static void deviceErrorLight(bool flag);
signals:

public slots:
public:
#ifdef UNITTEST
    bool testFlag;
    QTimer m_timer;
    void testSlot();
#endif
};

#endif // LEDCONTROLLER_H
