#ifndef MICNODE_H
#define MICNODE_H

#include <QObject>
#include <QThread>
#include <QMutex>
#include <stdio.h>
#include <malloc.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <fcntl.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <time.h>
#include <locale.h>
#include <sys/unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <alsa/asoundlib.h>
#include <assert.h>
#include "wav_parser.h"
#include "sndwav_common.h"

#include <QTimer>

#define USE_KPI_LOGGER

class MicNode : public QThread
{
    Q_OBJECT
public:
    explicit MicNode();
    void init();
    void startWork();
    void setFreq(int freq);

    void run();
    bool handleError();
    bool initWavParams(WAVContainer_t *wav);
    void record_10S_data();
    bool closeSnd();
    bool initSnd();
    void parseRawData(long long lenBytes);

signals:
    void sigMicData(qreal noise);

public slots:
    void triggerWavLogger(QString fileName);
    void tiggerRecorder();
public:
    volatile bool m_logData;
    QMutex  m_mutex;
    QTimer *m_recordTimer;

    int m_loggerfd;
    QByteArray filename;

    int m_Default_Channels;
    int m_Default_Sample_Rate;
    int m_Default_Sample_Length;
    int m_Default_Duration_Time;

    WAVContainer_t m_wavContainer;
    SNDPCMContainer_t m_PCMContainer;

    double m_denominator;
    int m_100msCounter;
#ifdef USE_KPI_LOGGER
    int m_kpifd;
    bool kpiFileOk;
#endif
};

#endif // MICNODE_H
