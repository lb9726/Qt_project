#include "acceleratenode.h"

#include <QCoreApplication>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <float.h>
#include <unistd.h>
#include <linux/input.h>


const char *VibLeftConfig = "echo 3 > /sys/devices/soc0/soc.0/2100000.aips-bus/21a0000.i2c/i2c-0/0-001d/pollrate_ms";
const char *VibRightConfig = "echo 3 > /sys/devices/soc0/soc.0/2100000.aips-bus/21a4000.i2c/i2c-1/1-001d/pollrate_ms";

AccelerateNode::AccelerateNode()
{
    m_postFreq = 10;//10Hz

    m_AccValue[0] = 0;
    m_AccValue[1] = 0;
    m_AccValue[2] = 0;
    m_fileRawData = NULL;

    m_AccdirectionMap[0] = 0;
    m_AccdirectionMap[1] = 1;
    m_AccdirectionMap[2] = 2;
    clearBuffer();
    isDebuging = false;

    m_datapostTimer = new QTimer();
    m_datapostTimer->setInterval(1000);///m_postFreq);

    m_NodeDetectorTimer = new QTimer();
    m_NodeDetectorTimer->setInterval(500);

    connect(m_datapostTimer,&QTimer::timeout,this,&AccelerateNode::accTriggerTimeout);
    connect(m_NodeDetectorTimer,&QTimer::timeout,this,&AccelerateNode::nodeDetecter);
    isNodeConnected = false;
}

bool AccelerateNode::init(int nodeIndex)
{
    m_nodeIndex = nodeIndex;
    if(nodeIndex == 1){
        //IDE_TRACE();
        if(QFile::exists("/sys/devices/soc0/soc.0/2100000.aips-bus/21a0000.i2c/i2c-0/0-001d/pollrate_ms")){
            nodeDevPath = "/dev/input/event0";
            ///
            m_NodeExist = '0';
        }else{
            nodeDevPath = "";
            m_NodeExist = '1';
        }
        //system(Vib1Config);
        m_NodeDetectorFile.setFileName("/sys/class/gpio/gpio133/value");
    }else if(nodeIndex == 2){
        //IDE_TRACE();
        if(QFile::exists("/sys/devices/soc0/soc.0/2100000.aips-bus/21a4000.i2c/i2c-1/1-001d/pollrate_ms")){
            if(QFile::exists("/sys/devices/soc0/soc.0/2100000.aips-bus/21a0000.i2c/i2c-0/0-001d/pollrate_ms")){
                nodeDevPath = "/dev/input/event1";
                //IDE_TRACE();
                m_NodeExist = '0';
            }else{
                nodeDevPath = "/dev/input/event0";
                //IDE_TRACE();
                m_NodeExist = '0';
            }
        }else{
            nodeDevPath = "";
            m_NodeExist = '1';
            //IDE_TRACE();
        }
        //system(Vib1Config);
        m_NodeDetectorFile.setFileName("/sys/class/gpio/gpio134/value");
    }else{
        return false;
    }
    return true;
}

void AccelerateNode::nodeDetecter(){
    char isExist = 0x0;
    if(m_NodeDetectorFile.open(QFile::ReadOnly)){
        //IDE_TRACE();
        if(m_NodeDetectorFile.getChar(&isExist)){
            if(isExist == '0' && m_NodeExist == '1'){
                IDE_TRACE_STR("Node Insert");
                emit sigNodeInsert();
            }/*else if (isExist == '0' && !isNodeConnected){
                IDE_TRACE_STR("Node Insert ");
            }*/else if (isExist == '1'){
                isNodeConnected = false;
                emit sigRemoved();
                //IDE_TRACE_STR("Node Remove");
            }else{

            }
            m_NodeExist = isExist;
        }
        m_NodeDetectorFile.close();
    }else{
        ///IDE_TRACE();
    }
}

void AccelerateNode::sltShiftFile(QString filePath){
    Q_UNUSED(filePath);
    //IDE_TRACE();
    QString m_fileName;
    if(m_nodeIndex == 1){
        m_fileName  = getCurrentHourFileNameBase() +"addvib.csv";
        m_fileRawData = new QFile();
        m_fileRawData->setFileName(m_fileName);
    }

    if(m_nodeIndex == 2){
        m_fileName  = getCurrentHourFileNameBase()+"gbvib.csv";
        m_fileRawData = new QFile();
        m_fileRawData->setFileName(m_fileName);
    }
    bool isExist;
    isExist =  m_fileRawData->exists() ? true:false;
    if(m_fileRawData&&m_fileRawData->open(QIODevice::WriteOnly)){
        if(!isExist){
            QByteArray ba;
            ba.append(getTimeStamp()+",");
            if(m_nodeIndex == 1){
                ba.append("addVibForward,").append("addVibLateral,");
                ba.append("addVibVertical").append("\r\n");
            }else{
                ba.append("GBVibForward,").append("GBVibLateral,");
                ba.append("GBVibVertical").append("\r\n");
            }
            m_fileRawData->write(ba,ba.count());
            ///IDE_TRACE();
        }
        m_logData = true;
        //IDE_TRACE();
    }else{
        m_logData = false;
        delete m_fileRawData;
        m_fileRawData =  NULL;
    }
}

void AccelerateNode::startWork()
{
    IDE_TRACE_STR(nodeDevPath);
    if(QFile::exists(nodeDevPath)){
        isNodeConnected = true;
        IDE_TRACE();
        start();
    }else{
        isNodeConnected = false;
        IDE_TRACE();
    }
    m_NodeDetectorTimer->start();
}

void AccelerateNode::accTriggerTimeout(){
    QMutexLocker locker(&m_muxtex);
    qreal forward = m_AccValue[m_AccdirectionMap[0]];
    qreal lateral = m_AccValue[m_AccdirectionMap[1]];
    qreal vertical = m_AccValue[m_AccdirectionMap[2]];

    qreal absForward = abs(forward);
    qreal absLateral = abs(lateral);
    qreal absVertical = abs(vertical);

    m_forwardPeak = absForward > m_forwardPeak ? absForward : m_forwardPeak;
    m_lateralPeak = absLateral > m_lateralPeak ? absLateral : m_lateralPeak;
    m_verticalPeak = absVertical > m_verticalPeak ? absVertical : m_verticalPeak;

    if(m_logData){
        QByteArray ba;
        ba.append(getTimeStamp());
        QString str = QString(",%1,%2,%3\n").arg(toFixedFloat(forward/1000,4))\
                .arg(toFixedFloat(lateral/1000,4)).arg(toFixedFloat(vertical/1000,4));
        ba.append(str);
        m_fileRawData->write(ba,ba.count());
    }
    m_forwardQueue.append(forward);
    m_lateralQueue.append(lateral);
    m_verticalQueue.append(vertical);
    if(m_verticalQueue.count() == 12000){
        /*
        m_forwardRMS = RMS1();
        m_lateralRMS = RMS2();
        m_verticalRMS = RMS3();
        */
        m_forwardQueue.clear();
        m_lateralQueue.clear();
        m_verticalQueue.clear();
        //m_forwardPeak = 0;//
        //m_lateralPeak = 0;//
        //m_verticalPeak = 0;//
    }
    emit  sigAccData(forward,lateral,vertical);
}

void AccelerateNode::loggerData(){
    ///IDE_TRACE();
    if(m_forwardQueue.count() == m_lateralQueue.count() && \
            m_lateralQueue.count() == m_verticalQueue.count() &&\
            m_verticalQueue.count() == m_timeStamp.count()){
        //        calqForward();
        //        calqLateral();
        //        calqVertical();

        int dataLenght = m_forwardQueue.count();
        QMutexLocker locker(&m_muxtex);
        if(m_fileRawData&&m_fileRawData->isOpen())
        {
            for(int i=0;i<dataLenght;i++){
                QByteArray ba;
                QString str = QString("%1,%2,%3,%4\n").arg(m_timeStamp.at(i).toString("yyyy/MM/dd hh:mm:ss.zzz"))\
                        .arg(toFixedString(m_forwardQueue.at(i)/1000.0,3))\
                        .arg(toFixedString(m_lateralQueue.at(i)/1000.0,3))\
                        .arg(toFixedString((qreal)(m_verticalQueue.at(i)/1000.0),3));
                ba.append(str);
                ///IDE_TRACE_STR(str);
                m_fileRawData->write(ba,ba.length());
            }
            m_fileRawData->flush();
        }
    }
    clearBuffer();
}

bool AccelerateNode::clearBuffer()
{
    m_forwardQueue.clear();
    m_lateralQueue.clear();
    m_verticalQueue.clear();
    m_timeStamp.clear();

    m_forwardQueue.reserve(15000);
    m_lateralQueue.reserve(15000);
    m_verticalQueue.reserve(15000);
    m_timeStamp.reserve(15000);

    m_forwardPeak = 0;///QREAL_MIN;
    m_lateralPeak = 0;///QREAL_MIN;
    m_verticalPeak = 0;///QREAL_MIN;
    return true;
}

void AccelerateNode::setFreq(int freq)
{
    if(m_postFreq<1||m_postFreq>200)
        return;
    m_postFreq = freq;
    m_datapostTimer->setInterval(1000/m_postFreq);
}

void AccelerateNode::setDebugMode(bool isDebug){
    if(isDebuging != isDebug){
        isDebuging = isDebug;
    }else{
        return;
    }
    if(isDebuging){
        IDE_TRACE();
        if(m_fileRawData){
            m_fileRawData->close();
            delete m_fileRawData;
            m_fileRawData = NULL;
            IDE_TRACE();
        }
    }else{
        IDE_TRACE();
        sltShiftFile("");
    }
    IDE_TRACE();
}

void AccelerateNode::run()
{
#ifdef  IMX
    QByteArray path;
    path.append(nodeDevPath);
    int fd;
    struct input_event accevent;
    fd = open(path.data(), O_RDONLY);
    if(fd <= 0)
    {
        isNodeConnected = false;
        IDE_TRACE_STR(QString("Open %1 failed").arg(nodeDevPath));
        return;
    }

    long int lastMs = 0;
    long int thisMs = 0;
    quint64 timestamp;
    quint64 sec;
    quint64 usec;
    while(isNodeConnected)///while(1)
    {
        if(read(fd, &accevent, sizeof(accevent)) == sizeof(accevent))
        {
            if(accevent.type == EV_MSC){
                if(accevent.code == MSC_SERIAL){
                    m_AccValue[0] = accevent.value;
                }else if(accevent.code == MSC_PULSELED){
                    m_AccValue[1] = -accevent.value;
                }else if(accevent.code == MSC_GESTURE){
                    m_AccValue[2] = accevent.value;
                    sec = accevent.time.tv_sec;
                    usec = accevent.time.tv_usec;
                    //qDebug()<<t.time.tv_usec/1000;
                    thisMs = usec/1000;
                    timestamp = sec*1000 + usec/1000;
                    m_timeStamp.append(QDateTime::fromMSecsSinceEpoch(timestamp));
                    if(lastMs - thisMs > 900){
                        loggerData();
                    }
                    lastMs = thisMs;
                    m_forwardQueue.append(m_AccValue[m_AccdirectionMap[0]]);
                    m_lateralQueue.append(m_AccValue[m_AccdirectionMap[1]]);
                    m_verticalQueue.append(m_AccValue[m_AccdirectionMap[2]]);
                    emit sigAccData(m_AccValue[m_AccdirectionMap[0]]\
                            ,m_AccValue[m_AccdirectionMap[1]]\
                            ,m_AccValue[m_AccdirectionMap[2]]);
//                    if(m_nodeIndex == 1){
//                        qDebug()<<"1AccValue "<<m_AccValue[0]<<m_AccValue[1]<<m_AccValue[2];
//                        qDebug()<<"1AccelerateNode "<<m_AccValue[m_AccdirectionMap[0]]<<m_AccValue[m_AccdirectionMap[1]]<<m_AccValue[m_AccdirectionMap[2]];
//                    }

//                    if(m_nodeIndex == 2){
//                        qDebug()<<"2AccValue "<<m_AccValue[0]<<m_AccValue[1]<<m_AccValue[2];
//                        qDebug()<<"2AccelerateNode "<<m_AccValue[m_AccdirectionMap[0]]<<m_AccValue[m_AccdirectionMap[1]]<<m_AccValue[m_AccdirectionMap[2]];
//                    }
                }
            }
        }else{
            IDE_TRACE();
        }
        ///Debug delay for 50ms
        ///msleep(100);
    }
    close(fd);
#endif
}

bool AccelerateNode::isAccNodeConnected(){
    return isNodeConnected;
}

void AccelerateNode::calqForward()
{
    if(m_forwardQueue.isEmpty()){
        return;
    }
    qreal rms = 0.0;
    quint32 data;
    for(int i=0;i < m_forwardQueue.count();i++){
        data = abs(m_forwardQueue.at(i));
        m_forwardPeak = data > m_forwardPeak ? data : m_forwardPeak;
        rms += pow(data,2);
    }
    m_forwardRMS = toFixedFloat(qSqrt(rms/m_forwardQueue.count())/1000.0,3);
}

void AccelerateNode::calqLateral()
{
    if(m_lateralQueue.isEmpty()){
        return;
    }
    qreal rms = 0.0;
    quint32 data;
    for(int i=0;i < m_lateralQueue.count();i++){
        data = abs(m_lateralQueue.at(i));
        m_lateralPeak = data > m_lateralPeak ? data : m_lateralPeak;
        rms += pow(data,2);
    }
    m_lateralRMS = toFixedFloat(qSqrt(rms/m_lateralQueue.count())/1000.0,3);
}

void AccelerateNode::calqVertical()
{
    if(m_verticalQueue.isEmpty()){
        return;
    }
    qreal rms = 0.0;
    quint32 data;
    for(int i=0;i < m_verticalQueue.count();i++){
        data = abs(m_verticalQueue.at(i));
        m_verticalPeak = data > m_verticalPeak ? data : m_verticalPeak;
        rms += pow(data,2);
    }
    m_verticalRMS = toFixedFloat(qSqrt(rms/m_verticalQueue.count())/1000.0,3);
}

void AccelerateNode::setDirectionMap(QString map){
    if(map.isEmpty())
        return;
    QStringList list = map.split(",");
    if(list.count()!=3)
        return ;
    setDirectionMap(list.at(0).toInt(),list.at(1).toInt(),list.at(2).toInt());
}

void AccelerateNode::setDirectionMap(uint forward,uint lateral,uint vertical)
{


    if(forward == lateral||forward == vertical||lateral == vertical){
        IDE_TRACE();
        return;
    }else if(forward > 2){
        IDE_TRACE();
        return;
    }else if(lateral > 2){
        IDE_TRACE();
        return;
    }else if(vertical > 2){
        IDE_TRACE();
        return;
    }
    QMutexLocker locker(&m_muxtex);
    m_AccdirectionMap[0] = forward;
    m_AccdirectionMap[1] = lateral;
    m_AccdirectionMap[2] = vertical;

    //    IDE_TRACE_INT(m_AccdirectionMap[0]);
    //    IDE_TRACE_INT(m_AccdirectionMap[1]);
    //    IDE_TRACE_INT(m_AccdirectionMap[2]);
}

