#ifndef ACCELERATENODE_H
#define ACCELERATENODE_H

#include <QObject>
#include <QThread>
#include <QTimer>
#include <QMutex>
#include <QFile>
#include "../define.h"
#include <QQueue>
#include <QDateTime>
#include <QDate>
#include <QTime>
#include <QDir>
#include <QtMath>


class AccelerateNode : public QThread
{
    Q_OBJECT
public:
    explicit AccelerateNode();
    bool init(int nodeIndex);
    void startWork();
    void setFreq(int freq);
    void setDebugMode(bool isDebug);
    void run();
    bool isAccNodeConnected();
signals:
    void sigAccData(qreal forward, qreal lateral, qreal vertical);
    void sigNodeInsert();
    void sigRemoved();
public slots:
    void sltShiftFile(QString filePath);
    void accTriggerTimeout();
    void setDirectionMap(uint forward, uint lateral, uint vertical);
    void setDirectionMap(QString map);
    void nodeDetecter();
public:
    bool isNodeConnected;
    QString nodeDevPath;
    volatile int m_postFreq;
    QTimer *m_datapostTimer;
    int m_AccValue[3];///对应LSM303C的x/y/z物理数值
    ///forward/lateral/vertical与m_AccValue的对应关系
    ///0-X,1-Y,2-Z,与m_AccValue数组下表对应，且m_AccdirectionMap的3个数值必须互斥
    volatile int m_AccdirectionMap[3];
    QMutex m_muxtex;

    QFile *m_fileRawData;
    bool m_logData;


    QQueue<int> m_forwardQueue;
    QQueue<int> m_lateralQueue;
    QQueue<int> m_verticalQueue;
    QQueue<QDateTime> m_timeStamp;
    void calqForward();
    void calqLateral();
    void calqVertical();


    qreal m_forwardRMS;
    qreal m_forwardPeak;

    qreal m_lateralRMS;
    qreal m_lateralPeak;

    qreal m_verticalRMS;
    qreal m_verticalPeak;

    void loggerData();
    bool clearBuffer();
    volatile int iCounter;

    int m_nodeIndex;
    volatile bool isDebuging;
    QFile m_NodeDetectorFile;
    QTimer*  m_NodeDetectorTimer;
    char  m_NodeExist;//0- connect, 1-Not connect
};

#endif // ACCELERATENODE_H
