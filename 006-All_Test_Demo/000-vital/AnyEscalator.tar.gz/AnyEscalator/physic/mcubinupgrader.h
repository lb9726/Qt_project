#ifndef MCUBINUPGRADER_H
#define MCUBINUPGRADER_H

#include <QObject>
#include <QFile>

class mcuBinUpgrader : public QObject
{
    Q_OBJECT
public:
    explicit mcuBinUpgrader(QObject *parent = 0);
    bool isNeedUpgrade();
signals:

public slots:

public:
    QByteArray binFilePath;
    QByteArray mcuBinData;
    quint32  totalByteSize;
    quint32  currentBytePos;
    quint32  currentFrameCount;
    quint32  bytePerFrame;
    bool unbindFile();
    bool bindFile();
    QByteArray currentFrame();
    QByteArray nextFrame();
    QByteArray m_currentFrame;
};

#endif // MCUBINUPGRADER_H
