#include "ledcontroller.h"
#include "define.h"
#include <QFile>
const char light_on = '1';
const char light_off = '0';
LedController::LedController(QObject *parent) : QObject(parent)
{
#ifdef UNITTEST
    testFlag = false;
    m_timer.setInterval(2000);
    connect(&m_timer,&QTimer::timeout,this,&LedController::testSlot);
    m_timer.start();
#endif
}
#ifdef UNITTEST
void LedController::testSlot(){
    testFlag = !testFlag;
    if(testFlag){
        LedController::powerOnLight();
        ///LedController::deviceErrorLight(true);
        LedController::deviceModeLight(true);
        LedController::onlineLight(true);
    }else{
        LedController::powerOnLight(false);
        LedController::deviceErrorLight(false);
        LedController::deviceModeLight(false);
        LedController::onlineLight(false);
    }
}
#endif
void LedController::powerOnLight(bool flag)
{
//    QFile file("/sys/class/leds/poweron-led/brightness");
//    if(file.open(QIODevice::WriteOnly)){
//        if(flag)
//            file.write(&light_on,1);
//        else
//            file.write(&light_off,1);
//    }else{
//        IDE_TRACE();
//    }
}

void LedController::onlineLight(bool flag)
{
//    QFile file("/sys/class/leds/online-led/brightness");
//    if(file.open(QIODevice::WriteOnly)){
//        if(flag)
//            file.write(&light_on,1);
//        else
//            file.write(&light_off,1);
//    }else{
//        IDE_TRACE();
//    }

    QFile file("/sys/class/leds/devicemode-led/brightness");
    if(file.open(QIODevice::WriteOnly)){
        if(flag)
            file.write(&light_on,1);
        else
            file.write(&light_off,1);
        file.close();
    }else{
        IDE_TRACE();
    }
}

void LedController::deviceModeLight(bool flag)
{
//    QFile file("/sys/class/leds/devicemode-led/brightness");
//    if(file.open(QIODevice::WriteOnly)){
//        if(flag)
//            file.write(&light_on,1);
//        else
//            file.write(&light_off,1);
//    }else{
//        IDE_TRACE();
//    }

    QFile file("/sys/class/leds/online-led/brightness");
    if(file.open(QIODevice::WriteOnly)){
        if(flag)
            file.write(&light_on,1);
        else
            file.write(&light_off,1);
    }else{
        IDE_TRACE();
    }
}

void LedController::deviceErrorLight(bool flag)
{
//    QFile file("/sys/class/leds/deviceerror-led/brightness");
//    if(file.open(QIODevice::WriteOnly)){
//        if(flag)
//            file.write(&light_on,1);
//        else
//            file.write(&light_off,1);
//    }else{
//        IDE_TRACE();
//    }

    QFile file("/sys/class/leds/poweron-led/brightness");
    if(file.open(QIODevice::WriteOnly)){
        if(flag)
            file.write(&light_on,1);
        else
            file.write(&light_off,1);
    }else{
        IDE_TRACE();
    }
}

