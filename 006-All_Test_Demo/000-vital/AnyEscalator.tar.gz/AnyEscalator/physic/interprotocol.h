#ifndef INTERPROTOCOL_H
#define INTERPROTOCOL_H

#include <QObject>
#include <QSerialPort>
#include <QTimer>
#include <QTcpServer>
#include <QMap>
#include <QTcpSocket>
#include <QFile>
#include "sensor/sensordefine.h"
#include "mcubinupgrader.h"
//#define UseNetworkTest

enum Frame_TYPE {
    HeartBeat = 0x00,
    SensorData = 0x01,
    ConnectStatus = 0x02,
    ParameterConfigure = 0x10,
    UpgradCmd = 0x12,
    UpgradCmdAck = 0x14,
    UpgradData = 0x13,
    McuVersion = 0x11,
    UnkownFrame = 0xFF
};

enum Upgrad_Stage {
    NoNeedUpgrad = 0x00,
    StartUpgrad = 0x01,
    FinishUpgrad = 0x02,
    EnterUpgrad = 0x03,
};

enum UpgradReply_Status {
    NormalRunning = 0x00,
    RequireSucceed = 0x01,
    LeasrFrameConfirmed = 0x02,
    ReSendLeastFrame = 0x03,
};

enum SensorNode {
    IR_Left	     = 0x00,
    IR_Right     = 0x01,
    TEMP_Left    = 0x02,
    TEMP_Right	 = 0x03,
    RS485        = 0x04,
    People_Count = 0x05,
    DI	         = 0x06,
    Vib_Left	 = 0x07,
    Vib_Right    = 0x08,
    AllNodes    = 0x09
};

enum McuUpgradStatu {
    McuUpgrad_Unstart,
    McuUpgrad_Start,
    McuUpgrad_Data,
    McuUpgrad_Finish,
    McuUpgrad_Error
};


class InterProtocol : public QObject
{
    Q_OBJECT
public:
    explicit InterProtocol(QObject *parent = 0);

    void init();


    bool OpenCom();

    quint32 ParseBuffer(QByteArray &buffer);
    quint32 ParseFrame();

    quint32 sensorData(QByteArray &data);
    quint32 parameterConfigure(QByteArray &data);
    quint32 heartBeat(quint16 counter);
    quint32 connectStatus(QByteArray &data);
    quint32 upgradCmdAck(QByteArray &data);
    quint32 upgradData(QByteArray &data);
    quint32 mcuVersion(QByteArray &data);



    void readyRead();
    quint32 replyHeatBeatFrame(quint16 counter);
    qint64 sendFrame(QByteArray &ba);
    void sendHB(quint16 counter);
    void sendCmd(QString cmd);
    void sendFreq(SENSOR_TYPE sensor, qreal value);
    void initTcpTest(int port);
signals:
    void sigThermData(QString data);
    void sigInfraData(QString data);
    void sigPowerData(QString data);
    void sigSpeedData(QString data);
    void sigPeopleCountData(QString data);
    void sigDirectionData(QString data);


    void sigThermCmd(QString data);
    void sigInfraCmd(QString data);
    void sigPowerCmd(QString data);

    void sigNodeConnectStatus(quint8 node,bool isConnect);
public slots:
    void startWork();
    void hbTimerOut();

#ifdef UseNetworkTest
private slots:
    void newConnectSlot();
    void readMessage();
    void slotSendMesg(QByteArray &data);
    void clientDisconnected();
#endif

    quint32 triggUpgradMcu();
public:
    QByteArray  m_FrameBuffer;
    QSerialPort  *m_comPort;
    QTimer  *m_HBTimeoutTimer;
    quint16  m_HBCount;

#ifdef UseNetworkTest
    bool isConnected;
    QTcpServer *m_pTcpServer;
    QTcpSocket *m_pTcpSocket;
#endif
    bool isNodeAreConnected;
    bool isIR_Left;
    bool isIR_Right;
    bool isTEMP_Left;
    bool isTEMP_Right;
    bool isRS485;


    QFile binFile;
    quint8 mbigVersion;
    quint8 mlitteVersion;

    quint32 noNeedUpgrade();
    quint32 startUpgrade();

    mcuBinUpgrader *m_mcuBinUpgrader;

    McuUpgradStatu m_upgradStatus;
};






#endif // INTERPROTOCOL_H
