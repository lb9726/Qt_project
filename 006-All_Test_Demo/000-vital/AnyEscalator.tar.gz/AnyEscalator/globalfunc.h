#ifndef GLOBALFUNC
#define GLOBALFUNC

#include <QDate>
#include <QTime>
#include <QDir>
#include <QCoreApplication>


const QString DATA_STORAGE_DIR_NAME = "data";
static const QString NEWLINE_RETURN = "\r\n";
static const QString TIME_STAMP = "Time_Stamp";
//获取指定精度的double数值,避免Json中的科学计数及长精度的显示
inline qreal toFixedFloat(qreal src,int prec = 2){
    if(src > 0.0000001 ||src < -0.0000001)
        return QString::number(src,'f',prec).toDouble();
    else{
        return 0.0;
    }
}

inline QString toFixedString(qreal src,int prec = 2){
    return QString::number(src,'f',prec);
}

inline QString getTimeStamp(){
    return QDate::currentDate().toString("yyyy-MM-ddT")+ QTime::currentTime().toString("hh:mm:ss.zzzZ");
}

inline QString getCurrentHourDir(){
    QString m_baseDirPath;
    QDir dir(QCoreApplication::applicationDirPath());
    dir.mkdir(DATA_STORAGE_DIR_NAME);
    m_baseDirPath = QCoreApplication::applicationDirPath()+"/"+DATA_STORAGE_DIR_NAME+"/";
    dir.cd(DATA_STORAGE_DIR_NAME);
    QString m_curDataDirName = QDate::currentDate().toString("yyyyMMdd");
    QString m_curHourDirName = m_curDataDirName + QTime::currentTime().toString("_hh");
    dir.mkdir(m_curDataDirName);
    dir.cd(m_curDataDirName);
    dir.mkdir(m_curHourDirName);
    return m_baseDirPath + m_curDataDirName +"/"+m_curHourDirName+"/";
}

inline QString getCurrentHourFileNameBase(){
    //QString datetimeName = QDateTime::currentDateTime().toString("yyyyMMdd_hh_mm_ss_");
    return getCurrentHourDir() + QDateTime::currentDateTime().toString("yyyyMMdd_hh_00_00_");
}


#endif // GLOBALFUNC

