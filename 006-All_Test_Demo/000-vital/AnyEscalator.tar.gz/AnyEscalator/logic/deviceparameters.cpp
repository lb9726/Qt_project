#include "deviceparameters.h"
#include "logicheader.h"
#include "../sensor/configureparser.h"
#include "../utility/websocket/websocketclient.h"
#include "../define.h"

DeviceParameters::DeviceParameters(ConfigureParser *cp)
{
    m_cp = cp;

    m_KPIinterval = 60;
    m_sleepthresholdmain = 60;
    m_sleepthresholdsecondary = 30;
    m_sleepthresholdstep = 60;

    m_GBVIBFORWARDDIR = 2;
    m_GBVIBLATERALDDIR = 0;
    m_GBVIBVERTICALDIR = 1;

    m_ADDVIBFORWARDDIR = 2;
    m_ADDVIBLATERALDDIR = 0;
    m_ADDVIBVERTICALDIR = 1;

    m_GBVIBXOFFSET = 0;
    m_GBVIBYOFFSET = 0;
    m_GBVIBZOFFSET = 0;

    m_ADDVIBXOFFSET = 0;
    m_ADDVIBYOFFSET = 0;
    m_ADDVIBZOFFSET = 0;

    initParameters();
}

//DeviceParameters::DeviceParameters(QSettings *setting)
//{
//    ///m_settings = setting;
////    if(setting){
////        initParameters();
////    }
//}

void DeviceParameters::setWSClient(WebSocketClient *wsClient){
    this->m_wsClient = wsClient;
}

void DeviceParameters::reportDeviceParameters(){
    QJsonObject RootObj;
    QJsonObject anyecsalatorParameters;

    RootObj.insert("Message",QJsonValue("ConfigurationChange"));
    RootObj.insert("Version",QJsonValue(SERVER_VERSION));
    RootObj.insert("AnyEscalatorID",QJsonValue(AnyEscalator_ID));
    RootObj.insert("Timestamp",QJsonValue(getTimeStamp()));
    anyecsalatorParameters.insert("GBVIBFORWARDDIR",QJsonValue(m_GBVIBFORWARDDIR));
    anyecsalatorParameters.insert("GBVIBLATERALDDIR",QJsonValue(m_GBVIBLATERALDDIR));
    anyecsalatorParameters.insert("GBVIBVERTICALDIR",QJsonValue(m_GBVIBVERTICALDIR));

    anyecsalatorParameters.insert("ADDVIBFORWARDDIR",QJsonValue(m_ADDVIBFORWARDDIR));
    anyecsalatorParameters.insert("ADDVIBLATERALDDIR",QJsonValue(m_ADDVIBLATERALDDIR));
    anyecsalatorParameters.insert("ADDVIBVERTICALDIR",QJsonValue(m_ADDVIBVERTICALDIR));

    anyecsalatorParameters.insert("GBVIBXOFFSET",QJsonValue(getAxisInfo(m_GBVIBXOFFSET)));
    anyecsalatorParameters.insert("GBVIBYOFFSET",QJsonValue(getAxisInfo(m_GBVIBYOFFSET)));
    anyecsalatorParameters.insert("GBVIBZOFFSET",QJsonValue(getAxisInfo(m_GBVIBZOFFSET)));

    anyecsalatorParameters.insert("ADDVIBXOFFSET",QJsonValue(getAxisInfo(m_ADDVIBXOFFSET)));
    anyecsalatorParameters.insert("ADDVIBYOFFSET",QJsonValue(getAxisInfo(m_ADDVIBYOFFSET)));
    anyecsalatorParameters.insert("ADDVIBZOFFSET",QJsonValue(getAxisInfo(m_ADDVIBZOFFSET)));

    anyecsalatorParameters.insert("KPIinterval",QJsonValue(m_KPIinterval));
    anyecsalatorParameters.insert("sleepthresholdmain",QJsonValue(m_sleepthresholdmain));
    anyecsalatorParameters.insert("sleepthresholdsecondary",QJsonValue(m_sleepthresholdsecondary));
    anyecsalatorParameters.insert("sleepthresholdstep",QJsonValue(m_sleepthresholdstep));

    RootObj.insert("AnyEscalatorParameters",QJsonValue(anyecsalatorParameters));
    //m_wsClient->sendJson(RootObj);
    emit sigSendJsonMsg(RootObj);
}

QString DeviceParameters::getAxisInfo(int axis){
    if(axis == 0){
        return "X";
    }else if(axis == 1){
        return "Y";
    }else if(axis == 2){
        return "Z";
    }else{
        return "";
    }
}

void DeviceParameters::initParameters(){
    ///IDE_TRACE();
    QDomElement tmpElement;
    QString domText;
    int domValue;
    QDomElement dom = m_cp->getParameter();
    m_parameterDom = dom;
    QDomNodeList SubuiNodeList = dom.childNodes();
    for(int i=0;i<SubuiNodeList.count();i++)
    {
        tmpElement = SubuiNodeList.at(i).toElement();
        domText = tmpElement.text();
        domValue = domText.toInt();
        if(!QString::compare(tmpElement.tagName(),"GBVIBFORWARDDIR",Qt::CaseInsensitive)){
            m_GBVIBFORWARDDIR = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"GBVIBLATERALDDIR",Qt::CaseInsensitive)){
            m_GBVIBLATERALDDIR = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"GBVIBVERTICALDIR",Qt::CaseInsensitive)){
            m_GBVIBVERTICALDIR = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"ADDVIBFORWARDDIR",Qt::CaseInsensitive)){
            m_ADDVIBFORWARDDIR = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"ADDVIBLATERALDDIR",Qt::CaseInsensitive)){
            m_ADDVIBLATERALDDIR = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"ADDVIBVERTICALDIR",Qt::CaseInsensitive)){
            m_ADDVIBVERTICALDIR = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"GBVIBXOFFSET",Qt::CaseInsensitive)){
            m_GBVIBXOFFSET = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"GBVIBYOFFSET",Qt::CaseInsensitive)){
            m_GBVIBYOFFSET = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"GBVIBZOFFSET",Qt::CaseInsensitive)){
            m_GBVIBZOFFSET = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"ADDVIBXOFFSET",Qt::CaseInsensitive)){
            m_ADDVIBXOFFSET = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"ADDVIBYOFFSET",Qt::CaseInsensitive)){
            m_ADDVIBYOFFSET = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"ADDVIBZOFFSET",Qt::CaseInsensitive)){
            m_ADDVIBZOFFSET = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"KPIinterval",Qt::CaseInsensitive)){
            m_KPIinterval = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"sleepthresholdmain",Qt::CaseInsensitive)){
            m_sleepthresholdmain = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"sleepthresholdsecondary",Qt::CaseInsensitive)){
            m_sleepthresholdsecondary = domValue;
        }else if(!QString::compare(tmpElement.tagName(),"sleepthresholdstep",Qt::CaseInsensitive)){
            m_sleepthresholdstep = domValue;
        }else{

        }
    }
}

QJsonObject DeviceParameters::getDeviceParameters()
{
    QJsonObject RootObj;
    QJsonObject anyecsalatorParameters;

    RootObj.insert("Message",QJsonValue("ConfigurationChange"));
    ///RootObj.insert("Version",QJsonValue(appSoftwareVersion));
    RootObj.insert("Version",QJsonValue(0));
    RootObj.insert("AnyEscalatorID",QJsonValue(AnyEscalator_ID));
    RootObj.insert("Timestamp",QJsonValue(getTimeStamp()));

    anyecsalatorParameters.insert("KPIinterval",QJsonValue(m_KPIinterval));
    anyecsalatorParameters.insert("sleepthresholdmain",QJsonValue(m_sleepthresholdmain));
    anyecsalatorParameters.insert("sleepthresholdsecondary",QJsonValue(m_sleepthresholdsecondary));
    anyecsalatorParameters.insert("sleepthresholdstep",QJsonValue(m_sleepthresholdstep));

    anyecsalatorParameters.insert("GBVIBFORWARDDIR",QJsonValue(m_GBVIBFORWARDDIR));
    anyecsalatorParameters.insert("GBVIBLATERALDDIR",QJsonValue(m_GBVIBLATERALDDIR));
    anyecsalatorParameters.insert("GBVIBVERTICALDIR",QJsonValue(m_GBVIBVERTICALDIR));

    anyecsalatorParameters.insert("ADDVIBFORWARDDIR",QJsonValue(m_ADDVIBFORWARDDIR));
    anyecsalatorParameters.insert("ADDVIBLATERALDDIR",QJsonValue(m_ADDVIBLATERALDDIR));
    anyecsalatorParameters.insert("ADDVIBVERTICALDIR",QJsonValue(m_ADDVIBVERTICALDIR));

    anyecsalatorParameters.insert("GBVIBXOFFSET",QJsonValue(m_GBVIBXOFFSET));
    anyecsalatorParameters.insert("GBVIBYOFFSET",QJsonValue(m_GBVIBYOFFSET));
    anyecsalatorParameters.insert("GBVIBZOFFSET",QJsonValue(m_GBVIBZOFFSET));

    anyecsalatorParameters.insert("ADDVIBXOFFSET",QJsonValue(m_ADDVIBXOFFSET));
    anyecsalatorParameters.insert("ADDVIBYOFFSET",QJsonValue(m_ADDVIBYOFFSET));
    anyecsalatorParameters.insert("ADDVIBZOFFSET",QJsonValue(m_ADDVIBZOFFSET));

    RootObj.insert("AnyEscalatorParameters",QJsonValue(anyecsalatorParameters));
    qDebug()<<"anyecsalatorParameters"<<anyecsalatorParameters;
    return RootObj;
}

void DeviceParameters::setDeviceParameters(QJsonObject &obj)
{
    ///No power meter in AnyEscalatorParameters Msg.
    if(!obj.isEmpty()){
        QJsonValue parametersValue = obj.value("AnyEscalatorParameters");
        if(parametersValue.isObject()){
            QJsonValue tmpValue;
            int tmpInt;
            QJsonObject obj =  parametersValue.toObject();

            if(obj.contains("GBVIBFORWARDDIR")){
                tmpValue = obj.value("GBVIBFORWARDDIR");
                tmpInt = tmpValue.toInt();
                if(m_GBVIBFORWARDDIR != tmpInt){
                    m_GBVIBFORWARDDIR = tmpInt;
                }
            }
            if(obj.contains("GBVIBLATERALDDIR")){
                tmpValue = obj.value("GBVIBLATERALDDIR");
                tmpInt = tmpValue.toInt();
                if(m_GBVIBLATERALDDIR != tmpInt){
                    m_GBVIBLATERALDDIR = tmpInt;
                }
            }
            if(obj.contains("GBVIBVERTICALDIR")){
                tmpValue = obj.value("GBVIBVERTICALDIR");
                tmpInt = tmpValue.toInt();
                if(m_GBVIBVERTICALDIR != tmpInt){
                    m_GBVIBVERTICALDIR = tmpInt;
                }
            }

            //        GBVIBFORWARDDIR
            //        GBVIBLATERALDDIR
            //        GBVIBVERTICALDIR
            if(obj.contains("ADDVIBFORWARDDIR")){
                tmpValue = obj.value("ADDVIBFORWARDDIR");
                tmpInt = tmpValue.toInt();
                if(m_ADDVIBFORWARDDIR != tmpInt){
                    m_ADDVIBFORWARDDIR = tmpInt;
                }
            }
            if(obj.contains("ADDVIBLATERALDDIR")){
                tmpValue = obj.value("ADDVIBLATERALDDIR");
                tmpInt = tmpValue.toInt();
                if(m_ADDVIBLATERALDDIR != tmpInt){
                    m_ADDVIBLATERALDDIR = tmpInt;
                }
            }
            if(obj.contains("ADDVIBVERTICALDIR")){
                tmpValue = obj.value("ADDVIBVERTICALDIR");
                tmpInt = tmpValue.toInt();
                if(m_ADDVIBVERTICALDIR != tmpInt){
                    m_ADDVIBVERTICALDIR = tmpInt;
                }
            }
            //        ADDVIBFORWARDDIR
            //        ADDVIBLATERALDDIR
            //        ADDVIBVERTICALDIR
            if(obj.contains("GBVIBXOFFSET")){
                tmpValue = obj.value("GBVIBXOFFSET");
                tmpInt = tmpValue.toInt();
                if(m_GBVIBXOFFSET != tmpInt){
                    m_GBVIBXOFFSET = tmpInt;
                }
            }
            if(obj.contains("GBVIBYOFFSET")){
                tmpValue = obj.value("GBVIBYOFFSET");
                tmpInt = tmpValue.toInt();
                if(m_GBVIBYOFFSET != tmpInt){
                    m_GBVIBYOFFSET = tmpInt;
                }
            }
            if(obj.contains("GBVIBZOFFSET")){
                tmpValue = obj.value("GBVIBZOFFSET");
                tmpInt = tmpValue.toInt();
                if(m_GBVIBZOFFSET != tmpInt){
                    m_GBVIBZOFFSET = tmpInt;
                }
            }

            if(obj.contains("ADDVIBXOFFSET")){
                tmpValue = obj.value("ADDVIBXOFFSET");
                tmpInt = tmpValue.toInt();
                if(m_ADDVIBXOFFSET != tmpInt){
                    m_ADDVIBXOFFSET = tmpInt;
                }
            }
            if(obj.contains("ADDVIBYOFFSET")){
                tmpValue = obj.value("ADDVIBYOFFSET");
                tmpInt = tmpValue.toInt();
                if(m_ADDVIBYOFFSET != tmpInt){
                    m_ADDVIBYOFFSET = tmpInt;
                }
            }
            if(obj.contains("ADDVIBZOFFSET")){
                tmpValue = obj.value("ADDVIBZOFFSET");
                tmpInt = tmpValue.toInt();
                if(m_ADDVIBZOFFSET != tmpInt){
                    m_ADDVIBZOFFSET = tmpInt;
                }
            }


            ///emit
            if(obj.contains("KPIinterval")){
                tmpValue = obj.value("KPIinterval");
                tmpInt = tmpValue.toInt();
                if(m_KPIinterval != tmpInt){
                    m_KPIinterval = tmpInt;
                    emit sigKPIintervalChanged(m_KPIinterval);
                }
            }
            if(obj.contains("sleepthresholdmain")){
                tmpValue = obj.value("sleepthresholdmain");
                tmpInt = tmpValue.toInt();
                if(m_sleepthresholdmain != tmpInt){
                    m_sleepthresholdmain = tmpInt;
                }
            }
            if(obj.contains("sleepthresholdsecondary")){
                tmpValue = obj.value("sleepthresholdsecondary");
                tmpInt = tmpValue.toInt();
                if(m_sleepthresholdsecondary != tmpInt){
                    m_sleepthresholdsecondary = tmpInt;
                }
            }
            if(obj.contains("sleepthresholdstep")){
                tmpValue = obj.value("sleepthresholdstep");
                tmpInt = tmpValue.toInt();
                if(m_sleepthresholdstep != tmpInt){
                    m_sleepthresholdstep = tmpInt;
                }
            }
        }
        saveParameters();
    }
}

int DeviceParameters::getDeviceParameter(QString name){
    if(!name.isEmpty()){
        if(!name.compare("GBVIBFORWARDDIR",Qt::CaseInsensitive)){
            return m_GBVIBFORWARDDIR;
        }

        if(!name.compare("GBVIBLATERALDDIR",Qt::CaseInsensitive)){
            return m_GBVIBLATERALDDIR;
        }

        if(!name.compare("GBVIBVERTICALDIR",Qt::CaseInsensitive)){
            return m_GBVIBVERTICALDIR;
        }

        if(!name.compare("ADDVIBFORWARDDIR",Qt::CaseInsensitive)){
            return m_ADDVIBFORWARDDIR;
        }
        if(!name.compare("ADDVIBLATERALDDIR",Qt::CaseInsensitive)){
            return m_ADDVIBLATERALDDIR;
        }
        if(!name.compare("ADDVIBVERTICALDIR",Qt::CaseInsensitive)){
            return m_ADDVIBVERTICALDIR;
        }

        if(!name.compare("GBVIBXOFFSET",Qt::CaseInsensitive)){
            return m_GBVIBXOFFSET;
        }
        if(!name.compare("GBVIBYOFFSET",Qt::CaseInsensitive)){
            return m_GBVIBYOFFSET;
        }
        if(!name.compare("GBVIBZOFFSET",Qt::CaseInsensitive)){
            return m_GBVIBZOFFSET;
        }



        if(!name.compare("ADDVIBXOFFSET",Qt::CaseInsensitive)){
            return m_ADDVIBXOFFSET;
        }
        if(!name.compare("ADDVIBYOFFSET",Qt::CaseInsensitive)){
            return m_ADDVIBYOFFSET;
        }
        if(!name.compare("ADDVIBZOFFSET",Qt::CaseInsensitive)){
            return m_ADDVIBZOFFSET;

        }

        if(!name.compare("KPIinterval",Qt::CaseInsensitive)){
            return m_KPIinterval;
        }
        if(!name.compare("sleepthresholdmain",Qt::CaseInsensitive)){
            return m_sleepthresholdmain;
        }
        if(!name.compare("sleepthresholdsecondary",Qt::CaseInsensitive)){
            return m_sleepthresholdsecondary;
        }
        if(!name.compare("sleepthresholdstep",Qt::CaseInsensitive)){
            return m_sleepthresholdstep;
        }
    }
    return 0;
}

void DeviceParameters::setParameter(QString name,int value){
    IDE_TRACE_STR(name);
    if(!name.isEmpty()){

        if(!name.compare("GBVIBFORWARDDIR",Qt::CaseInsensitive)){
            if(m_GBVIBFORWARDDIR != value){
                m_GBVIBFORWARDDIR = value;
            }
        }

        if(!name.compare("GBVIBLATERALDDIR",Qt::CaseInsensitive)){
            if(m_GBVIBLATERALDDIR != value){
                m_GBVIBLATERALDDIR = value;
            }
        }

        if(!name.compare("GBVIBVERTICALDIR",Qt::CaseInsensitive)){
            if(m_GBVIBVERTICALDIR != value){
                m_GBVIBVERTICALDIR = value;
            }
        }

        if(!name.compare("ADDVIBFORWARDDIR",Qt::CaseInsensitive)){
            if(m_ADDVIBFORWARDDIR != value){
                m_ADDVIBFORWARDDIR = value;
            }
        }
        if(!name.compare("ADDVIBLATERALDDIR",Qt::CaseInsensitive)){
            if(m_ADDVIBLATERALDDIR != value){
                m_ADDVIBLATERALDDIR = value;
            }
        }
        if(!name.compare("ADDVIBVERTICALDIR",Qt::CaseInsensitive)){
            if(m_ADDVIBVERTICALDIR != value){
                m_ADDVIBVERTICALDIR = value;
            }
        }

        if(!name.compare("GBVIBXOFFSET",Qt::CaseInsensitive)){
            if(m_GBVIBXOFFSET != value){
                m_GBVIBXOFFSET = value;
            }
        }
        if(!name.compare("GBVIBYOFFSET",Qt::CaseInsensitive)){
            if(m_GBVIBYOFFSET != value){
                m_GBVIBYOFFSET = value;
            }
        }
        if(!name.compare("GBVIBZOFFSET",Qt::CaseInsensitive)){
            if(m_GBVIBZOFFSET != value){
                m_GBVIBZOFFSET = value;
            }
        }


        if(!name.compare("ADDVIBXOFFSET",Qt::CaseInsensitive)){
            if(m_ADDVIBXOFFSET != value){
                m_ADDVIBXOFFSET = value;
            }
        }
        if(!name.compare("ADDVIBYOFFSET",Qt::CaseInsensitive)){
            if(m_ADDVIBYOFFSET != value){
                m_ADDVIBYOFFSET = value;
            }
        }
        if(!name.compare("ADDVIBZOFFSET",Qt::CaseInsensitive)){
            if(m_ADDVIBZOFFSET != value){
                m_ADDVIBZOFFSET = value;
            }
        }


        if(!name.compare("KPIinterval",Qt::CaseInsensitive)){
            IDE_TRACE_INT(value);
            if(m_KPIinterval != value&&value>0){
                m_KPIinterval = value;
                IDE_TRACE();
                emit sigKPIintervalChanged(m_KPIinterval);
            }
        }
        if(!name.compare("sleepthresholdmain",Qt::CaseInsensitive)){
            if(m_sleepthresholdmain != value){
                m_sleepthresholdmain = value;
            }
        }
        if(!name.compare("sleepthresholdsecondary",Qt::CaseInsensitive)){
            if(m_sleepthresholdsecondary != value){
                m_sleepthresholdsecondary = value;
            }
        }
        if(!name.compare("sleepthresholdstep",Qt::CaseInsensitive)){
            if(m_sleepthresholdstep != value){
                m_sleepthresholdstep = value;
            }
        }

        saveParameters();
    }
}

void DeviceParameters::saveParameters(){   
    m_cp->modifyDeviceParameter(m_parameterDom,"GBVIBFORWARDDIR",m_GBVIBFORWARDDIR);
    m_cp->modifyDeviceParameter(m_parameterDom,"GBVIBLATERALDDIR",m_GBVIBLATERALDDIR);
    m_cp->modifyDeviceParameter(m_parameterDom,"GBVIBVERTICALDIR",m_GBVIBVERTICALDIR);

    m_cp->modifyDeviceParameter(m_parameterDom,"ADDVIBFORWARDDIR",m_ADDVIBFORWARDDIR);
    m_cp->modifyDeviceParameter(m_parameterDom,"ADDVIBLATERALDDIR",m_ADDVIBLATERALDDIR);
    m_cp->modifyDeviceParameter(m_parameterDom,"ADDVIBVERTICALDIR",m_ADDVIBVERTICALDIR);

    m_cp->modifyDeviceParameter(m_parameterDom,"GBVIBXOFFSET",m_GBVIBXOFFSET);
    m_cp->modifyDeviceParameter(m_parameterDom,"GBVIBYOFFSET",m_GBVIBYOFFSET);
    m_cp->modifyDeviceParameter(m_parameterDom,"GBVIBZOFFSET",m_GBVIBZOFFSET);

    m_cp->modifyDeviceParameter(m_parameterDom,"ADDVIBXOFFSET",m_ADDVIBXOFFSET);
    m_cp->modifyDeviceParameter(m_parameterDom,"ADDVIBYOFFSET",m_ADDVIBYOFFSET);
    m_cp->modifyDeviceParameter(m_parameterDom,"ADDVIBZOFFSET",m_ADDVIBZOFFSET);


    m_cp->modifyDeviceParameter(m_parameterDom,"KPIinterval",m_KPIinterval);
    m_cp->modifyDeviceParameter(m_parameterDom,"sleepthresholdmain",m_sleepthresholdmain);
    m_cp->modifyDeviceParameter(m_parameterDom,"sleepthresholdsecondary",m_sleepthresholdsecondary);
    m_cp->modifyDeviceParameter(m_parameterDom,"sleepthresholdstep",m_sleepthresholdstep);
    m_cp->saveXml();
}
