#ifndef KPIS_H
#define KPIS_H

#include <QObject>
#include <QJsonObject>
#include <QVariantMap>

class WebSocketClient;
class Kpis : public QObject
{
    Q_OBJECT
public:
    explicit Kpis(QObject *parent = 0);
    void initMaps();
signals:
    void sigSendJsonMsg(QJsonObject msg);
public slots:
    void setValue(QString name,int value);
    void triggerKipsReport(QString timeStamp);
public:
    WebSocketClient *m_wsClient;
    QVariantMap  m_kpisMap;
    void resetPeak();
    void insertDefaultItme();
};

#endif // KPIS_H
