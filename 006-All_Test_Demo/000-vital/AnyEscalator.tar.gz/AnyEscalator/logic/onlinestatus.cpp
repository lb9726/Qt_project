#include "onlinestatus.h"
#include "logicheader.h"
#include "../utility/websocket/websocketclient.h"
#include "../define.h"
OnlineStatus::OnlineStatus(QObject *parnet) : QObject(parnet){
    initMaps();
}

void OnlineStatus::initMaps(){
    m_statusMap.insert("GBVibForwardRMS", 0.0f);
    m_statusMap.insert("GBVibLateralRMS", 0.0f);
    m_statusMap.insert("GBVibVerticalRMS", 0.0f);
    m_statusMap.insert("addVibForwardRMS", 0.0f);
    m_statusMap.insert("addVibLateralRMS", 0.0f);
    m_statusMap.insert("addVibVerticalRMS", 0.0f);
    m_statusMap.insert("StepVibForwardRMS", 0.0f);
    m_statusMap.insert("StepVibLateralRMS", 0.0f);
    m_statusMap.insert("StepVibVerticalRMS", 0.0f);
    m_statusMap.insert("StepNoiseRMS", 0.0f);
    m_statusMap.insert("GB1TempAvg", 0.0f);
    m_statusMap.insert("GB2TempAvg", 0.0f);
    m_statusMap.insert("HandrailTempLeftInfraredAvg", 0.0f);
    m_statusMap.insert("HandrailTempRightInfraredAvg", 0.0f);
    m_statusMap.insert("HandrailTempLeftTCAvg", 0.0f);
    m_statusMap.insert("HandrailTempRightTCAvg", 0.0f);
    m_statusMap.insert("HandrailAmbTempLeftAvg", 0.0f);
    m_statusMap.insert("HandrailAmbTempRightAvg", 0.0f);
    m_statusMap.insert("UpperPitNoiseRMS", 0.0f);
    m_statusMap.insert("StepNoiseRMS", 0.0f);
    m_statusMap.insert("MotorCurrent1Avg", 0.0f);
    m_statusMap.insert("MotorCurrent2Avg", 0.0f);
    m_statusMap.insert("MotorCurrent3Avg", 0.0f);
    m_statusMap.insert("MotorPowerActiveAvg", 0.0f);
    m_statusMap.insert("MotorPowerTotalAvg", 0.0f);
    m_statusMap.insert("PowerComsuption", 0.0f);
    m_statusMap.insert("StepBandSpeedLeftAvg", 0.0f);
    m_statusMap.insert("HandrailSpeedLeftAvg", 0.0f);
    m_statusMap.insert("StepBandSpeedRightAvg", 0.0f);
    m_statusMap.insert("HandrailSpeedRightAvg", 0.0f);
    m_statusMap.insert("MotorSpeedLeftAvg", 0.0f);
    m_statusMap.insert("MotorSpeedRightAvg", 0.0f);
    m_statusMap.insert("Passengercount", 0.0f);
    m_statusMap.insert("OperationDirection", 0);
}

void OnlineStatus::triggerStatusReport()
{
    //if(m_wsClient&&m_wsClient->isConnected){
        QJsonObject obj;
        QJsonObject param;
        QJsonObject statistics;

        obj.insert("Message",QJsonValue("OnlineStatus"));
        obj.insert("AnyEscalatorID",QJsonValue(AnyEscalator_ID));
        //obj.insert("Version",QJsonValue(SERVER_VERSION));
        obj.insert("Version",QJsonValue(0));


        param.insert("Timestamp",QJsonValue(getTimeStamp()));
        //param.insert("SW_version",QJsonValue(AESWversion));
        statistics = QJsonObject::fromVariantMap(m_statusMap);
        param.insert("AnyEscalatorEvent",QJsonValue(statistics));

        obj.insert("Param",QJsonValue(param));
        emit sigSendJsonMsg(obj);
        ///m_wsClient->sendJson(obj);
    //}
}

QJsonObject OnlineStatus::getOnlineStatus()
{
    QJsonObject obj;
    QJsonObject param;
    QJsonObject statistics;

    obj.insert("Message",QJsonValue("AnyEscalatorSensorStats"));
    obj.insert("AnyEscalatorID",QJsonValue(AnyEscalator_ID));
    obj.insert("Version",QJsonValue(SERVER_VERSION));

    param.insert("Timestamp",QJsonValue(getTimeStamp()));
    //param.insert("SW_version",QJsonValue(AESWversion));
    statistics = QJsonObject::fromVariantMap(m_statusMap);
    param.insert("AnyEscalatorEvent",QJsonValue(statistics));

    obj.insert("Param",QJsonValue(param));
    return obj;
}
