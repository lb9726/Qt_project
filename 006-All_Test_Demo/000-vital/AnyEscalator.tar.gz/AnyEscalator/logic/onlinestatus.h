#ifndef ONLINESTATUS_H
#define ONLINESTATUS_H

#include <QObject>
#include <QJsonObject>
#include <QVariantMap>
#include <QJsonObject>
class WebSocketClient;
class OnlineStatus : public QObject
{
    Q_OBJECT
public:
    explicit OnlineStatus(QObject *parent = 0);
    void initMaps();

signals:
    void sigSendwebsocketMsg(QByteArray msg);
    void sigSendJsonMsg(QJsonObject msg);
public slots:
    void triggerStatusReport();
    QJsonObject getOnlineStatus();
public:
    WebSocketClient *m_wsClient;
    QVariantMap  m_statusMap;

};

#endif // ONLINESTATUS_H
