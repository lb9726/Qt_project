#include "devicestatus.h"
#include "logicheader.h"
#include "../utility/websocket/websocketclient.h"

DeviceStatus::DeviceStatus(WebSocketClient *wsClient)
{
    m_wsClient = wsClient;
}

DeviceStatus::DeviceStatus()
{

}

void DeviceStatus::reportDeviceStatus(){
   // if(m_wsClient&&m_wsClient->isConnected){
        QJsonObject RootObj;
        QJsonObject anyecsalator;
        RootObj.insert("Message",QJsonValue("DeviceStatus"));
        RootObj.insert("Version",QJsonValue(SERVER_VERSION));
        anyecsalator.insert("AEManufacturer",QJsonValue(AEManufacturer));
        anyecsalator.insert("AESWversion",QJsonValue(appSoftwareVersion));
        anyecsalator.insert("AEHDVersion",QJsonValue(apHardwareVersiob));
        anyecsalator.insert("AnyEscalatorID",QJsonValue(AnyEscalator_ID));
        RootObj.insert("AnyEscalator",QJsonValue(anyecsalator));
        emit sigSendJsonMsg(RootObj);
        //m_wsClient->sendJson(RootObj);
    //}
}

QJsonObject DeviceStatus::getDeviceStatus()
{
    QJsonObject RootObj;
    QJsonObject anyecsalator;
    RootObj.insert("Message",QJsonValue("DeviceStatus"));
    RootObj.insert("Version",QJsonValue(SERVER_VERSION));
    anyecsalator.insert("AEManufacturer",QJsonValue(AEManufacturer));
    anyecsalator.insert("AESWversion",QJsonValue(appSoftwareVersion));
    anyecsalator.insert("AEHDVersion",QJsonValue(apHardwareVersiob));
    anyecsalator.insert("AnyEscalatorID",QJsonValue(AnyEscalator_ID));
    RootObj.insert("AnyEscalator",QJsonValue(anyecsalator));
    return RootObj;
}
