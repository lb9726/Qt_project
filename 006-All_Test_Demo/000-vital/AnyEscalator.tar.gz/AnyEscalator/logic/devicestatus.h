#ifndef DEVICESTATUS_H
#define DEVICESTATUS_H

#include <QObject>
#include <QJsonObject>

class WebSocketClient;

class DeviceStatus : public QObject
{
    Q_OBJECT
public:
    explicit DeviceStatus(WebSocketClient *wsClient);
    DeviceStatus();
signals:
    void sigSendwebsocketMsg(QByteArray msg);
    void sigSendJsonMsg(QJsonObject msg);
public slots:
    QJsonObject getDeviceStatus();
    void reportDeviceStatus();
public:
    WebSocketClient *m_wsClient;
};

#endif // DEVICESTATUS_H
