#ifndef ROUTINECALL_H
#define ROUTINECALL_H

#include <QObject>
#include <QJsonObject>
class QTimer;
class WebSocketClient;
class RoutineCall : public QObject
{
    Q_OBJECT
public:
    explicit RoutineCall(WebSocketClient *wsClient = 0);
    QJsonObject getRoutineCall();
    void trggerRoutineCall();    
    void startWork();
signals:
    void sigSendwebsocketMsg(QByteArray msg);
    void sigSendJsonMsg(QJsonObject msg);
public:
    int m_resets;
    int m_reconnects;
    int m_storage;
    int m_battery;

    WebSocketClient *m_wsClient;    
    QTimer *m_routineTimer;
};

#endif // ROUTINECALL_H
