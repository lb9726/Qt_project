#include "datalogger.h"
#include <QDate>
#include <QCoreApplication>
#include "../define.h"
#include "logicheader.h"
const int spaceCyclePeroid = 2;//days
DataLogger::DataLogger(QObject *parent) : QObject(parent)
{
    m_InfradLogger = NULL;
    m_TCTempLogger = NULL;
    m_PowerLogger = NULL;
    m_KpiLogger = NULL;

    m_InfradCSVHeader = true;
    m_GBVibCSVHeader = true;
    m_addVibCSVHeader = true;
    m_TCTempCSVHeader = true;
    m_PowerCSVHeader = true;
    m_MicCSVHeader = true;
    m_KpiCSVHeader = true;

    m_baseDirPath = QCoreApplication::applicationDirPath();
    QDir dir(m_baseDirPath);
//    dir.mkdir(DATA_STORAGE_DIR_NAME);
//    m_baseDirPath +="/"+DATA_STORAGE_DIR_NAME+"/";
    dir.mkdir("data");
    m_baseDirPath +="/data/";
    m_isDebugModel = false;
//    IDE_TRACE();
}

DataLogger::~DataLogger()
{
    closeFiles();
}

void DataLogger::init(){
    dataLoggerThread = new QThread();
    this->moveToThread(dataLoggerThread);
    dataLoggerThread->start();
}

void DataLogger::closeFiles()
{
    //IDE_TRACE();
    if(m_InfradLogger){
        m_InfradLogger->flush();
        m_InfradLogger->close();
        m_InfradLogger = NULL;
    }

    if(m_TCTempLogger){
        m_TCTempLogger->flush();
        m_TCTempLogger->close();
        m_TCTempLogger = NULL;
    }

    if(m_PowerLogger){
        m_PowerLogger->flush();
        m_PowerLogger->close();
        m_PowerLogger = NULL;
    }

    if(m_KpiLogger){
        m_KpiLogger->flush();
        m_KpiLogger->close();
        m_KpiLogger = NULL;
    }
}

void DataLogger::startWork(){
    shiftHourFile();
    initTimer();
    spaceRecycle();
}

void DataLogger::deviceDebugModel(bool flag)
{
    IDE_TRACE();
    if(m_isDebugModel != flag){
        IDE_TRACE();
        m_isDebugModel = flag;
        if(!m_isDebugModel){//离开Debug模式
            shiftHourFile();
            m_InternalTimer->start();
            m_HourTimer->start();
            IDE_TRACE();
        }else{//进入Debug模式
            closeFiles();
            m_InternalTimer->stop();
            m_HourTimer->stop();
            IDE_TRACE();
        }
    }
    IDE_TRACE();
}

void DataLogger::initTimer()
{
    m_HourTimer = new QTimer(this);
    m_InternalTimer = new QTimer(this);

    m_InternalTimer->setSingleShot(true);
    m_HourTimer->setInterval(DAYS_SECONDS);

    m_SpaceRecycleTimer = new QTimer(this);

    connect(m_HourTimer,&QTimer::timeout,this,&DataLogger::hourTimeOut);
    connect(m_InternalTimer,&QTimer::timeout,this,&DataLogger::internalTimeOut);
    connect(m_SpaceRecycleTimer,&QTimer::timeout,this,&DataLogger::spaceRecycle);
    int curMinute = QTime::currentTime().minute();
    int curSecond = QTime::currentTime().second();

    int interval = (59-curMinute)*60 + (60-curSecond)+1;//确保进入下一个小时
    //IDE_TRACE_INT(interval);
    m_InternalTimer->setInterval(interval*1000);
    m_InternalTimer->start();
    //IDE_TRACE();
    ///m_SpaceRecycleTimer->setInterval(1000*60*60*24*spaceCyclePeroid);//Space recycle timer for 2 days.
    m_SpaceRecycleTimer->setInterval(1000*60*60*spaceCyclePeroid);//Space recycle timer for 2 days.
    m_SpaceRecycleTimer->start();
}

void DataLogger::hourTimeOut(){
    shiftHourFile();
}

void DataLogger::internalTimeOut(){
    IDE_TRACE();
    m_HourTimer->start();
    shiftHourFile();
}

void DataLogger::spaceRecycle(){
    QDir dir(m_baseDirPath);
    QDate limitDate = QDate::currentDate().addDays((-1)*spaceCyclePeroid);// Only save data for 15 days.
    if(dir.exists()){
        QFileInfoList dirList = dir.entryInfoList(QDir::Dirs|QDir::NoDotAndDotDot,QDir::Name);
        for(int i = 0;i<dirList.count();i++){
            QString dirName = dirList.at(i).fileName();
            QDate dirDate = QDate::fromString(dirName,"yyyyMMdd");
            if(dirDate.isValid() && dirDate <= limitDate){
                dir.cd(dirName);
                dir.removeRecursively();
                dir.cdUp();
                IDE_TRACE_STR(dirName);
            }else if(dirDate.isValid() && dirDate > QDate::currentDate()){
                dir.cd(dirName);
                dir.removeRecursively();
                dir.cdUp();
                IDE_TRACE_STR(dirName);
            }else{
                qDebug()<<dirDate<<",li :"<<limitDate;
            }
        }
    }else{
        IDE_TRACE();
    }
}

QString DataLogger::getCurrentTimeDirName()
{
    QDate curDate = QDate::currentDate();
    m_curDataDirName = curDate.toString("yyyyMMdd");
    m_curHourDirName = m_curDataDirName + QTime::currentTime().toString("_hh");
    //IDE_TRACE_STR(m_curDataDirName);
    //IDE_TRACE_STR(m_curHourDirName);
    QDir dir(m_baseDirPath);
    dir.mkdir(m_curDataDirName);

    dir.cd(m_curDataDirName);
    dir.mkdir(m_curHourDirName);
    return QString("%1_%2_00_00_").arg(m_curDataDirName).arg(QTime::currentTime().hour());
}

void DataLogger::shiftHourFile()
{
    ///IDE_TRACE();
    ///QString baseName = getCurrentTimeDirName();
    shiftFile(getCurrentHourFileNameBase());
    initSCVHeader();
    emit sigShiftFile("");
}

void DataLogger::shiftFile(QString baseName)
{
    if(m_InfradLogger){
        m_InfradLogger->close();
        delete m_InfradLogger;
    }

    if(m_TCTempLogger){
        m_TCTempLogger->close();
        delete m_TCTempLogger;
    }

    if(m_PowerLogger){
        m_PowerLogger->close();
        delete m_PowerLogger;
    }

    if(m_KpiLogger){
        m_KpiLogger->close();
        delete m_KpiLogger;
    }

    m_InfradLogger = new QFile(baseName+"infrared.csv");
    m_TCTempLogger = new QFile(baseName+"thermocouple.csv");
    m_PowerLogger = new QFile(baseName+"power.csv");
    m_KpiLogger = new QFile(baseName+"kpi.csv");

    if(m_InfradLogger->exists()){
        m_InfradCSVHeader = false;
    }else{
        m_InfradCSVHeader = true;
    }

    if(!m_InfradLogger->open(QIODevice::WriteOnly | QIODevice::Append)){
        delete m_InfradLogger;
        m_InfradLogger = NULL;
    }

    if(m_TCTempLogger->exists()){
        m_TCTempCSVHeader = false;
    }else{
        m_TCTempCSVHeader = true;
    }
    if(!m_TCTempLogger->open(QIODevice::WriteOnly | QIODevice::Append)){
        delete m_TCTempLogger;
        m_TCTempLogger = NULL;
    }

    if(m_PowerLogger->exists()){
        m_PowerCSVHeader = false;
    }else{
        m_PowerCSVHeader = true;
    }
    if(!m_PowerLogger->open(QIODevice::WriteOnly | QIODevice::Append)){
        delete m_PowerLogger;
        m_PowerLogger = NULL;
    }

    if(m_KpiLogger->exists()){
        m_KpiCSVHeader = false;
    }else{
        m_KpiCSVHeader = true;
    }
    if(!m_KpiLogger->open(QIODevice::WriteOnly | QIODevice::Append)){
        delete m_KpiLogger;
        m_KpiLogger = NULL;
    }
}

void DataLogger::initSCVHeader()
{
    QByteArray ba;
    if(m_InfradLogger&&m_InfradCSVHeader){
        ba.append(TIME_STAMP+",");
        ba.append("HandrailTempLeftInfrared,").append("HandrailTempRightInfrared,");
        ba.append("HandrailAmbTempLeft,").append("HandrailAmbTempRight").append(NEWLINE_RETURN);
        writeFile(m_InfradLogger,ba);
    }
    ba.clear();

    if(m_TCTempLogger&&m_TCTempCSVHeader){
        ba.append(TIME_STAMP+",");
        ///ba.append("HandrailTempLeftTC,").append("HandrailTempRightTC,");
        ba.append("GBTemp1,").append("GBTemp2,").append(NEWLINE_RETURN);
        writeFile(m_TCTempLogger,ba);
    }
    ba.clear();

    if(m_PowerLogger&&m_PowerCSVHeader){
        ba.append(TIME_STAMP+",");
        ba.append("MotorCurrent1,").append("MotorCurrent2,").append("MotorCurrent3,");
        ba.append("MotorPowerActive,").append("MotorPowerTotal").append(NEWLINE_RETURN);
        writeFile(m_PowerLogger,ba);
    }
    ba.clear();

    if(m_KpiLogger&&m_KpiCSVHeader){
        ba.append(TIME_STAMP+",");
        ba.append("GBVibForwardRMS,").append("GBVibLateralRMS,");
        ba.append("GBVibVerticalRMS,").append("GBVibForwardPeak,");
        ba.append("GBVibLateralPeak,").append("GBVibVerticalPeak,");
        ba.append("MotorVibForwardRMS,").append("MotorVibLateralRMS,");
        ba.append("MotorVibVerticalRMS,").append("addVibForwardRMS,");
        ba.append("addVibLateralRMS,").append("addVibVerticalRMS,");
        ba.append("addVibForwardPeak,").append("addVibLateralPeak,");
        ba.append("addVibVerticalPeak,").append("StepVibForwardRMS,");

        ba.append("StepVibLateralRMS,").append("StepVibVerticalRMS,");
        ba.append("StepVibForwardPeak,").append("StepVibLateralPeak,");
        ba.append("StepVibVerticalPeak,").append("StepNoiseRMS,");
        ba.append("StepNoisePeak,").append("GBTempAvg,");
        ba.append("GBTemp1Avg,").append("GBTemp2Avg,");


        ba.append("HandrailTempLeftInfraredAvg,").append("HandrailTempRightInfraredAvg,");
        ba.append("HandrailAmbTempLeftAvg,").append("HandrailAmbTempLeftAvg,");
        ba.append("HandrailTempLeftTCAvg,").append("HandrailTempRightTCAvg,");
        ba.append("UpperPitNoiseRMS,").append("UpperPitNoiseAvg,");
        ba.append("UpperPitNoisePeak,").append("MotorCurrent1Avg,");
        ba.append("MotorCurrent2Avg,").append("MotorCurrent3Avg,");
        ba.append("MotorPowerActiveAvg,").append("MotorPowerTotalAvg,");
        ba.append("MotorPower1Avg,").append("MotorPower2Avg,");
        ba.append("MotorCurrent1Peak,").append("MotorCurrent2Peak,");
        ba.append("MotorCurrent3Peak,").append("MotorPowerActivePeak,");

        ba.append("MotorPowerTotalPeak,").append("MotorPower1Peak,");
        ba.append("MotorPower2Peak,").append("PowerComsuption,");
        ba.append("StepBandSpeedLeftAvg,").append("HandrailSpeedLeftAvg,");
        ba.append("StepBandSpeedRightAvg,").append("HandrailSpeedRightAvg,");
        ba.append("MotorSpeedLeftAvg,").append("MotorSpeedRightAvg,");
        ba.append("OilLevel,").append("AccelerationTime,");
        ba.append("DecelerationTime,").append("Passengercount,");
        ba.append("OperationDirection,").append("BrakingDistance,");
        ba.append("OperationStatus,").append("modeset,");
        ba.append("alarmID,").append("Duration\n");

        writeFile(m_KpiLogger,ba);
    }
}

void DataLogger::writeFile(QFile *pFile,QByteArray &ba){
    if(m_isDebugModel){
        return;
    }

    if(pFile->isOpen()){
        pFile->write(ba);
        pFile->flush();
    }else{
        if(pFile->open(QIODevice::WriteOnly | QIODevice::Append)){
            pFile->write(ba);
            pFile->flush();
        }else{
            IDE_TRACE();
        }
    }
}


///数据写入槽
void DataLogger::infradAppend(qreal leftTemp,qreal rightTemp,qreal leftAmb,qreal rightAmb){
    QString content = QString("%1,%2,%3,%4,%5%6").arg(getTimeStamp()).arg(leftTemp)\
            .arg(rightTemp).arg(leftAmb).arg(rightAmb).arg(NEWLINE_RETURN);

    QByteArray ba;
    ba.append(content);
    writeFile(m_InfradLogger,ba);
}

void DataLogger::gbVibAppend(qreal forward,qreal lateral,qreal vertical){
    //    QString v1 = QString::number(forward/1000,'f',3);
    //    QString v2 = QString::number(lateral/1000,'f',3);
    //    QString v3 = QString::number(vertical/1000,'f',3);

    //    //    QString v1 = QString::number(forward,'f',3);
    //    //    QString v2 = QString::number(lateral,'f',3);
    //    //    QString v3 = QString::number(vertical,'f',3);
    //    QString content = QString("%1,%2,%3,%4%5").arg(getTimeStamp()).arg(v1)\
    //            .arg(v2).arg(v3).arg(NEWLINE_RETURN);
    //    QByteArray ba;
    //    ba.append(content);
    //    //IDE_TRACE_STR(content);
    //    writeFile(m_GBVibLogger,ba);
}

void DataLogger::addVibAppend(qreal forward,qreal lateral,qreal vertical)
{
    //    QString v1 = QString::number(forward/1000,'f',3);
    //    QString v2 = QString::number(lateral/1000,'f',3);
    //    QString v3 = QString::number(vertical/1000,'f',3);
    //    QString content = QString("%1,%2,%3,%4%5").arg(getTimeStamp()).arg(v1)\
    //            .arg(v2).arg(v3).arg(NEWLINE_RETURN);
    //    QByteArray ba;
    //    ba.append(content);
    //    //IDE_TRACE_STR(content);
    //    writeFile(m_addVibLogger,ba);
}

void DataLogger::tcAppend(qreal gbTemp1,qreal gbTemp2,qreal gbTemp3,qreal gbTemp4){
    Q_UNUSED(gbTemp3);
    Q_UNUSED(gbTemp4);
    QString content = QString("%1,%2,%3,%4").arg(getTimeStamp())\
            .arg(gbTemp1).arg(gbTemp2).arg(NEWLINE_RETURN);
    //IDE_TRACE_STR(content);
    QByteArray ba;
    ba.append(content);
    writeFile(m_TCTempLogger,ba);
}

void DataLogger::powerAppend(qreal c1,qreal c2,qreal c3,qreal active,qreal total,qreal comsuption){
    Q_UNUSED(comsuption);
    //IDE_TRACE();
    QString content = QString("%1,%2,%3,%4,%5,%6%7").arg(getTimeStamp()).arg(c1)\
            .arg(c2).arg(c3).arg(active).arg(total).arg(NEWLINE_RETURN);
    QByteArray ba;
    ba.append(content);
    //IDE_TRACE_STR(content);
    writeFile(m_PowerLogger,ba);
}

void DataLogger::micAppend(qreal noise){
    //    QString content = QString("%1,%2%3").arg(getTimeStamp()).arg(noise).arg(NEWLINE_RETURN);
    //    QByteArray ba;
    //    ba.append(content);
    //    IDE_TRACE_STR(content);
    //    writeFile(m_MicLogger,ba);
}

void DataLogger::kpiAppend(QString kpi){
    QString content = QString("%1,%2%3").arg(getTimeStamp()).arg(kpi).arg(NEWLINE_RETURN);
    QByteArray ba;
    ba.append(content);
    writeFile(m_KpiLogger,ba);
}

void DataLogger::kpiLogger(QVariantMap kpi){
    QByteArray ba;
    ba.append(getTimeStamp()).append(",");
//    ba.append(QString("%1").arg(kpi["GBVibForwardRMS"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["GBVibLateralRMS"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["GBVibVerticalRMS"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["GBVibForwardPeak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["GBVibLateralPeak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["GBVibVerticalPeak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorVibForwardRMS"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorVibLateralRMS"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorVibVerticalRMS"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["addVibForwardRMS"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["addVibLateralRMS"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["addVibVerticalRMS"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["addVibForwardPeak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["addVibLateralPeak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["addVibVerticalPeak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["StepVibForwardRMS"].toDouble())).append(",");

//    ba.append(QString("%1").arg(kpi["StepVibLateralRMS"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["StepVibVerticalRMS"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["StepVibForwardPeak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["StepVibLateralPeak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["StepVibVerticalPeak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["StepNoiseRMS"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["StepNoisePeak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["GBTempAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["GBTemp1Avg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["GBTemp2Avg"].toDouble())).append(",");

//    ba.append(QString("%1").arg(kpi["HandrailTempLeftInfraredAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["HandrailTempRightInfraredAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["HandrailAmbTempLeftAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["HandrailAmbTempLeftAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["HandrailTempLeftTCAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["HandrailTempRightTCAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["UpperPitNoiseRMS"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["UpperPitNoiseAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["UpperPitNoisePeak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorCurrent1Avg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorCurrent2Avg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorCurrent3Avg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorPowerActiveAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorPowerTotalAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorPower1Avg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorPower2Avg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorCurrent1Peak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorCurrent2Peak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorCurrent3Peak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorPowerActivePeak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorPowerTotalPeak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorPower1Peak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorPower2Peak"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["PowerComsuption"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["StepBandSpeedLeftAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["HandrailSpeedLeftAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["StepBandSpeedRightAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["HandrailSpeedRightAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorSpeedLeftAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["MotorSpeedRightAvg"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["OilLevel"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["AccelerationTime"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["DecelerationTime"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["Passengercount"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["OperationDirection"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["BrakingDistance"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["OperationStatus"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["Modeset"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["alarmID"].toDouble())).append(",");
//    ba.append(QString("%1").arg(kpi["Duration"].toDouble())).append("\n");

    ba.append(kpi["GBVibForwardRMS"].toString()).append(",");
    ba.append(kpi["GBVibLateralRMS"].toString()).append(",");
    ba.append(kpi["GBVibVerticalRMS"].toString()).append(",");
    ba.append(kpi["GBVibForwardPeak"].toString()).append(",");
    ba.append(kpi["GBVibLateralPeak"].toString()).append(",");
    ba.append(kpi["GBVibVerticalPeak"].toString()).append(",");
    ba.append(kpi["MotorVibForwardRMS"].toString()).append(",");
    ba.append(kpi["MotorVibLateralRMS"].toString()).append(",");
    ba.append(kpi["MotorVibVerticalRMS"].toString()).append(",");
    ba.append(kpi["addVibForwardRMS"].toString()).append(",");
    ba.append(kpi["addVibLateralRMS"].toString()).append(",");
    ba.append(kpi["addVibVerticalRMS"].toString()).append(",");
    ba.append(kpi["addVibForwardPeak"].toString()).append(",");
    ba.append(kpi["addVibLateralPeak"].toString()).append(",");
    ba.append(kpi["addVibVerticalPeak"].toString()).append(",");
    ba.append(kpi["StepVibForwardRMS"].toString()).append(",");

    ba.append(kpi["StepVibLateralRMS"].toString()).append(",");
    ba.append(kpi["StepVibVerticalRMS"].toString()).append(",");
    ba.append(kpi["StepVibForwardPeak"].toString()).append(",");
    ba.append(kpi["StepVibLateralPeak"].toString()).append(",");
    ba.append(kpi["StepVibVerticalPeak"].toString()).append(",");
    ba.append(kpi["StepNoiseRMS"].toString()).append(",");
    ba.append(kpi["StepNoisePeak"].toString()).append(",");
    ba.append(kpi["GBTempAvg"].toString()).append(",");
    ba.append(kpi["GBTemp1Avg"].toString()).append(",");
    ba.append(kpi["GBTemp2Avg"].toString()).append(",");

    ba.append(kpi["HandrailTempLeftInfraredAvg"].toString()).append(",");
    ba.append(kpi["HandrailTempRightInfraredAvg"].toString()).append(",");
    ba.append(kpi["HandrailAmbTempLeftAvg"].toString()).append(",");
    ba.append(kpi["HandrailAmbTempLeftAvg"].toString()).append(",");
    ba.append(kpi["HandrailTempLeftTCAvg"].toString()).append(",");
    ba.append(kpi["HandrailTempRightTCAvg"].toString()).append(",");
    ba.append(kpi["UpperPitNoiseRMS"].toString()).append(",");
    ba.append(kpi["UpperPitNoiseAvg"].toString()).append(",");
    ba.append(kpi["UpperPitNoisePeak"].toString()).append(",");
    ba.append(kpi["MotorCurrent1Avg"].toString()).append(",");
    ba.append(kpi["MotorCurrent2Avg"].toString()).append(",");
    ba.append(kpi["MotorCurrent3Avg"].toString()).append(",");
    ba.append(kpi["MotorPowerActiveAvg"].toString()).append(",");
    ba.append(kpi["MotorPowerTotalAvg"].toString()).append(",");
    ba.append(kpi["MotorPower1Avg"].toString()).append(",");
    ba.append(kpi["MotorPower2Avg"].toString()).append(",");
    ba.append(kpi["MotorCurrent1Peak"].toString()).append(",");
    ba.append(kpi["MotorCurrent2Peak"].toString()).append(",");
    ba.append(kpi["MotorCurrent3Peak"].toString()).append(",");
    ba.append(kpi["MotorPowerActivePeak"].toString()).append(",");
    ba.append(kpi["MotorPowerTotalPeak"].toString()).append(",");
    ba.append(kpi["MotorPower1Peak"].toString()).append(",");
    ba.append(kpi["MotorPower2Peak"].toString()).append(",");
    ba.append(kpi["PowerComsuption"].toString()).append(",");
    ba.append(kpi["StepBandSpeedLeftAvg"].toString()).append(",");
    ba.append(kpi["HandrailSpeedLeftAvg"].toString()).append(",");
    ba.append(kpi["StepBandSpeedRightAvg"].toString()).append(",");
    ba.append(kpi["HandrailSpeedRightAvg"].toString()).append(",");
    ba.append(kpi["MotorSpeedLeftAvg"].toString()).append(",");
    ba.append(kpi["MotorSpeedRightAvg"].toString()).append(",");
    ba.append(kpi["OilLevel"].toString()).append(",");
    ba.append(kpi["AccelerationTime"].toString()).append(",");
    ba.append(kpi["DecelerationTime"].toString()).append(",");
    ba.append(kpi["Passengercount"].toString()).append(",");
    ba.append(kpi["OperationDirection"].toString()).append(",");
    ba.append(kpi["BrakingDistance"].toString()).append(",");
    ba.append(kpi["OperationStatus"].toString()).append(",");
    ba.append(kpi["modeset"].toString()).append(",");
    ba.append(kpi["alarmID"].toString()).append(",");
    ba.append(kpi["Duration"].toString()).append("\n");
    writeFile(m_KpiLogger,ba);
}

