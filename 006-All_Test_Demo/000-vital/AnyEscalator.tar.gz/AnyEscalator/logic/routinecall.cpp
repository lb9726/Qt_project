#include "routinecall.h"
#include "logicheader.h"
#include "../utility/websocket/websocketclient.h"
#include <QTimer>
#include <QJsonObject>
#include "../define.h"

RoutineCall::RoutineCall(WebSocketClient *wsClient)
{
    m_wsClient = wsClient;
    m_resets = 0;
    m_reconnects = 0;
    m_storage = 5;
    m_battery = 100;
    m_routineTimer = new QTimer();
    m_routineTimer->setInterval(86400000);//24小时转为毫秒
}

QJsonObject RoutineCall::getRoutineCall()
{
    QJsonObject RootObj;
    QJsonObject param;
    QJsonObject rcEvent;

    RootObj.insert("Message",QJsonValue("RoutineCall"));
    RootObj.insert("AnyEscalatorID",QJsonValue(AnyEscalator_ID));
    RootObj.insert("Version",QJsonValue(SERVER_VERSION));

    param.insert("Timestamp",QJsonValue(getTimeStamp()));

    rcEvent.insert("resets",QJsonValue(AnyEscalator_ID));
    rcEvent.insert("reconnects",QJsonValue(AnyEscalator_ID));
    rcEvent.insert("storage",QJsonValue(AnyEscalator_ID));
    rcEvent.insert("battery",QJsonValue(AnyEscalator_ID));
    param.insert("AnyEscalatorRCevent",QJsonValue(rcEvent));

    RootObj.insert("Param",QJsonValue(param));
    //m_wsClient->sendJson(RootObj);
    return RootObj;
}

void RoutineCall::trggerRoutineCall()
{
    //if(m_wsClient&&m_wsClient->isConnected){
        QJsonObject RootObj;
        QJsonObject param;
        QJsonObject rcEvent;

        RootObj.insert("Message",QJsonValue("RoutineCall"));
        RootObj.insert("AnyEscalatorID",QJsonValue(AnyEscalator_ID));
        RootObj.insert("Version",QJsonValue(SERVER_VERSION));

        param.insert("Timestamp",QJsonValue(getTimeStamp()));

        rcEvent.insert("resets",QJsonValue(m_resets));
        rcEvent.insert("reconnects",QJsonValue(m_reconnects));
        rcEvent.insert("storage",QJsonValue(m_storage));
        rcEvent.insert("battery",QJsonValue(m_battery));
        param.insert("AnyEscalatorRCevent",QJsonValue(rcEvent));

        RootObj.insert("Param",QJsonValue(param));
        emit sigSendJsonMsg(RootObj);
        //m_wsClient->sendJson(RootObj);
    //}
}

void RoutineCall::startWork(){
    m_routineTimer->start();
}
