#include "kpis.h"
#include "logicheader.h"
#include "../utility/websocket/websocketclient.h"
#include <float.h>
#include <QtMath>

Kpis::Kpis(QObject *parent) : QObject(parent)
{
    initMaps();
}

void Kpis::initMaps(){
    m_kpisMap.insert("StepBandSpeedLeftAvg", 0.0f);
    m_kpisMap.insert("HandrailSpeedLeftAvg", 0.0f);
    m_kpisMap.insert("StepBandSpeedRightAvg", 0.0f);
    m_kpisMap.insert("HandrailSpeedRightAvg", 0.0f);
    m_kpisMap.insert("MotorSpeedLeftAvg", 0.0f);
    m_kpisMap.insert("MotorSpeedRightAvg", 0.0f);
    m_kpisMap.insert("OilLevel", 0.0f);
    m_kpisMap.insert("AccelerationTime", 0.0f);
    m_kpisMap.insert("DecelerationTime", 0.0f);
    m_kpisMap.insert("BrakingDistance", 0.0f);
    m_kpisMap.insert("OperationStatus", 0.0f);
    m_kpisMap.insert("modeset", 1.0f);
    m_kpisMap.insert("alarmID", 0.0f);
}

void Kpis::setValue(QString name, int value)
{
    if(m_kpisMap.contains(name)){
        m_kpisMap[name] = QVariant(value);
    }
}

void Kpis::triggerKipsReport(QString timeStamp)
{
    QJsonObject obj;
    QJsonObject param;
    QJsonObject statistics;
    insertDefaultItme();
    obj.insert("Message",QJsonValue("AnyEscalatorSensorStats"));
    obj.insert("AnyEscalatorID",QJsonValue(AnyEscalator_ID));
    //obj.insert("Version",QJsonValue("0"));
    obj.insert("Version",QJsonValue(SERVER_VERSION));

    param.insert("Timestamp",QJsonValue(timeStamp));
    param.insert("SW_version",QJsonValue(appSoftwareVersion));
    statistics = QJsonObject::fromVariantMap(m_kpisMap);
    param.insert("SensorDataStatistics",QJsonValue(statistics));

    obj.insert("Param",QJsonValue(param));
    emit sigSendJsonMsg(obj);

}

void Kpis::insertDefaultItme(){
    m_kpisMap.insert("StepBandSpeedLeftAvg", 0.0f);
    m_kpisMap.insert("HandrailSpeedLeftAvg", 0.0f);
    m_kpisMap.insert("StepBandSpeedRightAvg", 0.0f);
    m_kpisMap.insert("HandrailSpeedRightAvg", 0.0f);
    m_kpisMap.insert("MotorSpeedLeftAvg", 0.0f);
    m_kpisMap.insert("MotorSpeedRightAvg", 0.0f);
    m_kpisMap.insert("OilLevel", 0.0f);
    m_kpisMap.insert("AccelerationTime", 0.0f);
    m_kpisMap.insert("DecelerationTime", 0.0f);
    m_kpisMap.insert("BrakingDistance", 0.0f);
    m_kpisMap.insert("OperationStatus", 0.0f);
    m_kpisMap.insert("modeset", 1.0f);
    m_kpisMap.insert("alarmID", 0.0f);
}

void Kpis::resetPeak(){
//    m_kpisMap["GBVibForwardPeak"] = 0;//QREAL_MIN;
//    m_kpisMap["GBVibLateralPeak"] = 0;//QREAL_MIN;
//    m_kpisMap["GBVibVerticalPeak"] = 0;//QREAL_MIN;
//    m_kpisMap["addVibForwardPeak"] = 0;//QREAL_MIN;
//    m_kpisMap["addVibLateralPeak"] = 0;//QREAL_MIN;
//    m_kpisMap["addVibVerticalPeak"] = 0;//QREAL_MIN;
//    m_kpisMap["StepVibForwardPeak"] = 0;//QREAL_MIN;
//    m_kpisMap["StepVibLateralPeak"] = 0;//QREAL_MIN;
//    m_kpisMap["StepVibVerticalPeak"] = 0;//QREAL_MIN;
//    m_kpisMap["StepNoisePeak"] = QREAL_MIN;
//    m_kpisMap["UpperPitNoisePeak"] = QREAL_MIN;
//    m_kpisMap["MotorCurrent1Peak"] = QREAL_MIN;
//    m_kpisMap["MotorCurrent2Peak"] = QREAL_MIN;
//    m_kpisMap["MotorCurrent3Peak"] = QREAL_MIN;
//    m_kpisMap["MotorPowerActivePeak"] = QREAL_MIN;
//    m_kpisMap["MotorPowerTotalPeak"] = QREAL_MIN;
//    m_kpisMap["MotorPower1Peak"] = QREAL_MIN;
//    m_kpisMap["MotorPower2Peak"] = QREAL_MIN;
}
