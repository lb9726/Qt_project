#ifndef DEVICEPARAMETERS_H
#define DEVICEPARAMETERS_H

#include <QObject>
#include <QJsonObject>
#include <QDomDocument>
#include <QSettings>

class ConfigureParser;
class WebSocketClient;
class DeviceParameters : public QObject
{
    Q_OBJECT
public:
    explicit DeviceParameters(ConfigureParser *cp = 0);
    ///DeviceParameters(QSettings* setting);
    void initParameters();
    void saveParameters();
    void setWSClient(WebSocketClient *wsClient);
    QString getAxisInfo(int axis);
signals:
    void sigGBVibFreqChanged(int freq);
    void sigaddVibFreqChanged(int freq);
    void sigGBTempFreqChanged(int freq);
    void sigHandrailInfraredFreqChanged(int freq);
    void sigKPIintervalChanged(int freq);
    void sigMicFreqChanged(int freq);

    void sigSendwebsocketMsg(QByteArray msg);
    void sigSendJsonMsg(QJsonObject msg);
public slots:
    void reportDeviceParameters();
    QJsonObject getDeviceParameters();
    void setDeviceParameters(QJsonObject& obj);

    int getDeviceParameter(QString name);
public:
    ConfigureParser *m_cp;
    int m_KPIinterval;
    int m_sleepthresholdmain;
    int m_sleepthresholdsecondary;
    int m_sleepthresholdstep;

    int m_GBVIBFORWARDDIR;
    int m_GBVIBLATERALDDIR;
    int m_GBVIBVERTICALDIR;

    int m_ADDVIBFORWARDDIR;
    int m_ADDVIBLATERALDDIR;
    int m_ADDVIBVERTICALDIR;

    int m_GBVIBXOFFSET;
    int m_GBVIBYOFFSET;
    int m_GBVIBZOFFSET;
    int m_ADDVIBXOFFSET;
    int m_ADDVIBYOFFSET;
    int m_ADDVIBZOFFSET;
    QDomElement m_parameterDom;
    //QSettings* m_settings;
    WebSocketClient* m_wsClient;
    void setParameter(QString name, int value);
};

#endif // DEVICEPARAMETERS_H
