#ifndef LOGICHEADER_H
#define LOGICHEADER_H
#include <QString>
#include <QDate>
#include <QTime>
#include "../define.h"
const int SERVER_VERSION  = 0;
///const int AnyEscalator_ID  = 0x000002;
const QString AnyEscalator_ID  = "BST1804220001";

const QString AEManufacturer = "BST";
const QString appSoftwareVersion = "4.2.6";
const QString apHardwareVersiob = "5.0";
static const int DAYS_SECONDS = 3600000;//1小时换算成毫秒
//const qreal QREAL_MIN = -100000000000;
//const qreal QREAL_MAX =  100000000000;
#endif // LOGICHEADER_H
