#ifndef DATALOGGER_H
#define DATALOGGER_H

#include <QObject>
#include <QFile>
#include <QTimer>
#include <QDir>
#include <QFileInfo>
#include <QThread>
#include <QJsonObject>
#include "physic/acceleratenode.h"
#include "physic/micnode.h"

class DataLogger : public QObject
{
    Q_OBJECT
public:
    explicit DataLogger(QObject *parent = 0);
    ~ DataLogger();    

    void closeFiles();
    void initTimer();

    void hourTimeOut();
    void internalTimeOut();
    void shiftHourFile();

    QString getCurrentTimeDirName();
    void shiftFile(QString baseName);
    void initSCVHeader();
    void writeFile(QFile *pFile, QByteArray &ba);

    void setAccNode(AccelerateNode* gb,AccelerateNode* add);
    void setMicNode(MicNode* mic);
signals:
    void sigSendwebsocketMsg(QByteArray msg);
    void sigSendJsonMsg(QJsonObject msg);
    void sigShiftFile(QString filePath);
public slots:    
    void startWork();
    void deviceDebugModel(bool flag);
    void infradAppend(qreal leftTemp, qreal rightTemp, qreal leftAmb, qreal rightAmb);
    void gbVibAppend(qreal forward, qreal lateral, qreal vertical);
    void tcAppend(qreal gbTemp1, qreal gbTemp2, qreal gbTemp3, qreal gbTemp4);
    void addVibAppend(qreal forward, qreal lateral, qreal vertical);
    void powerAppend(qreal c1, qreal c2, qreal c3, qreal active, qreal total, qreal comsuption);
    void micAppend(qreal noise);
    void kpiAppend(QString kpi);
    void kpiLogger(QVariantMap kpi);
public:
    bool m_isDebugModel;
    QFile *m_InfradLogger;
    QFile *m_GBVibLogger;
    QFile *m_addVibLogger;
    QFile *m_TCTempLogger;
    QFile *m_PowerLogger;
    QFile *m_MicLogger;
    QFile *m_KpiLogger;

    bool m_InfradCSVHeader;
    bool m_GBVibCSVHeader;
    bool m_addVibCSVHeader;
    bool m_TCTempCSVHeader;
    bool m_PowerCSVHeader;
    bool m_MicCSVHeader;
    bool m_KpiCSVHeader;

    QString m_baseDirPath;
    QString m_curDataDirName;
    QString m_curHourDirName;
    ///static QString Current_Logger_Dir;
    QTimer *m_InternalTimer;
    QTimer *m_HourTimer;
    QThread *dataLoggerThread;
    void init();

    QTimer *m_SpaceRecycleTimer;
    void spaceRecycle();
};

#endif // DATALOGGER_H
