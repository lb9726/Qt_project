#include "engine.h"
#include "logic/logicheader.h"
#include <QDateTime>
#include <time.h>


#ifdef WINDOWS
#include "Windows.h"  ///修改系统时间用
#endif

///sys/class/leds/poweron-led/brightness
///sys/class/leds/online-led/brightness
///sys/class/leds/devicemode-led/brightness
///sys/class/leds/deviceerror-led/brightness




static const int Operate_Result_OK = 200;
static const int Operate_Result_Fail = 500;

static const QString SENSOR_SPLIT = "@";
static const QString NAME_SPLIT = "#";
static const QString DATA_SPLIT = ",";

static const QString MESSAGE_TEXT = "Message";
static const QString TIME_STAMPS = "Timestamp";
static const QString EQUIPMENT_NUMBER = "EquipmentNumber";

Engine::Engine(QObject *parent) : QObject(parent)
{
    m_softwareUpdater = "/home/AnyEscalatorUpgrad";
    isUploadingRawData = false;
    m_RawFileMap.clear();

    m_cp = NULL;
    m_interProtocol = NULL;
    m_deviceParameters = NULL;
    m_deviceStatus = NULL;
    m_routineCall = NULL;
    m_webSocketClient = NULL; ///independence Thread
    m_dataLogger = NULL; ///independence Thread
    m_sensorHub = NULL; ///independence Thread
    m_kpiTimer = NULL;
    m_onolineStatusTimer = NULL;
    m_leftVibNode = NULL;
    m_rightVibNode = NULL;

    m_micNode = NULL;
    m_ftpClient = NULL;
    m_webSocketPcHelper = NULL;
    m_helperRealtimeDataTimer = NULL;
    mAllNodeStatus = false;
    m_peopleDetectTimer = NULL;
    m_GlobleNodeConnectStatus = false;
}

Engine::~Engine()
{
    ///正式分支
    //    m_dataLogger->disconnect();
    //    m_interProtocol->disconnect();
    //    delete m_interProtocol;
    //    delete m_dataLogger;
    //    delete m_cp;
    ////正式分支
}

void Engine::initEngine(){
    qDebug()<<"Software Version *****  "<<appSoftwareVersion<<" *****";

    m_settings = new QSettings("BST", "AnyEscalator");
    m_TotalPeopleCount = m_settings->value("peopleCount",0).toInt();
    IDE_TRACE_INT(m_TotalPeopleCount);

    ///正式分支

    initInterProtocol();
    initLogger();
    initWebsocket();
    initLogic();
    IDE_TRACE();
    initSensorHub();
    initFtpClient();
    initOnboradNode();
    initPcHelper();
    initPeopleCountLogic();
    IDE_TRACE();
    ///正式分支
    LedController::onlineLight(false);
    LedController::deviceModeLight(false);
    LedController::deviceErrorLight(false);
}

void Engine::startDevice(){
    ///正式分支
    IDE_TRACE_STR("startInterProtocol...");
    startInterProtocol();
    IDE_TRACE_STR("startLogger...");
    startLogger();
    IDE_TRACE_STR("startLogic...");
    startLogic();
    //IDE_TRACE_STR("startWebsocket...");
    startWebsocket();
    //IDE_TRACE_STR("startSensorHub...");
    startSensorHub();
    //IDE_TRACE_STR("startFtpClient...");
    startFtpClient();
    //IDE_TRACE_STR("startOnboradNode...");
    startOnboradNode();
    //IDE_TRACE_STR("startPcHelper...");
    startPcHelper();
    //IDE_TRACE_STR("*****Start Device Succeed*****");
    startPeopleCountLogic();
    ///正式分支
}
///Init Function   **********************  Start
void Engine::initInterProtocol(){
    m_interProtocol = new InterProtocol();
    connect(m_interProtocol,&InterProtocol::sigThermData,this,&Engine::thermoCoupleData);
    connect(m_interProtocol,&InterProtocol::sigInfraData,this,&Engine::infradData);
    connect(m_interProtocol,&InterProtocol::sigPowerData,this,&Engine::powerData);
    connect(m_interProtocol,&InterProtocol::sigSpeedData,this,&Engine::speedData);
    connect(m_interProtocol,&InterProtocol::sigPeopleCountData,this,&Engine::peopleCountData);
    connect(m_interProtocol,&InterProtocol::sigDirectionData,this,&Engine::directionData);
    connect(m_interProtocol,SIGNAL(sigNodeConnectStatus(quint8,bool)),this,SLOT(nodeConnectStatus(quint8,bool)));

    connect(this,SIGNAL(sigStartInterProtocol()),m_interProtocol,SLOT(startWork()));
    m_interProtocol->init();
}
void Engine::initLogger(){
    m_dataLogger = new DataLogger();
    if(!m_dataLogger){
        IDE_TRACE();
    }
    connect(this,&Engine::sTcData,m_dataLogger,&DataLogger::tcAppend);
    connect(this,&Engine::sInfradData,m_dataLogger,&DataLogger::infradAppend);
    connect(this,&Engine::sPowerData,m_dataLogger,&DataLogger::powerAppend);
    connect(this,SIGNAL(sigStartLogger()),m_dataLogger,SLOT(startWork()));
    m_baseDirPath = m_dataLogger->m_baseDirPath;
    m_dataLogger->init();
}

void Engine::initWebsocket(){
    m_webSocketClient = new WebSocketClient();
    connect(m_webSocketClient,&WebSocketClient::sigWebSocketConnected,this,&Engine::dtuWebSocketConnected);
    connect(m_webSocketClient,&WebSocketClient::sigWebSocketDisconnected,this,&Engine::dtuWebSocketDisconnected);
    connect(m_webSocketClient,&WebSocketClient::dtuMsg,this,&Engine::dtuMessage);
    connect(this,&Engine::sigStartWebSocketClient,m_webSocketClient,&WebSocketClient::startWork);
    connect(this,&Engine::sigSendJsonMsg,m_webSocketClient,&WebSocketClient::sendJson);
    m_webSocketClient->init("ws://192.168.1.1:1080/anyescalator/?version=1.1.0");
}

void Engine::initLogic(){
    m_cp  = new ConfigureParser("configurate.xml");
    bool flag = m_cp->openConfigure();
    if(!flag){
        ///点亮错误指示灯
        IDE_TRACE();
        return;
    }
    ///IDE_TRACE();
    m_deviceStatus = new DeviceStatus();
    m_routineCall = new RoutineCall();
    //IDE_TRACE();
    m_deviceParameters = new DeviceParameters(m_cp);
    //IDE_TRACE();
    connect(m_deviceStatus,&DeviceStatus::sigSendJsonMsg,m_webSocketClient,&WebSocketClient::sendJson);
    connect(m_routineCall,&RoutineCall::sigSendJsonMsg,m_webSocketClient,&WebSocketClient::sendJson);
    connect(m_deviceParameters,&DeviceParameters::sigSendJsonMsg,m_webSocketClient,&WebSocketClient::sendJson);

    connect(m_deviceParameters,&DeviceParameters::sigGBVibFreqChanged,this,&Engine::sltgbVibFreq);
    connect(m_deviceParameters,&DeviceParameters::sigaddVibFreqChanged,this,&Engine::sltaddVibFreq);
    connect(m_deviceParameters,&DeviceParameters::sigGBTempFreqChanged,this,&Engine::sltTcFreq);
    connect(m_deviceParameters,&DeviceParameters::sigHandrailInfraredFreqChanged,this,&Engine::sltInfraredFreq);
    connect(m_deviceParameters,&DeviceParameters::sigKPIintervalChanged,this,&Engine::sltKPIFreq);
    connect(m_deviceParameters,&DeviceParameters::sigMicFreqChanged,this,&Engine::sltMicFreq);
}

void Engine::initSensorHub(){
    m_sensorHub = new SensorHub();
    connect(m_sensorHub,&SensorHub::sigSendJsonMsg,this,&Engine::sltSendJsonMsg);

    connect(this,&Engine::sTcData,m_sensorHub,&SensorHub::sltTcData);
    connect(this,&Engine::sInfradData,m_sensorHub,&SensorHub::sltInfradData);
    connect(this,&Engine::sPowerData,m_sensorHub,&SensorHub::sltPower);

    connect(this,&Engine::sDirectionData,m_sensorHub,&SensorHub::sltDirectionData);
    connect(this,&Engine::sPeopleCountData,m_sensorHub,&SensorHub::sltPeopleCountData);
    connect(this,&Engine::sSpeedData,m_sensorHub,&SensorHub::sltSpeedData);
    connect(m_sensorHub,&SensorHub::sigKpiLogger,m_dataLogger,&DataLogger::kpiLogger);
    connect(m_interProtocol,&InterProtocol::sigNodeConnectStatus,m_sensorHub,&SensorHub::nodeConnectStatus);

    m_kpiTimer = new QTimer(this);
    connect(m_kpiTimer,&QTimer::timeout,m_sensorHub,&SensorHub::kpisReport);

    m_onolineStatusTimer = new QTimer(this);
    m_onolineStatusTimer->setInterval(1000);// online status defult interval is 1 seconds.
    connect(m_onolineStatusTimer,&QTimer::timeout,this,&Engine::OnlineStatusTrigger);
    connect(this,&Engine::sigOnlineStatusTrigger,m_sensorHub,&SensorHub::OnlineStatusReport);
    m_sensorHub->m_Duration = m_deviceParameters->getDeviceParameter("KPIinterval");
    m_sensorHub->setNodesMap(m_cp->m_sensorNodes);
    connect(this,SIGNAL(sigStartSensorHub()),m_sensorHub,SLOT(startWork()));
    m_sensorHub->init();
}

void Engine::initFtpClient(){
    m_ftpClient = new FtpClient();
    ///connect(m_ftpClient,&FtpClient::sigConnected,this,&Engine::ftpConnected);
    connect(m_ftpClient,&FtpClient::sigGetFileFinished,this,&Engine::getFTPFileFinished);
    connect(m_ftpClient,&FtpClient::sigPutFileFinished,this,&Engine::putFTPFileFinished);
    connect(m_ftpClient,&FtpClient::sigUploadRawFileCompelete,this,&Engine::uploadRawFileCompelete);
    //    connect(this,&Engine::sigGetFile,m_ftpClient,&FtpClient::getFile);
    connect(this,SIGNAL(sigGetFile(QString,QString)),m_ftpClient,SLOT(getFile(QString,QString)));
    connect(this,&Engine::sigStartUploadFile,m_ftpClient,&FtpClient::startUploadFile);
    connect(this,&Engine::sigAppendUploadFile,m_ftpClient,&FtpClient::appendUploadFile);

    connect(this,SIGNAL(sigStartFtpClient()),m_ftpClient,SLOT(startWork()));
    m_ftpClient->init(QUrl("ftp://192.168.1.1:21"),"ftp","");
}

void Engine::initOnboradNode(){
    m_leftVibNode = new AccelerateNode();
    m_leftVibNode->init(1);///Node's Order
    ///m_leftVibNode->setFreq(m_deviceParameters->m_GBVibFreq);
    m_leftVibNode->setDirectionMap(m_deviceParameters->getDeviceParameter("GBVIBFORWARDDIR"),\
                                   m_deviceParameters->getDeviceParameter("GBVIBLATERALDDIR"),\
                                   m_deviceParameters->getDeviceParameter("GBVIBVERTICALDIR"));

    //IDE_TRACE_INT()

    m_rightVibNode = new AccelerateNode();
    m_rightVibNode->init(2);///Node's Order
    ///m_rightVibNode->setFreq(m_deviceParameters->m_addVibFreq);
    //m_rightVibNode->setDirectionMap(m_cp->accAddDirection());
    m_rightVibNode->setDirectionMap(m_deviceParameters->getDeviceParameter("ADDVIBFORWARDDIR"),\
                                    m_deviceParameters->getDeviceParameter("ADDVIBLATERALDDIR"),\
                                    m_deviceParameters->getDeviceParameter("ADDVIBVERTICALDIR"));

    connect(this,&Engine::deviceDebugModel,m_leftVibNode,&AccelerateNode::setDebugMode);
    connect(this,&Engine::deviceDebugModel,m_rightVibNode,&AccelerateNode::setDebugMode);
    //connect(m_gbVibNode,&AccelerateNode::sigAccData,m_dataLogger,&DataLogger::gbVibAppend);
    //connect(m_addVibNode,&AccelerateNode::sigAccData,m_dataLogger,&DataLogger::addVibAppend);
    connect(m_leftVibNode,&AccelerateNode::sigAccData,m_sensorHub,&SensorHub::sltGBVibData);
    connect(m_rightVibNode,&AccelerateNode::sigAccData,m_sensorHub,&SensorHub::sltaddVibData);

    m_micNode = new MicNode();
    m_micNode->init();
    ///m_micNode->setFreq(m_deviceParameters->m_UpperPitNoiseFreq);
    connect(m_micNode,&MicNode::sigMicData,m_dataLogger,&DataLogger::micAppend);
    connect(m_micNode,&MicNode::sigMicData,m_sensorHub,&SensorHub::sltMicData);
    connect(this,&Engine::triggerMicRecord,m_micNode,&MicNode::triggerWavlogger);

    m_sensorHub->setAcc(m_leftVibNode,m_rightVibNode);
    connect(this,&Engine::deviceDebugModel,m_micNode,&MicNode::setDebugMode);

    connect(m_dataLogger,&DataLogger::sigShiftFile,m_micNode,&MicNode::sltShiftFile);
    connect(m_dataLogger,&DataLogger::sigShiftFile,m_rightVibNode,&AccelerateNode::sltShiftFile);
    connect(m_dataLogger,&DataLogger::sigShiftFile,m_leftVibNode,&AccelerateNode::sltShiftFile);

    connect(m_leftVibNode,&AccelerateNode::sigNodeInsert,this,&Engine::rebootPrepare);
    connect(m_rightVibNode,&AccelerateNode::sigNodeInsert,this,&Engine::rebootPrepare);

    connect(m_leftVibNode,&AccelerateNode::sigRemoved,m_sensorHub,&SensorHub::leftVibRemoved);
    connect(m_rightVibNode,&AccelerateNode::sigRemoved,m_sensorHub,&SensorHub::rightVibRemoved);

    connect(m_leftVibNode,&AccelerateNode::sigRemoved,this,&Engine::sltleftVibRemoved);
    connect(m_rightVibNode,&AccelerateNode::sigRemoved,this,&Engine::sltrightVibRemoved);
}


void Engine::initPcHelper(){
    m_helperConnected = false;
    ///m_webSocketPcHelper = new WebSocketServer();
    m_PcHelperClient = new cdcProtocol();

    //connect(m_webSocketPcHelper,&WebSocketServer::sigConnect,this,&Engine::helperConnected);
    //connect(m_webSocketPcHelper,&WebSocketServer::sigDisconnect,this,&Engine::helperDisconnected);
    //connect(m_webSocketPcHelper,&WebSocketServer::helperMsg,this,&Engine::helperMessage);
    connect(m_PcHelperClient,&cdcProtocol::sigConnect,this,&Engine::helperConnected);
    connect(m_PcHelperClient,&cdcProtocol::sigDisconnect,this,&Engine::helperDisconnected);
    connect(m_PcHelperClient,&cdcProtocol::helperMsg,this,&Engine::helperMessage);

    m_helperRealtimeDataTimer = new QTimer(this);
    m_helperRealtimeDataTimer->setInterval(1000);// realtime status defult interval is 1 seconds.
    connect(m_helperRealtimeDataTimer,&QTimer::timeout,this,&Engine::helperRealtimeDataTrigger);

    connect(m_leftVibNode,&AccelerateNode::sigAccData,this,&Engine::gbVibDataHelper);
    connect(m_rightVibNode,&AccelerateNode::sigAccData,this,&Engine::addVibDataHelper);
    connect(m_micNode,&MicNode::sigMicData,this,&Engine::topMicDataHelper);

    //connect(this,&Engine::sigStartPcHelper,m_webSocketPcHelper,&WebSocketServer::startWork);
    //connect(this,&Engine::sigSendHelperJson,m_webSocketPcHelper,&WebSocketServer::sendJson);

    //connect(this,&Engine::sigStartPcHelper,m_webSocketPcHelper,&WebSocketServer::startWork);
    //connect(this,&Engine::sigSendHelperJson,m_webSocketPcHelper,&WebSocketServer::sendJson);
    connect(this,&Engine::sigStartPcHelper,m_PcHelperClient,&cdcProtocol::startWork);
    connect(this,&Engine::sigSendHelperJson,m_PcHelperClient,&cdcProtocol::sendJson);

    connect(this,&Engine::deviceDebugModel,m_dataLogger,&DataLogger::deviceDebugModel);
    ///m_webSocketPcHelper->init();
    m_PcHelperClient->init();
}

void Engine::initPeopleCountLogic(){
    m_isFirstPeoplePassed = false;
    m_peopleDetectTimer = new QTimer();
    m_peopleDetectTimer->setInterval(1000);
    connect(m_peopleDetectTimer,&QTimer::timeout,this,&Engine::peopleCountLogicTimerSlot);
}

void Engine::peopleCountLogicTimerSlot(){    
    //    if(!m_isFirstPeoplePassed && m_GlobleNodeConnectStatus){
    //        //IDE_TRACE();
    //        LedController::deviceModeLight(!m_devLightStatus);
    //        m_devLightStatus = !m_devLightStatus;
    //    }else{
    //        if(m_peopleDetectTimer)
    //            m_peopleDetectTimer->stop();
    //        ///IDE_TRACE();
    //        LedController::deviceModeLight(m_GlobleNodeConnectStatus);
    //    }
    m_devLightStatus = !m_devLightStatus;
    LedController::deviceModeLight(m_devLightStatus);
}

///Init Function   **********************  End

///Start Function   **********************  Start
void Engine::startInterProtocol(){
    emit sigStartInterProtocol();
}
void Engine::startLogger(){
    emit sigStartLogger();
}
void Engine::startWebsocket(){    
    emit sigStartWebSocketClient();
}
void Engine::startLogic(){
    m_routineCall->startWork();
}
void Engine::startSensorHub(){
    emit sigStartSensorHub();
    int interval = m_deviceParameters->getDeviceParameter("KPIinterval")*1000;
    m_kpiTimer->setInterval(interval);
    m_kpiTimer->start();
}
void Engine::startFtpClient(){
    emit sigStartFtpClient();
}
void Engine::startOnboradNode(){
    m_leftVibNode->startWork();
    m_rightVibNode->startWork();
    m_micNode->startWork();
}
void Engine::startPcHelper(){
    emit sigStartPcHelper();
}

void Engine::startPeopleCountLogic(){
    //    if(m_peopleDetectTimer){
    //        m_peopleDetectTimer->start();
    //    }
}

///Start Function   **********************  End

///PC Helper **********************  Start
void Engine::helperConnected(){
    //LedController::deviceModeLight(true);
    IDE_TRACE();
    enterHelperModel();
    //    connect(m_leftVibNode,&AccelerateNode::sigAccData,this,&Engine::gbVibDataHelper);
    //    connect(m_rightVibNode,&AccelerateNode::sigAccData,this,&Engine::addVibDataHelper);
    //    connect(m_micNode,&MicNode::sigMicData,this,&Engine::topMicDataHelper);
}

void Engine::helperDisconnected(){
    ///LedController::deviceModeLight(false);
    IDE_TRACE();
    leaveHelperModel();
    //    disconnect(m_leftVibNode,&AccelerateNode::sigAccData,this,&Engine::gbVibDataHelper);
    //    disconnect(m_rightVibNode,&AccelerateNode::sigAccData,this,&Engine::addVibDataHelper);
    //    disconnect(m_micNode,&MicNode::sigMicData,this,&Engine::topMicDataHelper);
}

void Engine::enterHelperModel(){
    IDE_TRACE();
    if(m_helperRealtimeDataTimer&&m_helperRealtimeDataTimer->isActive()){
        IDE_TRACE();
        m_helperRealtimeDataTimer->stop();
    }
    m_helperConnected = true;
    m_helperRealTimeBuffer.clear();
    //////////////////////////////close all local storage files.
    IDE_TRACE();
    emit deviceDebugModel(true);
    helper_getparameters();
    helper_reportAccDirection();
}

void Engine::leaveHelperModel(){
    IDE_TRACE();
    m_helperConnected = false;
    m_helperRealtimeDataTimer->stop();
    emit deviceDebugModel(false);
}

void Engine::helperMessage(QJsonObject msgObj){
    if(msgObj.isEmpty())
        return;
    qDebug()<<"helperMessage " <<msgObj;
    if(msgObj.contains("type")){
        QString msgType = msgObj.value("type").toString();
        if(!QString::compare("get",msgType,Qt::CaseInsensitive)){
            if(msgObj.contains("subtype")){
                QString subType = msgObj.value("subtype").toString();
                if(!QString::compare("parameter",subType,Qt::CaseInsensitive)){
                    ///IDE_TRACE();
                    helper_getparameters();
                }else if(!QString::compare("accdirection",subType,Qt::CaseInsensitive)){
                    ///IDE_TRACE();
                    helper_reportAccDirection();
                }else{
                    ///IDE_TRACE();
                }
            }
        }else if(!QString::compare("set",msgType,Qt::CaseInsensitive)){
            if(msgObj.contains("subtype")){
                QString subType = msgObj.value("subtype").toString();
                if(!QString::compare("parameter",subType,Qt::CaseInsensitive)){
                    ///IDE_TRACE();
                    helper_setParameter(msgObj.value("payload").toObject());
                }else if(!QString::compare("accdirection",subType,Qt::CaseInsensitive)){
                    //IDE_TRACE();
                    helper_setAxis(msgObj.value("payload").toObject());
                }else{
                    ///IDE_TRACE();
                }
            }

            ///helper_setParameter(msgObj.value("payload").toObject());
        }else if(!QString::compare("cmd",msgType,Qt::CaseInsensitive)){
            if(msgObj.contains("subtype")){
                QString subType = msgObj.value("subtype").toString();
                //IDE_TRACE_STR(subType);
                if(!QString::compare("realtimedata",subType,Qt::CaseInsensitive)){
                    if(msgObj.contains("payload")){
                        ///IDE_TRACE();
                        QJsonObject cmd = msgObj.value("payload").toObject();
                        QString cmdStr = cmd.value("cmd").toString();
                        if(!QString::compare("start",cmdStr,Qt::CaseInsensitive)){
                            //IDE_TRACE();
                            helper_onlinestatus(true);
                        }else{
                            helper_onlinestatus(false);
                        }
                    }
                }else if(!QString::compare("micrecord",subType,Qt::CaseInsensitive)){
                    //IDE_TRACE();
                    emit triggerMicRecord("");
                }else if(!QString::compare("systemcmd",subType,Qt::CaseInsensitive)){
                    //IDE_TRACE();
                    if(msgObj.contains("payload")){
                        ///IDE_TRACE();
                        QJsonObject cmd = msgObj.value("payload").toObject();
                        QString cmdStr = cmd.value("cmd").toString();
                        if(!QString::compare("reboot",cmdStr,Qt::CaseInsensitive)){
                            //IDE_TRACE();
                            helper_onlinestatus(false);
                            rebootPrepare();
                        }
                    }
                }
            }
        }
    }
}

void Engine::rebootPrepare(){
    IDE_TRACE();
    m_dataLogger->closeFiles();
    LedController::deviceModeLight(false);
    LedController::onlineLight(false);
    system("sync");
    system("reboot");
}

void Engine::helper_getparameters(){
    IDE_TRACE();
    QJsonObject obj = m_deviceParameters->getDeviceParameters();
    emit sigSendHelperJson(obj,"parameter");
    IDE_TRACE();
}

void Engine::helper_reportAccDirection(){
    QJsonObject obj;
    IDE_TRACE();
    obj.insert("Message","VibAxisSetting");
    obj.insert("type","gb");

    QString gbacc = QString("%1,%2,%3").arg(m_deviceParameters->getDeviceParameter("GBVIBFORWARDDIR")).arg(
                m_deviceParameters->getDeviceParameter("GBVIBLATERALDDIR")).arg(
                m_deviceParameters->getDeviceParameter("GBVIBVERTICALDIR"));
    obj.insert("value",gbacc);
    m_rightVibNode = new AccelerateNode();
    m_rightVibNode->init(2);///Node's Order
    ///m_rightVibNode->setFreq(m_deviceParameters->m_addVibFreq);
    //m_rightVibNode->setDirectionMap(m_cp->accAddDirection());

    QString addacc = QString("%1,%2,%3").arg(m_deviceParameters->getDeviceParameter("ADDVIBFORWARDDIR")).arg(
                m_deviceParameters->getDeviceParameter("ADDVIBLATERALDDIR")).arg(
                m_deviceParameters->getDeviceParameter("ADDVIBVERTICALDIR"));
    obj.insert("value",addacc);

    IDE_TRACE();
    emit sigSendHelperJson(obj,"accdirection");
    obj.insert("type","add");
    obj.insert("value",m_cp->accAddDirection());
    emit sigSendHelperJson(obj,"accdirection");
    IDE_TRACE();
}

void Engine::helper_setParameter(QJsonObject msgObj){
    ///IDE_TRACE();
    if(msgObj.contains("Parameters")&&msgObj.contains("Value")){
        QString paraName = msgObj.value("Parameters").toString();
        int paravalue = msgObj.value("Value").toInt();
        m_deviceParameters->setParameter(paraName,paravalue);
    }else{
        IDE_TRACE();
    }
}
void Engine::helper_setAxis(QJsonObject msgObj){
    if(msgObj.contains("type")){
        QString paraName = msgObj.value("type").toString();
        QString va = msgObj.value("value").toString();
        if(va.isEmpty())
            return;
        if(!QString::compare(paraName,"gb",Qt::CaseInsensitive)){
            m_leftVibNode->setDirectionMap(va);
            this->updateGbAccDirection(va);
        }else if(!QString::compare(paraName,"add",Qt::CaseInsensitive)){
            m_rightVibNode->setDirectionMap(va);
            this->updateAddAccDirection(va);
        }
    }else{
        IDE_TRACE();
    }
}


void Engine::helper_onlinestatus(bool flag){
    if(flag){
        ///IDE_TRACE();
        m_helperRealtimeDataTimer->start();
    }else{
        ///IDE_TRACE();
        m_helperRealtimeDataTimer->stop();
    }
}
void Engine::helperRealtimeDataTrigger(){
    if(m_helperConnected){
        QJsonObject obj;
        QJsonObject param;
        obj.insert("Message",QJsonValue("RealtimeData"));
        //obj.insert("AnyEscalatorID",QJsonValue(AnyEscalator_ID));
        //obj.insert("Timestamp",QJsonValue(getTimestamp()));
        m_helperRealTimeBuffer.insert("PeopleCount",m_TotalPeopleCount);
        param = QJsonObject::fromVariantMap(m_helperRealTimeBuffer);
        obj.insert("Param",QJsonValue(param));
        emit sigSendHelperJson(obj,"realtimedata");
        //IDE_TRACE();
    }else{
        IDE_TRACE();
    }
}
///PC Helper **********************  End

///DTU数据
void Engine::sltSendJsonMsg(QJsonObject obj){
    emit sigSendJsonMsg(obj);
}
void Engine::dtuWebSocketConnected(){
    IDE_TRACE();
    LedController::onlineLight(true);
    bootUpDTUMsg();
    if(m_ftpClient){
        m_ftpClient->connectToFtp();
    }
}
void Engine::dtuWebSocketDisconnected(){
    LedController::onlineLight(false);
    IDE_TRACE();
}

void Engine::dtuMessage(QJsonObject msgObj){
    //qDebug()<<"dtuMessage: " <<msgObj;
    if(msgObj.isEmpty())
        return;
    if(msgObj.contains(MESSAGE_TEXT)){
        QString msgType = msgObj.value(MESSAGE_TEXT).toString();
        if(!QString::compare("ConfigurationDownload",msgType)){
            IDE_TRACE();
            dtu_configurationDownload(msgObj);
        }else if(!QString::compare("StartStatus",msgType)){
            IDE_TRACE();
            dtu_startStatus(msgObj);
        }else if(!QString::compare("StopStatus",msgType)){
            IDE_TRACE();
            dtu_stopStatus();
        }else if(!QString::compare("AnyEscalatorRawDataRequest",msgType)){
            IDE_TRACE();
            dtu_rawDataRequest(msgObj);
        }else if(!QString::compare("AnyEscalatorSWUpdateRequest",msgType)){
            IDE_TRACE();
            dtu_swUpdateRequest(msgObj);
        }else if(!QString::compare("AnyEscalatorTimeSync",msgType)){
            IDE_TRACE();
            dtu_timeSync(msgObj);
        }
    }
}

void Engine::dtu_configurationDownload(QJsonObject &obj){
    m_deviceParameters->setDeviceParameters(obj);
}

void Engine::dtu_startStatus(QJsonObject &obj){
    //Q_UNUSED(obj);
    if(obj.contains("Param")){
        QJsonObject para = obj.value("Param").toObject();
        if(para.contains("Duration")){
            int duration = para.value("Duration").toInt(0);
            if(duration >0){
                startOnlineStatus(duration);
            }
        }
    }
}

void Engine::dtu_stopStatus(){
    m_onolineStatusTimer->stop();
    //    m_kpiTimer->setInterval(m_deviceParameters->getDeviceParameter("KPIinterval")*1000);
    //    m_kpiTimer->start();
}

void Engine::startOnlineStatus(int elapseSeconds)
{
    if(elapseSeconds >0){
        m_onlineCounter = elapseSeconds;
        m_onolineStatusTimer->start();
    }
}

void Engine::OnlineStatusTrigger(){
    if(m_onlineCounter >0){
        m_onlineCounter--;
        if(m_onlineCounter == 0){
            m_onolineStatusTimer->stop();
        }else{
            emit sigOnlineStatusTrigger();
        }
    }
}

void Engine::dtu_rawDataRequest(QJsonObject &obj){
    if(isUploadingRawData){
        RawDataUploaded(Operate_Result_Fail);
    }

    if(obj.contains("Param")){
        QJsonObject para = obj.value("Param").toObject();
        if(para.contains("RawDataRange")){
            QJsonObject rawData = para.value("RawDataRange").toObject();
            if(rawData.contains("start")&&rawData.contains("end")){
                QString startDate = para.value("start").toString();
                QString endDate = para.value("end").toString();
                QDateTime start = QDateTime::fromString(startDate,Qt::ISODate);
                QDateTime end = QDateTime::fromString(endDate,Qt::ISODate);
                if(start.isValid()&&end.isValid()&&end>start){
                    getRawDataList(start,end);
                    //if(!m_ftpClient->m_uploadList.isEmpty()){
                    emit sigStartUploadFile(m_baseDirPath);
                    //m_ftpClient->startUploadFile(m_dataLogger->m_baseDirPath);
                    //}
                }else{
                    IDE_TRACE();
                }
            }
        }
    }

    /*
    {
        "Message": "AnyEscalatorRawDataRequest",
        "EquipmentNumber":132456789,
        "Version" : 0，
                "Param":
        {
            "Timestamp": "2015-05-28T15:35:48.000Z",
            "RawDataRange":
            {
                "start": "2015-05-28T15:00:00",
                "end": "2015-05-28T16:00:00"
            }
        }
    }
*/
}
void Engine::getRawDataList(QDateTime start,QDateTime end){
    m_RawFileMap.clear();
    if(!start.isValid()||!end.isValid()){
        IDE_TRACE();
        return;
    }

    QDir dir(m_baseDirPath);
    if(!dir.exists()){
        return;
    }
    QDate startDate = start.date();
    QDate endDate =  end.date();

    if(!startDate.isValid()||!endDate.isValid()){
        IDE_TRACE();
        return;
    }

    //    if(!m_ftpClient->canUploadFile()){
    //        IDE_TRACE();
    //        return;
    //    }
    isUploadingRawData = true;

    if(dir.exists()){
        QFileInfoList dirList = dir.entryInfoList(QDir::Dirs|QDir::NoDotAndDotDot,QDir::Name);
        for(int i = 0;i<dirList.count();i++){
            QString dirName = dirList.at(i).fileName();
            QDate dirDate = QDate::fromString(dirName,"yyyyMMdd");
            if(dirDate.isValid() && dirDate>=startDate && dirDate<=endDate){
                //IDE_TRACE_STR(dirName);
                dir.cd(dirName);
                //IDE_TRACE_STR(dir.path());
                QFileInfoList subdirList = dir.entryInfoList(QDir::Dirs|QDir::NoDotAndDotDot,QDir::Name);
                for(int j = 0;j<subdirList.count();j++){
                    QString subdirName = subdirList.at(j).fileName();
                    QDateTime dirDateTime = QDateTime::fromString(subdirName,"yyyyMMdd_hh");
                    if(dirDateTime.isValid()&&dirDateTime >= start&& dirDateTime <= end){
                        //IDE_TRACE_STR(subdirName);
                        dir.cd(subdirName);
                        //IDE_TRACE_STR(dir.relativeFilePath());
                        QFileInfoList itemList = dir.entryInfoList(QDir::Files|QDir::NoDotAndDotDot,QDir::Name);
                        for(int k=0;k<itemList.count();k++){
                            emit sigAppendUploadFile(dirName + "/" + subdirName + "/" + itemList.at(k).fileName());
                            //m_ftpClient->appendUploadFile(dirName + "/" + subdirName + "/" + itemList.at(k).fileName());
                        }
                        dir.cdUp();
                    }else{
                        IDE_TRACE_STR(subdirName);
                    }
                }
                dir.cdUp();
            }else{
                IDE_TRACE();
            }
        }
    }else{
        IDE_TRACE();
    }
}
void Engine::dtu_swUpdateRequest(QJsonObject &obj){
    qDebug()<<"dtu_swUpdateRequest"<<obj;
    if(obj.contains("Param")){
        QJsonObject para = obj.value("Param").toObject();
        if(para.contains("AnyEscalatorEvent")){
            QJsonObject sw = para.value("AnyEscalatorEvent").toObject();
            if(sw.contains("SWVersion")){
                QString swFile = sw.value("SWVersion").toString();
                IDE_TRACE_STR(swFile);
                if(!swFile.isEmpty()){
                    //m_ftpClient->getFile(m_softwareUpdater,swFile);
                    emit sigGetFile(m_softwareUpdater,swFile);
                }else{
                    IDE_TRACE();
                }
            }else{
                IDE_TRACE();
            }
        }else{
            IDE_TRACE();
        }
    }else{
        IDE_TRACE();
    }
    /*
    {
        "Message": "AnyEscalatorSWUpdateRequest",
        "EquipmentNumber": 132456789,
        "Version": 0,
        "Param":
        {
            "Timestamp": "2015-05-28T15:35:48.000Z",
            "AnyEscalatorEvent":
            {
                "SWVersion": "AnyEscalator_ibm_20170205"
            }
        }
    }
    */
}

void Engine::dtu_timeSync(QJsonObject &obj){
    Q_UNUSED(obj);
    /*
        {
            "Message": "AnyEscalatorTimeSync",
            "EquipmentNumber":132456789,
            "Timestamp": "2015-05-28T15:35:48.000Z"
        }
    */
    if(obj.contains(TIME_STAMPS)){
        QString utcTime = obj.value(TIME_STAMPS).toString();
        QDateTime dateTime = QDateTime::fromString(utcTime, Qt::ISODate);
        //qDebug()<<"dtu_timeSync:" << dateTime;
        QString cmd = QString("date -s \"%1\"").arg(dateTime.toString(Qt::ISODate));

#ifndef WINDOWS
        QByteArray ba;
        ba.append(cmd);
        system(ba.data());
        system("hwclock -w");
#endif
        //IDE_TRACE_STR(cmd);
    }
    /*
        SYSTEMTIME st;
        GetSystemTime(&st);
        st.wYear = 2018;
        qDebug()<<SetSystemTime(&st);

        struct tm nowtime;
        time_t t;
        nowtime.tm_sec=56;
        nowtime.tm_min=34;
        nowtime.tm_hour=12;
        nowtime.tm_mday=23;
        nowtime.tm_mon=8-1;
        nowtime.tm_year=2013-1900;
        nowtime.tm_isdst=-1;
        t=mktime(&nowtime);
        stime(&t);
        */
}

void Engine::bootUpDTUMsg(){
    ///"Message":"DeviceStatus"
    m_deviceStatus->reportDeviceStatus();
    ///"Message":"ConfigurationChange"
    m_deviceParameters->reportDeviceParameters();

    ///"Message":"DeviceStatus"
    //m_webSocketClient->sendJson(m_deviceStatus->getDeviceStatus());
    ///"Message":"ConfigurationChange"
    //m_webSocketClient->sendJson(m_deviceParameters->getDeviceParameters());
}

void Engine::SWUpdateComplete(int updateStatus){
    //if(m_webSocketClient->alive()){
    QJsonObject Obj;
    Obj.insert("Message",QJsonValue("AnyEscalatorSWUpdateComplete"));
    Obj.insert("AnyEscalatorID",QJsonValue(AnyEscalator_ID));
    Obj.insert("Version",QJsonValue(SERVER_VERSION));
    Obj.insert("Timestamp",QJsonValue(getTimeStamp()));
    Obj.insert("updatestatus",QJsonValue(updateStatus));
    //m_webSocketClient->sendJson(Obj);
    emit sigSendJsonMsg(Obj);
    //}
}

void Engine::RawDataUploaded(int updateStatus){
    //if(m_webSocketClient->alive()){
    QJsonObject Obj;
    Obj.insert("Message",QJsonValue("RawDataUploaded"));
    Obj.insert("AnyEscalatorID",QJsonValue(AnyEscalator_ID));
    Obj.insert("Version",QJsonValue(SERVER_VERSION));
    Obj.insert("Timestamp",QJsonValue(getTimeStamp()));
    Obj.insert("updatestatus",QJsonValue(updateStatus));
    //m_webSocketClient->sendJson(Obj);
    emit sigSendJsonMsg(Obj);
    //}
}

void Engine::getFTPFileFinished(QString fileName,bool isSucceed){
    IDE_TRACE();
    ///For Now : Only software update use 'get' to get the file from the server
    if(!QString::compare(m_softwareUpdater,fileName,Qt::CaseInsensitive)){
        if(isSucceed){
            IDE_TRACE();
            SWUpdateComplete(Operate_Result_OK);
            rebootPrepare();
        }else{
            SWUpdateComplete(Operate_Result_Fail);
        }
    }else{
        IDE_TRACE_STR(m_softwareUpdater);
        IDE_TRACE_STR(fileName);
    }
}
void Engine::uploadRawFileCompelete(bool isSucceed){
    if(isSucceed){
        SWUpdateComplete(Operate_Result_OK);
    }else{
        SWUpdateComplete(Operate_Result_Fail);
    }
}
void Engine::putFTPFileFinished(QString fileName,bool isSucceed){
    Q_UNUSED(fileName);
    ///For Now : Only Raw Data update use 'put' to put the file to the server
    if(isSucceed){
        IDE_TRACE();
    }else{
        RawDataUploaded(Operate_Result_Fail);
    }
}

///DTU配置参数
void Engine::sltgbVibFreq(int freq){
    m_leftVibNode->setFreq(freq);
}
void Engine::sltaddVibFreq(int freq){
    ///IDE_TRACE_INT(freq);
    m_rightVibNode->setFreq(freq);
}
void Engine::sltTcFreq(int freq){
    m_interProtocol->sendFreq(THERMOCOUPLE,freq);
}
void Engine::sltInfraredFreq(int freq){
    m_interProtocol->sendFreq(INFRARED,freq);
}
void Engine::sltKPIFreq(int freq){
    m_kpiTimer->setInterval(freq*1000);
    m_kpiTimer->start();
    if(m_sensorHub)
        m_sensorHub->m_Duration = freq;
    IDE_TRACE_INT(freq);
}
void Engine::sltMicFreq(int freq){
    //IDE_TRACE_INT(freq);
    m_micNode->setFreq(freq);
}

///传感器数据
void Engine::thermoCoupleData(QString data){    
    /// 1#%1@2#%2@3#%3@4#%4
    //IDE_TRACE_STR(data);
    QStringList nodeList = data.split(SENSOR_SPLIT);
    if(nodeList.count() !=4)
        return;
    qreal t1 = 0.0;
    qreal t2 = 0.0;
    qreal t3 = 0.0;
    qreal t4 = 0.0;
    QString nodeData;
    int index;
    for(int i = 0; i < nodeList.size(); ++i){
        nodeData = nodeList.at(i);
        QStringList nodeDataList = nodeData.split(NAME_SPLIT);
        if(nodeDataList.count() == 2){
            nodeData = nodeDataList.at(0);
            index = nodeData.toInt();
            if(index == 1){
                nodeData = nodeDataList.at(1);
                t1 = nodeData.toDouble();
            }else if(index == 2){
                nodeData = nodeDataList.at(1);
                t2 = nodeData.toDouble();
            }else if(index == 3){
                //nodeData = nodeDataList.at(1);
                //t3 = nodeData.toDouble();
            }else if(index == 4){
                //nodeData = nodeDataList.at(1);
                //t4 = nodeData.toDouble();
            }else{

            }
        }
    }
    if(m_helperConnected){
        m_helperRealTimeBuffer.insert("GBTemp1",t1);
        m_helperRealTimeBuffer.insert("GBTemp2",t2);
        //m_helperRealTimeBuffer.insert("GBTemp3",t3);
        //m_helperRealTimeBuffer.insert("GBTemp4",t4);
    }
    emit sTcData(t1,t2,t3,t4);
}
void Engine::infradData(QString data){
    ///"1#%1,%2@2#%3,%4"
    //IDE_TRACE_STR(data);
    QStringList nodeList = data.split(SENSOR_SPLIT);
    if(nodeList.count() !=2)
        return;
    qreal t1 = 0.0;
    qreal t2 = 0.0;
    qreal a1 = 0.0;
    qreal a2 = 0.0;
    int index;
    QString nodeData;
    for(int i = 0; i < nodeList.size(); ++i){
        nodeData = nodeList.at(i);
        QStringList nodeDataList = nodeData.split(NAME_SPLIT);
        if(nodeDataList.count() == 2){
            nodeData = nodeDataList.at(1);
            QStringList dataList = nodeData.split(DATA_SPLIT);
            if(dataList.count()==2){
                nodeData = nodeDataList.at(0);
                index = nodeData.toInt();
                if(index == 1){
                    nodeData = dataList.at(0);
                    t1 = nodeData.toDouble();
                    nodeData = dataList.at(1);
                    a1 = nodeData.toDouble();
                }else if(index == 2){
                    nodeData = dataList.at(0);
                    t2 = nodeData.toDouble();
                    nodeData = dataList.at(1);
                    a2 = nodeData.toDouble();
                }else{

                }

            }
        }
    }
    if(m_helperConnected){
        ///IDE_TRACE();
        m_helperRealTimeBuffer.insert("HandrailTempLeftInfrared",t1);
        m_helperRealTimeBuffer.insert("HandrailTempRightInfrared",t2);
        m_helperRealTimeBuffer.insert("HandrailAmbTempLeft",a1);
        m_helperRealTimeBuffer.insert("HandrailAmbTempRight",a2);
    }
    emit sInfradData(t1,t2,a1,a2);
}
void Engine::powerData(QString data){
    ///1#%1,%2,%3,%4,%5,%6
    //IDE_TRACE_STR(data);
    QStringList nodeList = data.split(NAME_SPLIT);
    if(nodeList.count() !=2)
        return;
    qreal a1 = 0.0;
    qreal a2 = 0.0;
    //qreal apprencePower = 0.0;
    qreal noActivePower = 0.0;
    qreal a3 = 0.0;
    qreal active = 0.0;
    qreal total = 0.0;
    qreal comsuption  =0.0;
    int index;
    QString nodeData;

    nodeData = nodeList.at(0);
    index = nodeData.toInt();
    if(index != 1)
        return;
    nodeData = nodeList.at(1);

    QStringList nodeDataList = nodeData.split(DATA_SPLIT);
    if(nodeDataList.count() != 5)
        return;
    nodeData = nodeDataList.at(0);
    a1 = nodeData.toDouble();
    nodeData = nodeDataList.at(1);
    //apprencePower = nodeData.toDouble();
    nodeData = nodeDataList.at(2);
    a3 = nodeData.toDouble();
    nodeData = nodeDataList.at(3);
    noActivePower = nodeData.toDouble();
    nodeData = nodeDataList.at(4);
    total = nodeData.toDouble();
    nodeData = nodeDataList.at(5);
    comsuption = nodeData.toDouble();

    a2 = a1*a1+a3*a3-a1*a3;
    active = total*total - noActivePower*noActivePower;

    if(m_helperConnected){
        m_helperRealTimeBuffer.insert("MotorCurrent1",a1);
        m_helperRealTimeBuffer.insert("MotorCurrent2",qSqrt(a2));
        m_helperRealTimeBuffer.insert("MotorCurrent3",a3);
        m_helperRealTimeBuffer.insert("MotorPowerActive",qSqrt(active));
        m_helperRealTimeBuffer.insert("MotorPowerTotal",total);
        m_helperRealTimeBuffer.insert("PowerComsuption",comsuption);
        ///Comsuption
    }
    emit sPowerData(a1,a2,a3,active,total,comsuption);
}
void Engine::speedData(QString data){
    ///1#%1
    //IDE_TRACE_STR(data);
    QStringList nodeList = data.split(NAME_SPLIT);
    if(nodeList.count() !=2)
        return;
    int speed = 0;
    int index;
    QString nodeData;

    nodeData = nodeList.at(0);
    index = nodeData.toInt();
    if(index != 1)
        return;
    nodeData = nodeList.at(1);
    speed = nodeData.toInt();
    if(m_helperConnected){
        m_helperRealTimeBuffer.insert("RunSpeed",speed);
    }
    emit sSpeedData(speed);
}
void Engine::peopleCountData(QString data){
    if(!QString::compare(data,"1#0",Qt::CaseSensitive)){
        //IDE_TRACE();
        return;
    }
    if(!m_isFirstPeoplePassed){
        m_isFirstPeoplePassed = true;
        ////m_peopleDetectTimer->stop();
    }
    /*
    //Back Up Code
    //    IDE_TRACE_STR(data);
    //    QStringList nodeList = data.split(NAME_SPLIT);
    //    if(nodeList.count() !=2)
    //        return;
    //    int peopleCount = 0;
    //    int index;
    //    QString nodeData;

    //    nodeData = nodeList.at(0);
    //    index = nodeData.toInt();
    //    if(index != 1)
    //        return;
    //    nodeData = nodeList.at(1);
    //    peopleCount = nodeData.toInt();

    //    m_TotalPeopleCount += peopleCount;
    */
    m_TotalPeopleCount ++;
    m_settings->setValue("peopleCount",m_TotalPeopleCount);
    //IDE_TRACE_INT(m_TotalPeopleCount);
    //    if(m_helperConnected){
    //        m_helperRealTimeBuffer.insert("PeopleCount",m_TotalPeopleCount);
    //    }
    emit sPeopleCountData(m_TotalPeopleCount);
}

void Engine::directionData(QString data){
    ///1#%1
    ///IDE_TRACE_STR(data);
    QStringList nodeList = data.split(NAME_SPLIT);
    if(nodeList.count() !=2)
        return;
    int direction = 0;
    int index;
    QString nodeData;

    nodeData = nodeList.at(0);
    index = nodeData.toInt();
    if(index != 1)
        return;
    nodeData = nodeList.at(1);
    direction = nodeData.toInt();
    if(m_helperConnected){
        m_helperRealTimeBuffer.insert("RunDirecction",direction);
    }
    emit sDirectionData(direction);
}

void Engine::gbVibDataHelper(qreal forward, qreal lateral, qreal vertical)
{
    //
    if(m_helperConnected){
        //IDE_TRACE();
        m_helperRealTimeBuffer.insert("GBVibForward",toFixedFloat(forward/1000.0,3));
        m_helperRealTimeBuffer.insert("GBVibLateral",toFixedFloat(lateral/1000.0,3));
        m_helperRealTimeBuffer.insert("GBVibVertical",toFixedFloat(vertical/1000.0,3));
    }
}
void Engine::addVibDataHelper(qreal forward, qreal lateral, qreal vertical)
{
    //    IDE_TRACE_INT(forward);
    //    IDE_TRACE_INT(lateral);
    //    IDE_TRACE_INT(vertical);
    if(m_helperConnected){
        //IDE_TRACE();
        m_helperRealTimeBuffer.insert("addVibForward",toFixedFloat(forward/1000.0,3));
        m_helperRealTimeBuffer.insert("addVibLateral",toFixedFloat(lateral/1000.0,3));
        m_helperRealTimeBuffer.insert("addVibVertical",toFixedFloat(vertical/1000.0,3));
    }
}
void Engine::topMicDataHelper(qreal micRMS)
{
    //IDE_TRACE();
    if(m_helperConnected){
        m_helperRealTimeBuffer.insert("UppePitNoiserms",toFixedFloat(micRMS,3));
    }
}

void Engine::sltleftVibRemoved(){
    nodeConnectStatus(Vib_Left,false);
}
void Engine::sltrightVibRemoved(){
    nodeConnectStatus(Vib_Right,false);
}

void Engine::nodeConnectStatus(quint8 node,bool flag){    
    if(node < 5){
        mSensorStatus[node] = flag;
    }
    if(AllNodes == node){
        IDE_TRACE();
        mAllNodeStatus = node;
    }
    if(mAllNodeStatus&m_leftVibNode->isAccNodeConnected()&&m_rightVibNode->isAccNodeConnected()){
        m_GlobleNodeConnectStatus = true;
    }else{
        m_GlobleNodeConnectStatus = false;
    }

    if(m_GlobleNodeConnectStatus){
        if(!m_isFirstPeoplePassed && !m_peopleDetectTimer->isActive()){
            m_peopleDetectTimer->start();
        }
    }else{
        if(m_peopleDetectTimer && m_peopleDetectTimer->isActive()){
            m_peopleDetectTimer->stop();
        }
    }
    LedController::deviceModeLight(m_GlobleNodeConnectStatus);
}

void Engine::updateGbAccDirection(QString map){
    if(map.isEmpty())
        return;
    QStringList list = map.split(",");
    if(list.count()!=3)
        return ;
    m_deviceParameters->setParameter("GBVIBFORWARDDIR",list.at(0).toInt());
    m_deviceParameters->setParameter("GBVIBLATERALDDIR",list.at(1).toInt());
    m_deviceParameters->setParameter("GBVIBVERTICALDIR",list.at(3).toInt());
}

void Engine::updateAddAccDirection(QString map){
    if(map.isEmpty())
        return;
    QStringList list = map.split(",");
    if(list.count()!=3)
        return ;
    m_deviceParameters->setParameter("ADDVIBFORWARDDIR",list.at(0).toInt());
    m_deviceParameters->setParameter("ADDVIBLATERALDDIR",list.at(1).toInt());
    m_deviceParameters->setParameter("ADDVIBVERTICALDIR",list.at(3).toInt());
}
