#ifndef CONFIGUREPARSER_H
#define CONFIGUREPARSER_H

#include <QObject>
#include <QSettings>

#include "xmlparse.h"
#include "sensordefine.h"
#include "../define.h"

class ConfigureParser : public XmlParse
{
    Q_OBJECT
public:
    ConfigureParser(QString fileName);
    ConfigureParser(QSettings setting);

    static const QString UiSuffix;
    static const QString UiFileType;

    bool openConfigure();
    bool closeConfigure();
    bool saveConfigure();

    void initConfigure();
    QString accGbDirection();
    QString accAddDirection();
    QDomElement getParameter();

    QString getManufacturer();
    QString getSWversion();
    QString getHDVersion();
    QString getVersion();
public:
    QHash<SENSOR_TYPE, QDomElement>  m_sensorNodes;

public slots:
    bool setAddAccDirection(QString direction);
    bool setGbAccDirection(QString direction);
};

#endif // CONFIGUREPARSER_H
