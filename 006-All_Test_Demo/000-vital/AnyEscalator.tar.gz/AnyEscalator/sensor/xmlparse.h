#ifndef XMLPARSE_H
#define XMLPARSE_H

#include <QObject>
#include <QRect>
#include <QFile>
#include <QFileInfo>
#include <QDir>
#include <QStringList>
#include <QDomDocument>
#include "../define.h"

class XmlParse : public QObject, public QDomDocument
{
    Q_OBJECT
public:
    XmlParse();
    XmlParse(QString fileName);
    ~XmlParse();


    static const QString XmlHead;
    static const QString XmlSuffix;

    void SetForcesave(bool pEnable) {m_ForceSave = pEnable;}

    bool getItemElement(QString itemPath);
    bool getItemElement(QDomElement itemDomElement, QString itemPath);
    bool searchItemElement(QString itemName);

    QString getItemElementValue();
    QString getItemElementValue(QString itemPath);

    QList<QDomAttr> getItemElementAttrs(QDomElement itemDomElement);
    QList<QDomAttr> getItemElementAttrs();
    QList<QDomAttr> getItemElementAttrs(QString itemPath);


    bool createItemElement(QString itemPath);
    bool createItemElement(QDomElement pParElement, QString pName, QString pValue);

    bool saveItemElement(QDomElement itemDomElement, QString& pContent);
    bool saveItemElement(QString &pContent);
    bool saveItemElement(QDomElement itemDomElement, QIODevice *pDevice);
    bool saveItemElement(QIODevice *pDevice);

    bool modifyItemElement(QString itemPath, QString value);
    bool modifyItemElement(QDomElement itemDomElement, QString value);
    bool setText(QDomElement itemDomElement, QString value);

    bool clearItemElement(QDomElement itemDomElement);
    bool deleteItemElement(QDomElement itemDomElement);

    QDomNodeList getChildNodes()
    {
        return itemElement.childNodes();
    }

    bool writeXml(QIODevice *device);
    bool readXml(QIODevice *device);
    bool openXml();
    bool createXml();
    bool saveXml();
    bool saveXmlAs(QString fileName);
    bool renameXml(QString fileName);


    bool modifyFreq(QDomElement itemDomElement, int value);
     bool modifyDeviceParameter(QDomElement itemDomElement, QString paraName, int value);
public:
    QString errorStr;
    int errorLine;
    int errorColumn;
    bool m_Valid;
    bool m_IsChanged;
    bool m_ForceSave;
    QString m_FileDir;
    QString m_FileName;
    QDomElement itemElement;

};


#endif // XMLPARSE_H
