#ifndef ACCELERATEDSENSOR_H
#define ACCELERATEDSENSOR_H

#include <QObject>
#include "sensorbase.h"

class AcceleratedSensor : public SensorBase
{
    Q_OBJECT
public:
    explicit AcceleratedSensor(SensorBase *parent = 0);
    void initSensor(QDomElement element, ConfigureParser *cp);

    void appendData(qreal forward, qreal lateral, qreal vertical);

    qreal Avg();
    qreal Peak();
    qreal Dip();
    qreal RMS();

    qreal lateralAvg();
    qreal lateralRMS();
    qreal lateralPeak();
    qreal lateralDip();

    qreal verticalAvg();
    qreal verticalRMS();
    qreal verticalPeak();
    qreal verticalDip();

    void clearBuffer();
signals:

public slots:

public:
    qreal m_forwardAvg;
    qreal m_forwardRMS;
    qreal m_forwardPeak;
    qreal m_forwardDip;


    qreal m_lateralAvg;
    qreal m_lateralRMS;
    qreal m_lateralPeak;
    qreal m_lateralDip;

    qreal m_verticalAvg;
    qreal m_verticalRMS;
    qreal m_verticalPeak;
    qreal m_verticalDip;

    QQueue<qreal> m_verticalQueue;
    QQueue<qreal> m_lateralQueue;

};

#endif // ACCELERATEDSENSOR_H
