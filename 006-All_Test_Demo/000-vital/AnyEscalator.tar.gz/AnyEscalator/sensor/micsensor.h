#ifndef MICSENSOR_H
#define MICSENSOR_H

#include <QObject>
#include "sensorbase.h"

class MicSensor : public SensorBase
{
    Q_OBJECT
public:
    explicit MicSensor(SensorBase *parent = 0);
    void initSensor(QDomElement element, ConfigureParser *cp);
    qreal RMS();
    qreal Peak();
    qreal Avg();
signals:

public slots:
};

#endif // MICSENSOR_H
