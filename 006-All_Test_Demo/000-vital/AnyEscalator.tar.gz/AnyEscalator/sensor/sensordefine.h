#ifndef SENSORDEFINE_H
#define SENSORDEFINE_H

#include <QObject>

typedef enum{
    SENSOR_INVALID = 0x00,
    THERMOCOUPLE = 0x1,
    THERMOCOUPLE1 = 0x11,
    THERMOCOUPLE2 = 0x12,
    THERMOCOUPLE3 = 0x13,
    INFRARED = 0x2,
    INFRARED1 = 0x21,
    POWERMETER = 0x3,
    RUN_SPEED = 0x4,
    PEOPLECOUNTER = 0x5,
    RUN_DIRECTION = 0x6,
    ACCELERATED = 0x7,
    ACCELERATED1 = 0x71,
    MIC = 0x8,
    BLUETOOTH = 0x9
}SENSOR_TYPE;

//<node describe="gear box" type ="accelerated" prefix="GBVib" location="GB"/>
//<node describe="additional" type ="accelerated" prefix="addVib" location="add"/>
//<node describe="gear box temperature" type ="thermocouple" prefix="GBTemp" location="1"/>
//<node describe="gear box temperature" type ="thermocouple" prefix="GBTemp" location="2"/>
//<node describe="Hand Rail Left" type ="infrared" prefix="GBTemp" location="Left"/>
//<node describe="Hand Rail Right" type ="infrared" prefix="GBTemp" location="Right"/>
//<node describe="power meter" type ="powermeter" prefix="Motor" location="Motor"/>
//<node describe="mic phone" type ="mic" prefix="Noise" location="Top"/>

SENSOR_TYPE getSensorType(QString pName);
QString getSensorString(SENSOR_TYPE pType);

#endif // SENSORDEFINE_H
