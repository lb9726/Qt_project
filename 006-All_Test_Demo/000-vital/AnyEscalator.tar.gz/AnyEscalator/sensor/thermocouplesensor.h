#ifndef THERMOCOUPLESENSOR_H
#define THERMOCOUPLESENSOR_H

#include <QObject>
#include "sensorbase.h"

class ThermocoupleSensor : public SensorBase
{
    Q_OBJECT
public:
    explicit ThermocoupleSensor(SensorBase *parent = 0);
    void initSensor(QDomElement element, ConfigureParser *cp);
signals:

public slots:
};

#endif // THERMOCOUPLESENSOR_H
