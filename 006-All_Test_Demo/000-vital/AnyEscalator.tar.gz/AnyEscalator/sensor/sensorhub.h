#ifndef SENSORHUB_H
#define SENSORHUB_H

#include <QObject>
#include "configureparser.h"
#include <QThread>
#include <QJsonObject>
#include "physic/acceleratenode.h"
#include "../physic/interprotocol.h"
#include "../physic/ledcontroller.h"

class SensorBase;
class InfraredSensor;
class AcceleratedSensor;
class MicSensor;
class PowermeterSensor;
class ThermocoupleSensor;

class Kpis;
class OnlineStatus;
class WebSocketClient;
class  QTimer;


class SensorHub : public QObject
{
    Q_OBJECT
public:
    SensorHub();
    SensorHub(ConfigureParser *cp);
    void init();

    void initSensorNodes();
    bool addComponent(SENSOR_TYPE pSensorType, QDomElement &pComElement);
    void setwsClient(WebSocketClient *wsClient);
    void clearBuffer();
signals:
    void sigSendwebsocketMsg(QByteArray msg);
    void sigSendJsonMsg(QJsonObject msg);
    void sigSendPCMsg(QJsonObject msg);
    void sigKpiLogger(QVariantMap kpi);
public slots:
    void sltInfradData(qreal leftTemp, qreal rightTemp, qreal leftAmb, qreal rightAmb);
    void sltGBVibData(qreal forward, qreal lateral, qreal vertical);
    void sltTcData(qreal gbTemp1, qreal gbTemp2, qreal gbTemp3, qreal gbTemp4);
    void sltaddVibData(qreal forward, qreal lateral, qreal vertical);
    void sltPower(qreal c1, qreal c2, qreal c3, qreal active, qreal total,qreal comsuption);
    void sltMicData(qreal noise);
    void sltKpiData(QString kpi);

    void sltDirectionData(int direction);
    void sltPeopleCountData(int peopleCount);
    void sltSpeedData(int speed); 
public slots:
    void nodeConnectStatus(quint8 node,bool flag);

public slots:
    void startWork();
    void kpisReport();
    void OnlineStatusReport();


    void sltSendJsonMsg(QJsonObject obj);
    void leftVibRemoved();
    void rightVibRemoved();
public:
    ConfigureParser *m_cp;
    QHash<SENSOR_TYPE, SensorBase*>  m_SensorList;
    SensorBase* testPtr;

    AcceleratedSensor* m_Acc_Node_GB;
    AcceleratedSensor* m_Acc_Node_add;

    InfraredSensor*  m_Infra_Node_Left;
    InfraredSensor*  m_Infra_Node_Right;

    ThermocoupleSensor* m_GBTemp_Node_1;
    ThermocoupleSensor* m_GBTemp_Node_2;

    PowermeterSensor* m_Power_Node;
    MicSensor* m_Mic_Node;

    WebSocketClient *m_wsClient;
    Kpis *m_Kpis;
    OnlineStatus *m_OnlineStatus;

    QTimer *m_kpiTimer;
    QTimer *m_onlineTimer;
    quint32 m_onlineCounter;
    bool m_online_helperModel;
    bool m_online_dtuModel;

    QThread *sensorHubThread;
    void setNodesMap(QHash<SENSOR_TYPE, QDomElement> m_sensorNodes);
    QHash<SENSOR_TYPE, QDomElement>  m_sensorNodes;

    ///PC helper
    QVariantMap  m_dataBuffer;
    QTimer *m_PCHelperStatus;

    int m_OperationDirection;
    int m_Passengercount;
    int m_MotorSpeed;
    int m_Duration;
    AccelerateNode* gbAcc;
    AccelerateNode* addAcc;
    void setAcc(AccelerateNode *gbAcc, AccelerateNode *addAcc);

    bool mSensorStatus[7]={false};//first 5 is from the mcu ,last 2 is VIB1,VIB2
    bool mAllNodeStatus;
};

#endif // SENSORHUB_H
