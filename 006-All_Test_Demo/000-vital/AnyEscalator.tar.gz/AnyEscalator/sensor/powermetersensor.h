#ifndef POWERMETERSENSOR_H
#define POWERMETERSENSOR_H

#include <QObject>
#include "sensorbase.h"

class PowermeterSensor : public SensorBase
{
    Q_OBJECT
public:
    explicit PowermeterSensor(SensorBase *parent = 0);
    void initSensor(QDomElement element, ConfigureParser *cp);
    qreal c1Avg();
    qreal c1RMS();
    qreal c1Peak();
    qreal c1Dip();

    qreal c2Avg();
    qreal c2RMS();
    qreal c2Peak();
    qreal c2Dip();

    qreal c3Avg();
    qreal c3RMS();
    qreal c3Peak();
    qreal c3Dip();

    qreal activeAvg();
    qreal activeRMS();
    qreal activePeak();
    qreal activeDip();

    void clearBuffer();



signals:

public slots:
void appendData(qreal c1, qreal c2, qreal c3, qreal active, qreal total,qreal comsuption);
public:
    qreal m_c1Avg;
    qreal m_c1RMS;
    qreal m_c1Peak;
    qreal m_c1Dip;

    qreal m_c2Avg;
    qreal m_c2RMS;
    qreal m_c2Peak;
    qreal m_c2Dip;


    qreal m_c3Avg;
    qreal m_c3RMS;
    qreal m_c3Peak;
    qreal m_c3Dip;

    qreal m_activeAvg;
    qreal m_activeRMS;
    qreal m_activePeak;
    qreal m_activeDip;

    qreal m_comsuption;

    QQueue<qreal> m_C1Queue;
    QQueue<qreal> m_C2Queue;
    QQueue<qreal> m_C3Queue;
    QQueue<qreal> m_activeQueue;

};

#endif // POWERMETERSENSOR_H
