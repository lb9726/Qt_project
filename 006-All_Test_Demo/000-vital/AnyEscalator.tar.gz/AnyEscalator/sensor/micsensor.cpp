#include "micsensor.h"
#include <QtMath>
MicSensor::MicSensor(SensorBase *parent) : SensorBase(parent)
{
    m_Peak = QREAL_MIN;
    m_Dip =  QREAL_MAX;
}

void MicSensor::initSensor(QDomElement element, ConfigureParser *cp)
{
    SensorBase::initSensor(element,cp);
}

qreal MicSensor::Avg()
{
    if(m_Queue.isEmpty())
        return 0.0;
    qreal avg = 0.0;
    for(int i=0;i < m_Queue.count();i++){
        avg += m_Queue.at(i);
    }
    return toFixedFloat(avg/m_Queue.count(),SensorBase_double_prec);
}

qreal MicSensor::RMS()
{
    if(m_Queue.isEmpty())
        return 0.0;
    qreal rms = 0.0;
    for(int i=0;i < m_Queue.count();i++){
        rms += pow(m_Queue.at(i),2);
    }
    return (-1)*toFixedFloat(qSqrt(rms/m_Queue.count()),SensorBase_double_prec);
}

qreal MicSensor::Peak()
{
    return toFixedFloat(m_Peak,SensorBase_double_prec);
}
