#include "infraredsensor.h"
#include <QtMath>
const int Infrared_double_prec = 1;
InfraredSensor::InfraredSensor(SensorBase *parent) : SensorBase(parent)
{
     m_ambAvg = 0.0;
     m_ambRMS = 0.0;
     m_ambPeak = QREAL_MIN;
     m_ambDip = QREAL_MAX;
}

void InfraredSensor::initSensor(QDomElement element, ConfigureParser *cp)
{
    SensorBase::initSensor(element,cp);
}

void InfraredSensor::appendData(qreal temp,qreal amb)
{
    SensorBase::appendData(temp);
    m_AmbQueue.enqueue(amb);
    m_ambPeak = amb > m_ambPeak ? amb : m_ambPeak;
    m_ambDip = amb > m_ambDip ? m_ambDip : amb;
}

void InfraredSensor::clearBuffer()
{
    m_ambPeak = QREAL_MIN;
    m_ambDip = QREAL_MAX;
    SensorBase::clearBuffer();
    m_AmbQueue.clear();
    m_AmbQueue.reserve(m_Freq);
}

qreal InfraredSensor::ambAvg()
{
    if(m_AmbQueue.isEmpty())
        return 0.0;
    qreal avg = 0.0;
    for(int i=0;i < m_AmbQueue.count();i++){
        avg += m_AmbQueue.at(i);
    }
    return toFixedFloat(avg/m_AmbQueue.count(),SensorBase_double_prec);
}

qreal InfraredSensor::ambRMS()
{
    if(m_AmbQueue.isEmpty())
        return 0.0;
    qreal rms = 0.0;
    for(int i=0;i < m_AmbQueue.count();i++){
        rms += pow(m_AmbQueue.at(i),2);
    }
    return toFixedFloat(qSqrt(rms/m_AmbQueue.count()),SensorBase_double_prec);
}

qreal InfraredSensor::ambPeak()
{
    return toFixedFloat(m_ambPeak,SensorBase_double_prec);
}

qreal InfraredSensor::ambDip()
{
    return toFixedFloat(m_ambDip,SensorBase_double_prec);
}


