#ifndef SENSORBASE_H
#define SENSORBASE_H

#include <QObject>
#include <QQueue>
#include <QDomElement>
#include <float.h>
#include <QtMath>
#include "../define.h"
class ConfigureParser;

const int SensorBase_double_prec = 2;

class SensorBase : public QObject
{
    Q_OBJECT
public:
    explicit SensorBase(QObject *parent = 0);

public:
    virtual void initSensor(QDomElement element, ConfigureParser *cp);
    virtual qreal Avg();
    virtual qreal RMS();
    virtual qreal Peak();
    virtual qreal Dip();
    virtual qreal callback(qreal value);
    virtual void clearBuffer();
signals:

public slots:
    void appendData(qreal data);
    void setFreq(quint16 freq);
public:
    bool m_AvgEnabled;
    bool m_RMSEnabled;
    bool m_PeakEnabled;
    bool m_DipEnabled;

    qreal m_Avg;
    qreal m_RMS;
    qreal m_Peak;
    qreal m_Dip;

    quint16 m_Freq;
    QQueue<qreal> m_Queue;

    QDomElement m_element;
    ConfigureParser* m_cp;

    int m_freq;
    QString  m_prefix;
    QString m_location;
};

#endif // SENSORBASE_H
