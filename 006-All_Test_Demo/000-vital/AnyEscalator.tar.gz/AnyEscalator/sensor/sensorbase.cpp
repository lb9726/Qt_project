#include "sensorbase.h"
#include <QtMath>
#include "configureparser.h"

SensorBase::SensorBase(QObject *parent) : QObject(parent)
{
    m_RMS = 0.0f ;
    m_Peak = QREAL_MIN;
    m_Dip =  QREAL_MAX;
    m_Avg = 0.0f;
    m_PeakEnabled = m_DipEnabled = true;
    m_Queue.clear();
    m_Freq = 0;
}

void SensorBase::initSensor(QDomElement element,ConfigureParser* cp)
{
    m_element = element;
    m_cp = cp;
    //    QDomElement  tmpDomElement = m_element.firstChildElement("frequency");
    //    if(!tmpDomElement.isNull()){
    //        QString tmp = tmpDomElement.text();
    //        bool flag = false;
    //        m_freq = tmp.toInt(&flag);
    //        if(!flag)
    //            m_freq = 90;
    //    }else{
    //        m_freq = 90;
    //    }

    m_prefix = m_element.attribute("prefix");
    m_location = m_element.attribute("location");
    //    IDE_TRACE_INT(m_freq);
    //    IDE_TRACE_STR(m_prefix);
    //    IDE_TRACE_STR(m_location);
}

void SensorBase::appendData(qreal data)
{
    m_Queue.enqueue(data);
    ///IDE_TRACE_DOUBLE(data);
    m_Peak = data > m_Peak ? data : m_Peak;
//    if(data > m_Peak){
//        IDE_TRACE_DOUBLE(data);
//        m_Peak = data;
//    }else{
//        IDE_TRACE_DOUBLE(m_Peak);
//    }
    ////IDE_TRACE_DOUBLE(m_Peak);
    m_Dip = data > m_Dip ? m_Dip : data;
}

void SensorBase::setFreq(quint16 freq)
{
    m_Freq = freq;
}

void SensorBase::clearBuffer()
{
    m_Peak = QREAL_MIN;
    m_Dip = QREAL_MAX;
    m_Queue.clear();
    m_Queue.reserve(m_Freq);
}

qreal SensorBase::Avg()
{
    if(m_Queue.isEmpty())
        return 0.0;
    qreal avg = 0.0;
    for(int i=0;i < m_Queue.count();i++){
        avg += m_Queue.at(i);
    }
    return toFixedFloat(avg/m_Queue.count(),SensorBase_double_prec);
}

qreal SensorBase::RMS()
{
    if(m_Queue.isEmpty())
        return 0.0;
    qreal rms = 0.0;
    for(int i=0;i < m_Queue.count();i++){
        qreal point = m_Queue.at(i);
        rms += pow(point,2);
    }
    return toFixedFloat(qSqrt(rms/m_Queue.count()),SensorBase_double_prec);
}

qreal SensorBase::Peak()
{
    return toFixedFloat(m_Peak,SensorBase_double_prec);
}

qreal SensorBase::Dip()
{
    return toFixedFloat(m_Dip,SensorBase_double_prec);
}

qreal SensorBase::callback(qreal value)
{
    return toFixedFloat(value,SensorBase_double_prec);
}


