#include "sensordefine.h"

SENSOR_TYPE getSensorType(QString pName){
    if(pName.isEmpty())
        return SENSOR_INVALID;
    else if(pName.compare(QString("accelerated"), Qt::CaseInsensitive) == 0)
        return ACCELERATED;
    else if(pName.compare(QString("accelerated1"), Qt::CaseInsensitive) == 0)
        return ACCELERATED1;
    else if(pName.compare(QString("thermocouple"), Qt::CaseInsensitive) == 0)
        return THERMOCOUPLE;
    else if(pName.compare(QString("thermocouple1"), Qt::CaseInsensitive) == 0)
        return THERMOCOUPLE1;
    else if(pName.compare(QString("thermocouple2"), Qt::CaseInsensitive) == 0)
        return THERMOCOUPLE2;
    else if(pName.compare(QString("thermocouple3"), Qt::CaseInsensitive) == 0)
        return THERMOCOUPLE3;
    else if(pName.compare(QString("infrared"), Qt::CaseInsensitive) == 0)
        return INFRARED;
    else if(pName.compare(QString("infrared1"), Qt::CaseInsensitive) == 0)
        return INFRARED1;
    else if(pName.compare(QString("powermeter"), Qt::CaseInsensitive) == 0)
        return POWERMETER;
    else if(pName.compare(QString("peoplecounter"), Qt::CaseInsensitive) == 0)
        return PEOPLECOUNTER;
    else if(pName.compare(QString("mic"), Qt::CaseInsensitive) == 0)
        return MIC;
    else if(pName.compare(QString("bluetooth"), Qt::CaseInsensitive) == 0)
        return BLUETOOTH;
    return SENSOR_INVALID;
}

QString getSensorString(SENSOR_TYPE pType){
    if(ACCELERATED == pType)
        return QString("accelerated");
    else if(ACCELERATED1 == pType)
        return QString("accelerated1");
    else if(THERMOCOUPLE == pType)
        return QString("thermocouple");
    else if(THERMOCOUPLE1 == pType)
        return QString("thermocouple1");
    else if(THERMOCOUPLE2 == pType)
        return QString("thermocouple2");
    else if(THERMOCOUPLE2 == pType)
        return QString("thermocouple3");
    else if(INFRARED == pType)
        return QString("infrared");
    else if(INFRARED1 == pType)
        return QString("infrared1");
    else if(POWERMETER == pType)
        return QString("powermeter");
    else if(PEOPLECOUNTER == pType)
        return QString("peoplecounter");
    else if(MIC == pType)
        return QString("mic");
    else if(BLUETOOTH == pType)
        return QString("bluetooth");
    return QString();
}
