#include "sensorhub.h"

#include "sensorbase.h"
#include "infraredsensor.h"
#include "acceleratedsensor.h"
#include "micsensor.h"
#include "powermetersensor.h"
#include "thermocouplesensor.h"
#include "../logic/logicheader.h"
#include "../logic/kpis.h"
#include "../logic/onlinestatus.h"

#include <QTimer>

SensorHub::SensorHub()
{
    m_Kpis = NULL;
    m_OnlineStatus = NULL;
    m_kpiTimer = NULL;
    m_onlineTimer = NULL;
    m_online_helperModel = false;
    m_online_dtuModel = false;

    m_Acc_Node_GB = NULL;
    m_Acc_Node_add = NULL;

    m_Infra_Node_Left = NULL;
    m_Infra_Node_Right = NULL;

    m_GBTemp_Node_1 = NULL;
    m_GBTemp_Node_2 = NULL;

    m_Power_Node = NULL;
    m_Mic_Node = NULL;
    m_kpiTimer = new QTimer(this);
    connect(m_kpiTimer,&QTimer::timeout,this,&SensorHub::kpisReport);
    //    m_kpiTimer->setInterval(10000);
    //    m_kpiTimer->start();
    m_PCHelperStatus = NULL;

    m_OperationDirection = 0;
    m_Passengercount = 0;
    m_MotorSpeed = 0;

    gbAcc = NULL;
    addAcc = NULL;
}

SensorHub::SensorHub(ConfigureParser *cp)
{
    m_cp = cp;
    m_Kpis = NULL;
    m_OnlineStatus = NULL;
    m_kpiTimer = NULL;
    m_onlineTimer = NULL;
    m_online_helperModel = false;
    m_online_dtuModel = false;
    m_Acc_Node_GB = NULL;
    m_Acc_Node_add = NULL;

    m_Infra_Node_Left = NULL;
    m_Infra_Node_Right = NULL;

    m_GBTemp_Node_1 = NULL;
    m_GBTemp_Node_2 = NULL;

    m_Power_Node = NULL;
    m_Mic_Node = NULL;
}
void SensorHub::setAcc(AccelerateNode* gbAcc,AccelerateNode* addAcc){
    this->addAcc = addAcc;
    this->gbAcc = gbAcc;
}

void SensorHub::init(){

    sensorHubThread = new QThread();
    initSensorNodes();
    m_Kpis = new Kpis(this);
    m_OnlineStatus = new OnlineStatus(this);

    connect(m_Kpis,SIGNAL(sigSendJsonMsg(QJsonObject)),this,SIGNAL(sigSendJsonMsg(QJsonObject)));
    connect(m_OnlineStatus,SIGNAL(sigSendJsonMsg(QJsonObject)),this,SIGNAL(sigSendJsonMsg(QJsonObject)));
}

void SensorHub::setNodesMap(QHash<SENSOR_TYPE, QDomElement> sensorNodes){
    m_sensorNodes = sensorNodes;
}

void SensorHub::sltSendJsonMsg(QJsonObject obj){
    IDE_TRACE();
    emit sigSendJsonMsg(obj);
}

void SensorHub::startWork(){
    this->moveToThread(sensorHubThread);
    sensorHubThread->start();
}

void SensorHub::initSensorNodes(){
    QList<SENSOR_TYPE> tmpSensorList = m_sensorNodes.keys();
    int count = tmpSensorList.count();
    for(int i=0;i<count;i++)
    {
        SENSOR_TYPE tmpType = tmpSensorList.at(i);

        QDomElement tmpElement = m_sensorNodes.value(tmpType);
        if(tmpElement.isNull())
            continue;
        addComponent(tmpType, tmpElement);
    }
}

bool SensorHub::addComponent(SENSOR_TYPE pSensorType, QDomElement &pComElement)
{
    if(pSensorType < SENSOR_INVALID)
        return false;

    if(m_SensorList.contains(pSensorType))
        return true;
    if(pComElement.isNull())
    {
        IDE_TRACE_STR(getSensorString(pSensorType));
        return false;
    }
    /// IDE_TRACE_STR(getSensorString(pSensorType));
    ////QString location = pComElement.attribute("location");

    ///IDE_TRACE_STR(location);
    SensorBase *tmpPtr = 0;

    switch(pSensorType)
    {
    case INFRARED:
        m_Infra_Node_Left = new InfraredSensor();
        tmpPtr = m_Infra_Node_Left;
        //        if(!QString::compare("Left", location, Qt::CaseInsensitive)){
        //            m_Infra_Node_Left = new InfraredSensor();
        //            tmpPtr = m_Infra_Node_Left;
        //        }else if(!QString::compare("Right", location, Qt::CaseInsensitive)){
        //            m_Infra_Node_Right = new InfraredSensor();
        //            tmpPtr = m_Infra_Node_Right;
        //        }
        break;
    case INFRARED1:
        m_Infra_Node_Right = new InfraredSensor();
        tmpPtr = m_Infra_Node_Right;
        break;
    case ACCELERATED:
        m_Acc_Node_GB = new AcceleratedSensor();
        tmpPtr = m_Acc_Node_GB;
        //        if(!QString::compare("GB", location, Qt::CaseInsensitive)){
        //            m_Acc_Node_GB = new AcceleratedSensor();
        //            tmpPtr = m_Acc_Node_GB;
        //            IDE_TRACE();
        //        }else if(!QString::compare("add", location, Qt::CaseInsensitive)){
        //            m_Acc_Node_add = new AcceleratedSensor();
        //            tmpPtr = m_Acc_Node_add;
        //            IDE_TRACE();
        //        }
        break;
    case ACCELERATED1:
        m_Acc_Node_add = new AcceleratedSensor();
        tmpPtr = m_Acc_Node_add;
        break;
    case THERMOCOUPLE:
        m_GBTemp_Node_1 = new ThermocoupleSensor();
        tmpPtr = m_GBTemp_Node_1;
        //        if(!QString::compare("1", location, Qt::CaseInsensitive)){
        //            m_GBTemp_Node_1 = new ThermocoupleSensor();
        //            tmpPtr = m_GBTemp_Node_1;
        //        }else if(!QString::compare("2", location, Qt::CaseInsensitive)){
        //            m_GBTemp_Node_2 = new ThermocoupleSensor();
        //            tmpPtr = m_GBTemp_Node_2;
        //        }
        break;
    case THERMOCOUPLE1:
        m_GBTemp_Node_2 = new ThermocoupleSensor();
        tmpPtr = m_GBTemp_Node_2;
        break;
    case THERMOCOUPLE2:
        break;
    case THERMOCOUPLE3:
        break;
    case POWERMETER:
        m_Power_Node = new PowermeterSensor();
        tmpPtr = m_Power_Node;
        break;
    case MIC:
        m_Mic_Node = new MicSensor();
        tmpPtr = m_Mic_Node;
        break;
    default:
        return false;
    }
    if(!tmpPtr){
        tmpPtr->initSensor(pComElement,m_cp);
        m_SensorList.insert(pSensorType, tmpPtr);
    }
    return true;
}

void SensorHub::setwsClient(WebSocketClient *wsClient)
{
    m_wsClient = wsClient;
}

//"GBVibForwardAvg": 0.211,
//"GBVibLateralAvg": 0.211,
//"GBVibVerticalAvg": 0.211,
//"addVibForwardAvg": 0.211,
//"addVibLateralAvg": 0.211,
//"addVibVerticalAvg": 0.211,
//"StepVibForwardRMS":0.112,
//"StepVibLateralRMS":0.112,
//"StepVibVerticalRMS":0.112,
//"StepVibForwardPeak":0.112,
//"StepVibLateralPeak":0.211,
//"StepVibVerticalPeak":0.211,

void SensorHub::OnlineStatusReport(){
    m_OnlineStatus->m_statusMap["GBVibForwardRMS"] = toFixedFloat(m_Acc_Node_GB->RMS(),3);
    m_OnlineStatus->m_statusMap["GBVibLateralRMS"] = toFixedFloat(m_Acc_Node_GB->lateralRMS(),3);
    m_OnlineStatus->m_statusMap["GBVibVerticalRMS"] = toFixedFloat(m_Acc_Node_GB->verticalRMS(),3);

    m_OnlineStatus->m_statusMap["addVibForwardRMS"] = toFixedFloat(m_Acc_Node_add->RMS(),3);
    m_OnlineStatus->m_statusMap["addVibLateralRMS"] = toFixedFloat(m_Acc_Node_add->lateralRMS(),3);
    m_OnlineStatus->m_statusMap["addVibVerticalRMS"] = toFixedFloat(m_Acc_Node_add->verticalRMS(),3);

    m_OnlineStatus->m_statusMap["GBTemp1Avg"] = toFixedFloat(m_GBTemp_Node_1->Avg(),1);
    m_OnlineStatus->m_statusMap["GBTemp2Avg"] = toFixedFloat(m_GBTemp_Node_2->Avg(),1);

    m_OnlineStatus->m_statusMap["HandrailTempLeftInfraredAvg"] = toFixedFloat(m_Infra_Node_Left->Avg(),1);
    m_OnlineStatus->m_statusMap["HandrailTempRightInfraredAvg"] = toFixedFloat(m_Infra_Node_Right->Avg(),1);
    m_OnlineStatus->m_statusMap["HandrailAmbTempLeftAvg"] = toFixedFloat( m_Infra_Node_Left->ambAvg(),1);
    m_OnlineStatus->m_statusMap["HandrailAmbTempRightAvg"] = toFixedFloat(m_Infra_Node_Right->Avg(),1);

    m_OnlineStatus->m_statusMap["UpperPitNoiseRMS"] = toFixedFloat(m_Mic_Node->RMS(),1);

    m_OnlineStatus->m_statusMap["MotorCurrent1Avg"] = toFixedFloat(m_Power_Node->c1Avg(),1);
    m_OnlineStatus->m_statusMap["MotorCurrent2Avg"] = toFixedFloat(m_Power_Node->c2Avg(),1);
    m_OnlineStatus->m_statusMap["MotorCurrent3Avg"] = toFixedFloat(m_Power_Node->c3Avg(),1);
    m_OnlineStatus->m_statusMap["MotorPowerActiveAvg"] = toFixedFloat(m_Power_Node->activeAvg(),1);
    m_OnlineStatus->m_statusMap["MotorPowerTotalAvg"] = toFixedFloat(m_Power_Node->Avg(),1);

    m_OnlineStatus->triggerStatusReport();
}
//IR_Left	   = 0x00,
//IR_Right     = 0x01,
//TEMP_Left    = 0x02,
//TEMP_Right   = 0x03,
//RS485        = 0x04,
//VIBLEFT      = 0x05,
//VIBRIGHT     = 0x06,

void SensorHub::kpisReport(){
    m_Kpis->m_kpisMap.clear();
    if(mSensorStatus[5])
    {
        m_Kpis->m_kpisMap["GBVibForwardRMS"] = m_Acc_Node_GB->RMS();
        m_Kpis->m_kpisMap["GBVibLateralRMS"] = m_Acc_Node_GB->lateralRMS();
        m_Kpis->m_kpisMap["GBVibVerticalRMS"] = m_Acc_Node_GB->verticalRMS();

        m_Kpis->m_kpisMap["GBVibForwardPeak"] = m_Acc_Node_GB->Peak();
        m_Kpis->m_kpisMap["GBVibLateralPeak"] = m_Acc_Node_GB->lateralPeak();
        m_Kpis->m_kpisMap["GBVibVerticalPeak"] = m_Acc_Node_GB->verticalPeak();
    }

    if(mSensorStatus[6])
    {
        m_Kpis->m_kpisMap["addVibForwardRMS"] = m_Acc_Node_add->RMS();
        m_Kpis->m_kpisMap["addVibLateralRMS"] = m_Acc_Node_add->lateralRMS();
        m_Kpis->m_kpisMap["addVibVerticalRMS"] = m_Acc_Node_add->verticalRMS();

        m_Kpis->m_kpisMap["addVibForwardPeak"] = toFixedFloat(m_Acc_Node_add->Peak());
        m_Kpis->m_kpisMap["addVibLateralPeak"] = toFixedFloat(m_Acc_Node_add->lateralPeak());
        m_Kpis->m_kpisMap["addVibVerticalPeak"] = toFixedFloat(m_Acc_Node_add->verticalPeak());
    }

    if(mSensorStatus[TEMP_Left])
    {
        //IDE_TRACE();
        m_Kpis->m_kpisMap["GBTempAvg"] = toFixedFloat(m_GBTemp_Node_1->Avg(),1);
        m_Kpis->m_kpisMap["GBTemp1Avg"] = toFixedFloat(m_GBTemp_Node_1->Avg(),1);
    }else{
        //IDE_TRACE();
    }

    if(mSensorStatus[TEMP_Right])
    {
        //IDE_TRACE();
        m_Kpis->m_kpisMap["GBTemp2Avg"] = toFixedFloat(m_GBTemp_Node_2->Avg(),1);
    }else{
        //IDE_TRACE();
    }

    if(mSensorStatus[IR_Left])
    {
        //IDE_TRACE();
        m_Kpis->m_kpisMap["HandrailTempLeftInfraredAvg"] = toFixedFloat(m_Infra_Node_Left->Avg(),1);
        m_Kpis->m_kpisMap["HandrailAmbTempLeftAvg"] = toFixedFloat(m_Infra_Node_Left->ambAvg(),1);
    }else{
        //IDE_TRACE();
    }

    if(mSensorStatus[IR_Right])
    {
        //IDE_TRACE();
        m_Kpis->m_kpisMap["HandrailTempRightInfraredAvg"] = toFixedFloat(m_Infra_Node_Right->Avg(),1);
        m_Kpis->m_kpisMap["HandrailAmbTempRightAvg"] = toFixedFloat(m_Infra_Node_Right->ambAvg(),1);
    }else{
        //IDE_TRACE();
    }
    //if(mSensorStatus[RS485])
    //{
    m_Kpis->m_kpisMap["UpperPitNoiseRMS"] = toFixedFloat(m_Mic_Node->RMS(),1);
    m_Kpis->m_kpisMap["UpperPitNoiseAvg"] = toFixedFloat(m_Mic_Node->Avg(),1);
    m_Kpis->m_kpisMap["UpperPitNoisePeak"] = toFixedFloat(m_Mic_Node->Peak(),1);
    //}

    if(mSensorStatus[RS485])
    {
        m_Kpis->m_kpisMap["MotorCurrent1Avg"] = toFixedFloat(m_Power_Node->c1Avg(),1);
        m_Kpis->m_kpisMap["MotorCurrent2Avg"] = toFixedFloat(m_Power_Node->c2Avg(),1);
        m_Kpis->m_kpisMap["MotorCurrent3Avg"] = toFixedFloat(m_Power_Node->c3Avg(),1);
        m_Kpis->m_kpisMap["MotorPowerActiveAvg"] = toFixedFloat(m_Power_Node->activeAvg(),1);
        m_Kpis->m_kpisMap["MotorPowerTotalAvg"] = toFixedFloat(m_Power_Node->Avg(),1);

        m_Kpis->m_kpisMap["MotorPower1Avg"] = toFixedFloat( m_Power_Node->activeAvg(),1);
        m_Kpis->m_kpisMap["MotorPower2Avg"] = toFixedFloat(m_Power_Node->Avg(),1);

        m_Kpis->m_kpisMap["MotorCurrent1Peak"] = toFixedFloat(m_Power_Node->c1Peak(),1);
        m_Kpis->m_kpisMap["MotorCurrent2Peak"] = toFixedFloat(m_Power_Node->c2Peak(),1);
        m_Kpis->m_kpisMap["MotorCurrent3Peak"] = toFixedFloat(m_Power_Node->c3Peak(),1);
        m_Kpis->m_kpisMap["MotorPowerActivePeak"] = toFixedFloat(m_Power_Node->activePeak(),1);
        m_Kpis->m_kpisMap["MotorPowerTotalPeak"] =toFixedFloat((int) m_Power_Node->Peak(),1);
        m_Kpis->m_kpisMap["PowerComsuption"] = toFixedFloat(m_Power_Node->m_comsuption,1);
    }


    m_Kpis->m_kpisMap["MotorSpeedLeftAvg"] = m_MotorSpeed;
    m_Kpis->m_kpisMap["MotorSpeedRightAvg"] = m_MotorSpeed;
    m_Kpis->m_kpisMap["Passengercount"] = m_Passengercount;
    m_Kpis->m_kpisMap["OperationDirection"] = m_OperationDirection;
    m_Kpis->m_kpisMap["Duration"] = m_Duration;

    m_Kpis->triggerKipsReport(getTimeStamp());
    emit  sigKpiLogger(m_Kpis->m_kpisMap);
    clearBuffer();
    m_Kpis->m_kpisMap.clear();
}

void SensorHub::leftVibRemoved()
{
    mSensorStatus[5] = false;
}

void SensorHub::rightVibRemoved()
{
    mSensorStatus[6]  = false;
}

void SensorHub::nodeConnectStatus(quint8 node,bool flag){
    ///IDE_TRACE();
    //qDebug()<<"nodeConnectStatus SensorNode:"<<node<<",flag"<<flag;
    if(node < 5 && node >= 0){
        mSensorStatus[node] = flag;
    }

    if(AllNodes == node){
        mAllNodeStatus = node;
    }

    mSensorStatus[5] = gbAcc->isAccNodeConnected();
    mSensorStatus[6]  = addAcc->isAccNodeConnected();
    ///IDE_TRACE();
//    qDebug()<<"mSensorStatus 5 6"<<mSensorStatus[5]<<mSensorStatus[6];
//    if(mAllNodeStatus & mSensorStatus[5] && mSensorStatus[6]){
//        //IDE_TRACE();
//        LedController::deviceModeLight(true);
//    }else{
//        //IDE_TRACE();
//        LedController::deviceModeLight(false);
//    }
}

void SensorHub::clearBuffer(){
    m_Acc_Node_GB->clearBuffer();
    m_Acc_Node_add->clearBuffer();

    m_Infra_Node_Left->clearBuffer();
    m_Infra_Node_Right->clearBuffer();

    m_GBTemp_Node_1->clearBuffer();
    m_GBTemp_Node_2->clearBuffer();

    m_Power_Node->clearBuffer();

    m_Mic_Node->clearBuffer();
}

void SensorHub::sltDirectionData(int direction){
    m_OperationDirection = direction;
}

void SensorHub::sltPeopleCountData(int peopleCount){
    //if(peopleCount > 0)
    m_Passengercount = peopleCount;
    ///IDE_TRACE_INT(m_Passengercount);
}

void SensorHub::sltSpeedData(int speed){
    m_MotorSpeed = speed;
}

void SensorHub::sltInfradData(qreal leftTemp,qreal rightTemp,qreal leftAmb,qreal rightAmb){
    m_Infra_Node_Left->appendData(leftTemp,leftAmb);
    m_Infra_Node_Right->appendData(rightTemp,rightAmb);
}

void SensorHub::sltGBVibData(qreal forward,qreal lateral,qreal vertical){
    ///qDebug()<<"GB:"<<(forward/1000.0)<<" , "<<(lateral/1000.0)<<" , "<<(vertical/1000.0);
    m_Acc_Node_GB->appendData(forward,lateral,vertical);
}

void SensorHub::sltaddVibData(qreal forward,qreal lateral,qreal vertical){
    //qDebug()<<"ADD:"<<(forward/1000.0)<<" , "<<(lateral/1000.0)<<" , "<<(vertical/1000.0);
    m_Acc_Node_add->appendData(forward,lateral,vertical);
}

void SensorHub::sltTcData(qreal gbTemp1,qreal gbTemp2,qreal gbTemp3,qreal gbTemp4){
    Q_UNUSED(gbTemp3);
    Q_UNUSED(gbTemp4);
    m_GBTemp_Node_1->appendData(gbTemp1);
    m_GBTemp_Node_2->appendData(gbTemp2);
}

void SensorHub::sltPower(qreal c1,qreal c2,qreal c3,qreal active,qreal total,qreal comsuption){
    m_Power_Node->appendData(c1,c2,c3,active,total,comsuption);
}

void SensorHub::sltMicData(qreal noise){
    //IDE_TRACE_DOUBLE(noise);
    m_Mic_Node->appendData(noise);
    ////IDE_TRACE_DOUBLE(m_Mic_Node->m_Peak);
}

void SensorHub::sltKpiData(QString kpi){
    Q_UNUSED(kpi);
}

//"GBVibForwardRMS": 0.211,
//"GBVibLateralRMS": 0.211,
//"GBVibVerticalRMS": 0.211,
//"GBVibForwardPeak": 0.211,
//"GBVibLateralPeak": 0.211,
//"GBVibVerticalPeak": 0.211,
//"addVibForwardRMS": 0.211,
//"addVibLateralRMS": 0.211,
//"addVibVerticalRMS": 0.211,
//"addVibForwardPeak": 0.211,
//"addVibLateralPeak": 0.211,
//"addVibVerticalPeak": 0.211,
//"GBVibForwardAvg": 0.211,
//"GBVibLateralAvg": 0.211,
//"GBVibVerticalAvg": 0.211,
//"addVibForwardAvg": 0.211,
//"addVibLateralAvg": 0.211,
//"addVibVerticalAvg": 0.211,
//"StepVibForwardRMS":0.112,
//"StepVibLateralRMS":0.112,
//"StepVibVerticalRMS":0.112,
//"StepVibForwardPeak":0.112,
//"StepVibLateralPeak":0.211,
//"StepVibVerticalPeak":0.211,
//"StepNoiseRMS":-40.111,
//"StepNoisePeak":-25.121,
//"GBTempAvg": 35.1,
//"GBTemp1Avg": 35.1,
//"GBTemp2Avg":35.1,
//"HandrailTempLeftInfraredAvg": 25.2,
//"HandrailTempRightInfraredAvg": 25.2,
//"HandrailAmbTempLeftAvg":25.2,
//"HandrailAmbTempRightAvg":25.2,
//"UpperPitNoiseRMS": -25.2,
//"UpperPitNoiseAvg": -25.1,
//"UpperPitNoisePeak": -25.3,
//"MotorCurrent1Avg":35.2,
//"MotorCurrent2Avg":35.2,
//"MotorCurrent3Avg":35.2,
//"MotorPowerActiveAvg":35.2,
//"MotorPowerTotalAvg":35.0,
//"MotorCurrent1Peak":35.2,
//"MotorCurrent2Peak":35.2,
//"MotorCurrent3Peak":35.2,
//"MotorPowerActivePeak":35.2,
//"MotorPowerTotalPeak":35.2,
//"PowerFactor":0.8,
//"PowerComsuption":120,
//"StepBandSpeedLeftAvg": 0.5,
//"HandrailSpeedLeftAvg": 0.5,
//"StepBandSpeedRightAvg": 0.5,
//"HandrailSpeedRightAvg": 0.5,
//"MotorSpeedLeftAvg": 0.5,
//"MotorSpeedRightAvg": 0.5,
//"AccelerationTime": 3,
//"DecelerationTime": 3,
//"Passengercount":50,
//"OperationDirection":1,
//"BrakingDistance": 0.5,
//"OperationStatus": 0,
//"modeset": 1,
//"alarmID":12,
//"duration": 60
