#ifndef INFRAREDSENSOR_H
#define INFRAREDSENSOR_H

#include <QObject>
#include "sensorbase.h"

class InfraredSensor : public SensorBase
{
    Q_OBJECT
public:
    explicit InfraredSensor(SensorBase *parent = 0);
    void initSensor(QDomElement element, ConfigureParser *cp);
    qreal ambAvg();
    qreal ambRMS();
    qreal ambPeak();
    qreal ambDip();
    void clearBuffer();
    void appendData(qreal temp, qreal amb);
signals:

public slots:

public:
    qreal m_ambAvg;
    qreal m_ambRMS;
    qreal m_ambPeak;
    qreal m_ambDip;
    QQueue<qreal> m_AmbQueue;


};

#endif // INFRAREDSENSOR_H
