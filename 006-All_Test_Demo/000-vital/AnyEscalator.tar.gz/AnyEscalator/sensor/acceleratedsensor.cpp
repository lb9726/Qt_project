#include "acceleratedsensor.h"
#include <float.h>
const int Acc_double_prec = 3;

AcceleratedSensor::AcceleratedSensor(SensorBase *parent) : SensorBase(parent)
{
    m_forwardAvg = 0;
    m_forwardRMS = 0;
    m_forwardPeak = 0;//QREAL_MIN;
    m_forwardDip = 0;//QREAL_MAX;

    m_lateralAvg = 0;
    m_lateralRMS = 0;
    m_lateralPeak = 0;//QREAL_MIN;
    m_lateralDip = 0;//QREAL_MAX;

    m_verticalAvg = 0;
    m_verticalRMS = 0;
    m_verticalPeak = 0;//QREAL_MIN;
    m_verticalDip = 0;//QREAL_MAX;
    m_Queue.clear();
    m_verticalQueue.clear();
    m_lateralQueue.clear();
    m_Freq = 12000; ///ODR 200Hz,12000 data per min
}

void AcceleratedSensor::initSensor(QDomElement element, ConfigureParser *cp)
{
    SensorBase::initSensor(element,cp);
}

void AcceleratedSensor::appendData(qreal forward, qreal lateral, qreal vertical)
{
    m_Queue.enqueue(forward);
    m_lateralQueue.enqueue(lateral);
    m_verticalQueue.enqueue(vertical);

    qreal absForward = abs(forward);
    qreal absLateral = abs(lateral);
    qreal absVertical = abs(vertical);
    ///IDE_TRACE_DOUBLE(m_forwardPeak);
   /// IDE_TRACE_DOUBLE(absForward);
    m_forwardPeak = absForward > m_forwardPeak ? absForward : m_forwardPeak;
    ///IDE_TRACE_DOUBLE(m_forwardPeak);
    ///m_forwardDip = absForward > m_forwardDip ?  m_forwardDip : absForward;

    m_lateralPeak = absLateral > m_lateralPeak ? absLateral : m_lateralPeak;
    ////m_lateralDip = absLateral > m_lateralDip ? m_lateralDip : absLateral;

    m_verticalPeak = absVertical > m_verticalPeak ? absVertical : m_verticalPeak;
    ////m_verticalDip = absVertical > m_verticalDip ? m_verticalDip : absVertical;
}

qreal AcceleratedSensor::Avg()
{
    if(m_Queue.isEmpty())
        return 0.0;
    qreal avg = 0.0;
    for(int i=0;i < m_Queue.count();i++){
        avg += m_Queue.at(i);
    }
    return toFixedFloat((avg/(1000.0*m_Queue.count())),Acc_double_prec);
}

qreal AcceleratedSensor::RMS()
{
    if(m_Queue.isEmpty())
        return 0.0;
    qreal rms = 0.0;
    for(int i=0;i < m_Queue.count();i++){
        rms += pow(m_Queue.at(i),2);
    }
    ////IDE_TRACE_INT(m_Queue.count());
    return toFixedFloat(qSqrt(rms/m_Queue.count())/1000.0,Acc_double_prec);
}

qreal AcceleratedSensor::Peak()
{
    return toFixedFloat(m_forwardPeak/1000.0,Acc_double_prec);
}

qreal AcceleratedSensor::Dip()
{
    return toFixedFloat(m_forwardDip/1000.0,Acc_double_prec);
}

void AcceleratedSensor::clearBuffer()
{
    ///IDE_TRACE();
    m_forwardPeak = 0;//QREAL_MIN;
    m_forwardDip = 0;//QREAL_MAX;
    m_lateralPeak = 0;//QREAL_MIN;
    m_lateralDip = 0;//QREAL_MAX;
    m_verticalPeak = 0;//QREAL_MIN;
    m_verticalDip = 0;//QREAL_MAX;

    SensorBase::clearBuffer();
    m_lateralQueue.clear();
    m_lateralQueue.reserve(m_Freq);

    m_verticalQueue.clear();
    m_verticalQueue.reserve(m_Freq);
}

qreal AcceleratedSensor::lateralAvg()
{
    if(m_lateralQueue.isEmpty())
        return 0.0;
    qreal avg = 0.0;
    for(int i=0;i < m_lateralQueue.count();i++){
        avg += m_lateralQueue.at(i);
    }
    return toFixedFloat((avg/(1000.0*m_lateralQueue.count())),Acc_double_prec);
}

qreal AcceleratedSensor::lateralRMS()
{
    if(m_lateralQueue.isEmpty())
        return 0.0;
    qreal rms = 0.0;
    for(int i=0;i < m_lateralQueue.count();i++){
        rms += pow(m_lateralQueue.at(i),2);
    }
    return toFixedFloat(qSqrt(rms/m_lateralQueue.count())/1000.0,Acc_double_prec);
}

qreal AcceleratedSensor::lateralPeak()
{
    return toFixedFloat(m_lateralPeak/1000.0,Acc_double_prec);
}

qreal AcceleratedSensor::lateralDip()
{
    return toFixedFloat(m_lateralDip/1000.0,Acc_double_prec);
}

qreal AcceleratedSensor::verticalAvg()
{
    if(m_verticalQueue.isEmpty())
        return 0.0;
    qreal avg = 0.0;
    for(int i=0;i < m_verticalQueue.count();i++){
        avg += m_verticalQueue.at(i);
    }
    return toFixedFloat(avg/(1000.0*m_verticalQueue.count()),Acc_double_prec);
}

qreal AcceleratedSensor::verticalRMS()
{
    if(m_verticalQueue.isEmpty())
        return 0.0;
    qreal rms = 0.0;
    for(int i=0;i < m_verticalQueue.count();i++){
        rms += pow(m_verticalQueue.at(i),2);
    }
    return toFixedFloat(qSqrt(rms/m_verticalQueue.count())/1000.0,Acc_double_prec);
}

qreal AcceleratedSensor::verticalPeak()
{
    return  toFixedFloat(m_verticalPeak/1000.0,Acc_double_prec);
}

qreal AcceleratedSensor::verticalDip()
{
    return toFixedFloat(m_verticalDip/1000.0,Acc_double_prec);
}
