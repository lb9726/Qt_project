#include "configureparser.h"

const QString ConfigureParser::UiSuffix = ".xml";

ConfigureParser::ConfigureParser(QString fileName):XmlParse(fileName)
{
    int tmpProNum, tmpSuffixNum;
    tmpProNum = m_FileName.length();
    tmpSuffixNum = UiSuffix.length();
    if(tmpProNum <= tmpSuffixNum)
    {
        IDE_TRACE_INT(tmpProNum);
        return;
    }
    QString suffix = m_FileName.mid(tmpProNum-tmpSuffixNum, tmpSuffixNum);
    if(suffix != UiSuffix){
        m_FileName = QString("%1%2").arg(m_FileName).arg(UiSuffix);
    }
    // IDE_TRACE();
}

ConfigureParser::ConfigureParser(QSettings setting)
{
  ///setting  = m_settings->value("peopleCount",0).toInt();
}

bool ConfigureParser::openConfigure()
{
    bool flag = openXml();
    if(flag == false)
    {
        m_Valid = false;
        return false;
    }
    m_Valid = true;
    initConfigure();
    return true;
}

bool ConfigureParser::closeConfigure()
{
    saveConfigure();
    return true;
}

bool ConfigureParser::saveConfigure()
{
    return this->saveXml();
}

void ConfigureParser::initConfigure()
{
    ///m_sensorNodes
    if(!m_Valid)
    {
        IDE_TRACE();
        return;
    }
    bool flag = getItemElement("/nodes");
    if(flag)
    {
        QDomElement tmpElement;
        QDomNodeList SubuiNodeList = itemElement.childNodes();
        for(int i=0;i<SubuiNodeList.count();i++)
        {
            tmpElement = SubuiNodeList.at(i).toElement();
            QString tmpString = tmpElement.attribute("type");
            //IDE_TRACE_STR(tmpString);
            SENSOR_TYPE tmpComType = getSensorType(tmpString);
            m_sensorNodes.insert(tmpComType, tmpElement);
        }
    }
    ///IDE_TRACE_INT(m_sensorNodes.count());
}

QDomElement ConfigureParser::getParameter()
{
    bool flag = getItemElement("/parameters");
    if(flag)
    {
        return itemElement;
    }else{
        return QDomElement();
    }
}

QString ConfigureParser::accGbDirection()
{
    bool flag = getItemElement("/accdirection");
    if(flag)
    {
        return itemElement.attribute("gb","2,0,1");
    }else{
        return QString();
    }
}

QString ConfigureParser::accAddDirection()
{
    bool flag = getItemElement("/accdirection");
    if(flag)
    {
        return itemElement.attribute("add","2,0,1");
    }else{
        return QString();
    }
}

bool ConfigureParser::setAddAccDirection(QString direction)
{
    bool flag = getItemElement("/accdirection");
    if(flag)
    {
        itemElement.setAttribute("add",direction);
        this->saveXml();
        return true;
    }else{
        return false;
    }

}

bool ConfigureParser::setGbAccDirection(QString direction)
{
    bool flag = getItemElement("/accdirection");
    if(flag)
    {
        itemElement.setAttribute("gb",direction);
        this->saveXml();
        return true;
    }else{
        return false;
    }
}

QString ConfigureParser::getVersion()
{
    return getItemElementValue("/board/Version");
}

QString ConfigureParser::getManufacturer()
{
    return getItemElementValue("/board/Manufacturer");
}

QString ConfigureParser::getSWversion()
{
    return getItemElementValue("/board/SWversion");
}

QString ConfigureParser::getHDVersion()
{
    return getItemElementValue("/board/HDVersion");
}
