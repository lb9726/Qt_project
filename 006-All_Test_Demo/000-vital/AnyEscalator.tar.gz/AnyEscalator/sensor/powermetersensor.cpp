#include "powermetersensor.h"
#include <QtMath>

PowermeterSensor::PowermeterSensor(SensorBase *parent) : SensorBase(parent)
{
    m_Peak = QREAL_MIN;
    m_Dip =  QREAL_MAX;
    m_c1Peak = QREAL_MIN;
    m_c1Dip =  QREAL_MAX;

    m_c2Peak = QREAL_MIN;
    m_c2Dip =  QREAL_MAX;

    m_c3Peak = QREAL_MIN;
    m_c3Dip  =  QREAL_MAX;

    m_activePeak = QREAL_MIN;
    m_activeDip =  QREAL_MAX;
}

void PowermeterSensor::initSensor(QDomElement element, ConfigureParser *cp)
{
    SensorBase::initSensor(element,cp);
}

void PowermeterSensor::appendData(qreal c1,qreal c2,qreal c3,qreal active,qreal total,qreal comsuption)
{
    SensorBase::appendData(total);
    m_C1Queue.enqueue(c1);
    m_C2Queue.enqueue(c2);
    m_C3Queue.enqueue(c3);
    m_activeQueue.enqueue(active);

    m_comsuption = comsuption;
    m_c1Peak = c1 > m_c1Peak ? c1 : m_c1Peak;
    //m_c1Dip = c1 > m_c1Dip ? m_c1Dip : c1;

    m_c2Peak = c2 > m_c2Peak ? c2 : m_c2Peak;
    //m_c2Dip = c2 > m_c2Dip ? m_c2Dip : c2;

    m_c3Peak = c3 > m_c3Peak ? c3 : m_c3Peak;
    //m_c3Dip = c3 > m_c3Dip ? m_c3Dip : c3;

    m_activePeak = active > m_activePeak ? active : m_activePeak;
    //m_activeDip = active > m_activeDip ? m_activeDip : active;
}

void PowermeterSensor::clearBuffer()
{    
    m_c1Peak = QREAL_MIN;
    m_c1Dip = QREAL_MAX;
    m_c2Peak = QREAL_MIN;
    m_c2Dip = QREAL_MAX;
    m_c3Peak = QREAL_MIN;
    m_c3Dip = QREAL_MAX;
    m_activePeak = QREAL_MIN;
    m_activeDip = QREAL_MAX;

    SensorBase::clearBuffer();
    m_C1Queue.clear();
    m_C1Queue.reserve(m_Freq);

    m_C2Queue.clear();
    m_C2Queue.reserve(m_Freq);

    m_C3Queue.clear();
    m_C3Queue.reserve(m_Freq);

    m_activeQueue.clear();
    m_activeQueue.reserve(m_Freq);
}


qreal PowermeterSensor::c1Avg()
{
    if(m_C1Queue.isEmpty())
        return 0.0;
    qreal avg = 0.0;
    for(int i=0;i < m_C1Queue.count();i++){
        avg += m_C1Queue.at(i);
    }
    return toFixedFloat(avg/m_C1Queue.count(),SensorBase_double_prec);
}

qreal PowermeterSensor::c1RMS()
{
    if(m_C1Queue.isEmpty())
        return 0.0;
    qreal rms = 0.0;
    for(int i=0;i < m_C1Queue.count();i++){
        rms += pow(m_C1Queue.at(i),2);
    }
    return toFixedFloat(qSqrt(rms/m_C1Queue.count()),SensorBase_double_prec);
}

qreal PowermeterSensor::c1Peak()
{
    return toFixedFloat(m_c1Peak,SensorBase_double_prec);
}

qreal PowermeterSensor::c1Dip()
{
    return toFixedFloat(m_c1Dip,SensorBase_double_prec);
}


qreal PowermeterSensor::c2Avg()
{
    if(m_C2Queue.isEmpty())
        return 0.0;
    qreal avg = 0.0;
    for(int i=0;i<m_C2Queue.count();i++){
        avg += m_C2Queue.at(i);
    }
    return toFixedFloat(avg/m_C2Queue.count(),SensorBase_double_prec);
}

qreal PowermeterSensor::c2RMS()
{
    if(m_C2Queue.isEmpty())
        return 0.0;
    qreal rms = 0.0;
    for(int i=0;i<m_C2Queue.count();i++){
        rms += pow(m_C2Queue.at(i),2);
    }

    return toFixedFloat(qSqrt(rms/m_C2Queue.count()),SensorBase_double_prec);
}

qreal PowermeterSensor::c2Peak()
{
    return toFixedFloat(m_c2Peak,SensorBase_double_prec);
}

qreal PowermeterSensor::c2Dip()
{
    return toFixedFloat(m_c2Dip,SensorBase_double_prec);
}



qreal PowermeterSensor::c3Avg()
{
    if(m_C3Queue.isEmpty())
        return 0.0;
    qreal avg = 0.0;
    for(int i=0;i<m_C3Queue.count();i++){
        avg += m_C3Queue.at(i);
    }
    return toFixedFloat(avg/m_C3Queue.count(),SensorBase_double_prec);
}

qreal PowermeterSensor::c3RMS()
{
    if(m_C3Queue.isEmpty())
        return 0.0;
    qreal rms = 0.0;
    for(int i=0;i<m_C3Queue.count();i++){
        rms += pow(m_C3Queue.at(i),2);
    }
    return toFixedFloat(qSqrt(rms/m_C3Queue.count()),SensorBase_double_prec);
}

qreal PowermeterSensor::c3Peak()
{
    return toFixedFloat(m_c3Peak,SensorBase_double_prec);
}

qreal PowermeterSensor::c3Dip()
{
    return toFixedFloat(m_c3Dip,SensorBase_double_prec);
}

qreal PowermeterSensor::activeAvg()
{
    if(m_activeQueue.isEmpty())
        return 0.0;
    qreal avg = 0.0;
    for(int i=0;i<m_activeQueue.count();i++){
        avg += m_activeQueue.at(i);
    }
    return toFixedFloat(avg/m_activeQueue.count(),SensorBase_double_prec);
}

qreal PowermeterSensor::activeRMS()
{
    if(m_activeQueue.isEmpty())
        return 0.0;
    qreal rms = 0.0;
    for(int i=0;i<m_activeQueue.count();i++){
        rms += pow(m_activeQueue.at(i),2);
    }
    return toFixedFloat(qSqrt(rms/m_activeQueue.count()),SensorBase_double_prec);
}

qreal PowermeterSensor::activePeak()
{
    return toFixedFloat(m_activePeak,SensorBase_double_prec);
}

qreal PowermeterSensor::activeDip()
{
    return toFixedFloat(m_activeDip,SensorBase_double_prec);
}

