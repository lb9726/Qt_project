#include "thermocouplesensor.h"

ThermocoupleSensor::ThermocoupleSensor(SensorBase *parent) : SensorBase(parent)
{

}

void ThermocoupleSensor::initSensor(QDomElement element, ConfigureParser *cp)
{
    SensorBase::initSensor(element,cp);
}
