#include "xmlparse.h"
const QString XmlParse::XmlHead = "version=\"1.0\" encoding=\"UTF-8\"";
const QString XmlParse::XmlSuffix = ".xml";

XmlParse::XmlParse() :QObject(), QDomDocument()
{
    m_ForceSave = true;
    m_Valid = false;
    m_IsChanged = true;
}

XmlParse::XmlParse(QString fileName) :QObject(), QDomDocument()
{
    m_ForceSave = true;
    m_Valid = false;
    m_IsChanged = true;
    QFileInfo tmpFileInfo(fileName);
    m_FileName = tmpFileInfo.fileName();
    m_FileDir = tmpFileInfo.dir().path();
    if(m_FileDir.contains('/'))
    {
        if(!m_FileDir.endsWith('/'))
            m_FileDir.append('/');
    }
    else
    {
        if(!m_FileDir.endsWith('/'))
            m_FileDir.append('/');
    }

//    IDE_TRACE_STR(m_FileDir);
//    IDE_TRACE_STR(m_FileName);
}

XmlParse::~XmlParse()
{
    if(m_IsChanged && m_ForceSave)
    {
        //IDE_TRACE();
        saveXmlAs(m_FileDir + m_FileName);
    }
    //clear();
}

bool XmlParse::getItemElement(QString itemPath)
{
    //IDE_TRACE_STR(itemPath);
    bool nodeFlag = true;          //是否为/test/subtest/类型的路径
    QString tmpString;
    QDomElement tmpElement, newElement;
    if (itemPath.at(0) != '/')
    {
        IDE_TRACE();
        return false;
    }
    tmpElement = documentElement();
    int index = 0, indexbk = 0;
    while(index < itemPath.length()-1)
    {
        index = itemPath.indexOf('/', index+1, Qt::CaseInsensitive);
        if(index<0)
        {
            nodeFlag = false;
            break;
        }
        tmpString = itemPath.mid(indexbk+1, index-indexbk-1);
        newElement = tmpElement.firstChildElement(tmpString);
        if(newElement.isNull())
        {
            IDE_TRACE_STR(tmpString);
            return false;
        }
        tmpElement = newElement;
        indexbk = index;
    }

    if(false == nodeFlag)
    {
        tmpString = itemPath.mid(indexbk+1);
        newElement = tmpElement.firstChildElement(tmpString);
        if(newElement.isNull())
        {
            IDE_TRACE_STR(tmpString);
            return false;
        }
        tmpElement = newElement;
    }
    itemElement = tmpElement;
    return true;
}

bool XmlParse::getItemElement(QDomElement itemDomElement, QString itemPath)
{
    bool nodeFlag = true;          //是否为/test/subtest/类型的路径
    QString tmpString;
    QDomElement tmpElement, newElement;
    if (itemPath.at(0) != '/')
    {
        IDE_TRACE();
        return false;
    }
    tmpElement = itemDomElement;
    int index = 0, indexbk = 0;
    while(index < itemPath.length()-1)
    {
        index = itemPath.indexOf('/', index+1, Qt::CaseInsensitive);
        if(index<0)
        {
            nodeFlag = false;
            break;
        }
        tmpString = itemPath.mid(indexbk+1, index-indexbk-1);
        newElement = tmpElement.firstChildElement(tmpString);
        if(newElement.isNull())
        {
            IDE_TRACE();
            return false;
        }
        tmpElement = newElement;
        indexbk = index;
    }
    if(false == nodeFlag)
    {
        tmpString = itemPath.mid(indexbk+1);
        newElement = tmpElement.firstChildElement(tmpString);
        if(newElement.isNull())
        {
            IDE_TRACE();
            return false;
        }
        tmpElement = newElement;
    }
    itemElement = tmpElement;
    return true;
}

QString XmlParse::getItemElementValue()
{
    QDomNode tmpNode = itemElement.firstChild();
    if(tmpNode.isNull() == false)
       return itemElement.text();
    return QString("");
}

QString XmlParse::getItemElementValue(QString itemPath)
{
    if(getItemElement(itemPath))
    {
        return getItemElementValue();
    }
    return QString("");
}

QList<QDomAttr> XmlParse::getItemElementAttrs(QDomElement itemDomElement)
{
    QList<QDomAttr> tmpAttrs;
    QDomNamedNodeMap tmpNodesMap = itemDomElement.attributes();
    for(int i=0;i<tmpNodesMap.count();i++)
        tmpAttrs.append(tmpNodesMap.item(i).toAttr());
    return tmpAttrs;
}

QList<QDomAttr> XmlParse::getItemElementAttrs()
{
    return getItemElementAttrs(itemElement);
}

QList<QDomAttr> XmlParse::getItemElementAttrs(QString itemPath)
{
    QList<QDomAttr> tmpAttrs;
    if(getItemElement(itemPath))
        return getItemElementAttrs();
    return tmpAttrs;
}

bool XmlParse::searchItemElement(QString itemName)
{
    QDomElement docElem = documentElement();
    QDomNodeList nodes=docElem.elementsByTagName(itemName);
    if(nodes.size()>0)
    {
        QDomElement tmpElement = nodes.at(0).toElement();
        if(tmpElement.isNull())
        {
            IDE_TRACE();
            return false;
        }
        itemElement = tmpElement;
        return true;
    }
    return false;
}

bool XmlParse::createItemElement(QString itemPath)
{
    //提取待创建的元素路径，并检验路径是否存在，如果不存在则创建
    bool nodeFlag = true;
    QString tmpString;
    QDomElement tmpElement, tmpElement_bk, newElement;
    QDomNode newNode;

    if (itemPath.at(0) != '/')
    {
        IDE_TRACE();
        return false;
    }
    tmpElement = documentElement();
    int index = 0, indexbk = 0;
    while(index < itemPath.length()-1)
    {
        index = itemPath.indexOf('/', index+1, Qt::CaseInsensitive);
        if(index<0)
        {
            nodeFlag = false;
            break;
        }
        tmpString = itemPath.mid(indexbk+1, index-indexbk-1);
        tmpElement = tmpElement.firstChildElement(tmpString);
        if(tmpElement.isNull())
        {
            newElement = createElement(tmpString);
            newNode = tmpElement_bk.appendChild(newElement);
            m_IsChanged = true;
            tmpElement = newNode.toElement();
            if(tmpElement.isNull())
            {
                IDE_TRACE();
                return false;
            }
        }
        indexbk = index;
        tmpElement_bk = tmpElement;
    }
    if(!nodeFlag)
    {
        tmpString = itemPath.mid(indexbk+1);
        tmpElement = tmpElement.firstChildElement(tmpString);
        if(tmpElement.isNull())
        {
            newElement = createElement(tmpString);
            newNode = tmpElement_bk.appendChild(newElement);
            m_IsChanged = true;
            tmpElement = newNode.toElement();
            if(tmpElement.isNull())
            {
                IDE_TRACE();
                return false;
            }
        }
    }
    itemElement = tmpElement;
    m_IsChanged = true;
    return true;
}

bool XmlParse::createItemElement(QDomElement pParElement, QString pName, QString pValue)
{
    if(pParElement.isNull())
        return false;
    QDomElement newElement = createElement(pName);
    QDomText newTitleText = createTextNode(pValue);
    newElement.appendChild(newTitleText);
    pParElement.appendChild(newElement);
    return true;
}

bool XmlParse::saveItemElement(QDomElement itemDomElement, QString& pContent)
{
    if(itemDomElement.isNull())
        return false;
    QTextStream out(&pContent);
    itemDomElement.save(out, 0);
    return true;
}

bool XmlParse::saveItemElement(QString& pContent)
{
    return saveItemElement(itemElement, pContent);
}

bool XmlParse::saveItemElement(QDomElement itemDomElement, QIODevice *pDevice)
{
    if(itemDomElement.isNull() || !pDevice)
        return false;
    if(!pDevice->isOpen())
    {
        IDE_TRACE();
        return false;
    }
    QTextStream out(pDevice);
    itemDomElement.save(out, 0);
    return true;
}

bool XmlParse::saveItemElement(QIODevice *pDevice)
{
    return saveItemElement(itemElement, pDevice);
}

bool XmlParse::modifyItemElement(QString itemPath, QString value)
{
    bool flag = getItemElement(itemPath);
    if(flag == false)
    {
        flag = createItemElement(itemPath);
        if(flag == false)
        {
            IDE_TRACE();
            return false;
        }
    }
    return modifyItemElement(itemElement, value);
}

bool XmlParse::modifyItemElement(QDomElement itemDomElement, QString value)
{
    if(itemDomElement.isElement() == false)
    {
        IDE_TRACE();
        return false;
    }
    QDomNodeList tmpList = itemDomElement.childNodes();
    if(!tmpList.isEmpty())
    {
        for(int i=tmpList.count()-1;i>=0;i--)
        {
            QDomNode tmpNode = tmpList.at(i);
            if(tmpNode.isNull())
                continue;
            if(tmpNode.nodeType() == QDomNode::TextNode)
            {
                m_IsChanged = true;
                itemDomElement.removeChild(tmpNode);
                break;
            }
        }
    }
    if(!value.isEmpty())
    {
        QDomText newTitleText = createTextNode(value);
        QDomNode tmpNewNode = itemDomElement.appendChild(newTitleText);
        m_IsChanged = true;
        if(tmpNewNode.isNull())
        {
            IDE_TRACE();
            //return false;
        }
    }
    return true;
}

bool XmlParse::modifyFreq(QDomElement itemDomElement, int value){
    if(itemDomElement.isElement() == false)
    {
        IDE_TRACE();
        return false;
    }

    QDomElement freqDom = itemDomElement.firstChildElement("frequency");
    if(freqDom.isElement()){
        IDE_TRACE();
       return modifyItemElement(freqDom,QString("%1").arg(value));
    }else{
        IDE_TRACE();
       return createItemElement(itemDomElement,"frequency",QString("%1").arg(value));
    }
}

bool XmlParse::modifyDeviceParameter(QDomElement itemDomElement, QString paraName,int value){
    if(itemDomElement.isElement() == false)
    {
        IDE_TRACE();
        return false;
    }

    QDomElement dom = itemDomElement.firstChildElement(paraName);
    if(dom.isElement()){
        //IDE_TRACE();
       return modifyItemElement(dom,QString("%1").arg(value));
    }else{
        IDE_TRACE();
       return createItemElement(itemDomElement,paraName,QString("%1").arg(value));
    }
}

bool XmlParse::setText(QDomElement itemDomElement, QString value)
{
    return modifyItemElement(itemDomElement, value);
}

bool XmlParse::deleteItemElement(QDomElement itemDomElement)
{
    if(itemDomElement.isNull())
        return true;
    QDomNode tmpParentNode = itemDomElement.parentNode();
    if(tmpParentNode.isNull())
    {
        IDE_TRACE();
        return false;
    }
    QDomNode newNode = tmpParentNode.removeChild(itemDomElement);
    if(newNode.isNull())
    {
        IDE_TRACE();
        return false;
    }
    newNode.clear();
    m_IsChanged = true;
    return true;
}

bool XmlParse::clearItemElement(QDomElement itemDomElement)
{
    if(itemDomElement.isNull())
        return false;
    QDomNodeList tmpList = itemDomElement.childNodes();
    if(tmpList.count())
    {
        for(int i=tmpList.count()-1;i>=0;i--)
        {
            QDomNode newNode = itemDomElement.removeChild(tmpList.at(i));
            if(newNode.isNull())
                continue;
            newNode.clear();
        }
    }
    m_IsChanged = true;
    return true;
}

bool XmlParse::writeXml(QIODevice *device)
{
    const int IndentSize = 4;
    if(device->isOpen() == false)
    {
        IDE_TRACE();
        return false;
    }
    QTextStream out(device);
    save(out, IndentSize);
    return true;
}

bool XmlParse::readXml(QIODevice *device)
{
    if(device->isOpen() == false)
    {
        IDE_TRACE();
        return false;
    }
    bool flag = setContent(device, false, &errorStr, &errorLine, &errorColumn);
    if (flag == false)
    {
        IDE_TRACE();
        return false;
    }
    return true;
}

bool XmlParse::openXml()
{
//    IDE_TRACE_STR(m_FileDir);
//    IDE_TRACE_STR(m_FileName);
    //if(m_FileDir.isEmpty() || m_FileName.isEmpty())
        //return false;

    if(!m_FileDir.endsWith("/"))
        m_FileDir.append("/");
    QFile file(m_FileDir + m_FileName);

    bool flag = file.exists();
    if(flag == true)
    {
        flag = file.open(QFile::ReadOnly | QFile::Text);
        if (flag == false)
        {
            IDE_TRACE();
            return false;
        }
        flag = readXml(&file);
        if(flag == false)
        {
            file.close();
            IDE_TRACE();
            return false;
        }
    }
    else
    {
        IDE_TRACE();
        IDE_TRACE_STR(m_FileDir + m_FileName);
        return false;
    }
    return true;
}

bool XmlParse::createXml()
{
    if(m_FileDir.isEmpty() || m_FileName.isEmpty())
        return false;

    QDir dir(m_FileDir);
    dir.mkpath(m_FileDir);

    QFile file(m_FileDir + m_FileName);       //此处只要新建一个空文件即可。
    bool flag = file.exists();
    if(flag == true)
    {
        IDE_TRACE();
        return false;
    }
    flag = file.open(QFile::WriteOnly | QFile::Text);
    if (flag == false)
    {
        IDE_TRACE();
        return false;
    }
    file.close();
    return true;
}

bool XmlParse::saveXml()
{
    if(m_FileDir.isEmpty() || m_FileName.isEmpty())
        return false;
    if(m_IsChanged)
    {
        QString tmpString = m_FileDir +m_FileName;// + QString("_bk");
        saveXmlAs(tmpString);
        m_IsChanged = false;
    }
    return true;
}

bool XmlParse::renameXml(QString fileName)
{
    if(m_FileDir.isEmpty() || m_FileName.isEmpty() || fileName.isEmpty())
        return false;

    QFile file(m_FileDir + m_FileName);
    file.setPermissions(QFile::ReadOther|QFile::WriteOther|QFile::ExeOther);
    bool flag = file.exists();
    if(flag == false)  //如果文件不存在，则重命名看作成功。
    {
        return true;
    }
    flag = file.rename(m_FileDir + fileName);
    return flag;

}

bool XmlParse::saveXmlAs(QString fileName)
{
    if(m_FileDir.isEmpty() || m_FileName.isEmpty() || fileName.isEmpty())
        return false;
    if(isNull())
    {
        IDE_TRACE();
        return false;
    }
    QFile f(fileName);
    bool flag = f.open(QIODevice::WriteOnly | QIODevice::Text);
    if (flag == false)
    {
        IDE_TRACE();
        return false;
    }
    flag = writeXml(&f);
    if(flag == false)
    {
        IDE_TRACE();
        f.close();
        return false;
    }
    f.close();
    m_IsChanged = false;
    return true;
}
