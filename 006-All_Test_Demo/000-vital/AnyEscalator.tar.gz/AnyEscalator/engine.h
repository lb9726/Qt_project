#ifndef ENGINE_H
#define ENGINE_H

#include <QObject>
#include <QThread>
#include <QMap>
#include <QSettings>


#include "sensor/sensorhub.h"
#include "physic/interprotocol.h"
#include "utility/ftp/ftpclient.h"
#include "utility/websocket/websocketserver.h"
#include "utility/websocket/websocketclient.h"

#include "logic/datalogger.h"
#include "logic/deviceparameters.h"
#include "logic/devicestatus.h"
#include "logic/routinecall.h"
#include "logic/onlinestatus.h"

#include "physic/acceleratenode.h"
#include "physic/micnode.h"
#include "physic/ledcontroller.h"

#include "comProtocol/cdcprotocol.h"

class Engine : public QObject
{
    Q_OBJECT
public:
    explicit Engine(QObject *parent = 0);
    ~Engine();

    void initEngine();
    void startDevice();

    void initInterProtocol();
    void startInterProtocol();

    void initLogger();
    void startLogger();

    void initWebsocket();
    void startWebsocket();

    void initLogic();
    void startLogic();

    void initSensorHub();
    void startSensorHub();

    void startOnboradNode();
    void initOnboradNode();

    void initFtpClient();
    void startFtpClient();

    void initPcHelper();
    void startPcHelper();

    void bootUpDTUMsg();

signals:
    ///PC Helper
    //void sigSendHelperJson(QJsonObject msg);
    void sigSendHelperJson(QJsonObject msg,QString subType);
    ///MCU DATA
    void sTcData(qreal t1,qreal t2,qreal t3,qreal t4);
    void sInfradData(qreal t1,qreal t2,qreal a1,qreal a2);
    void sPowerData(qreal a1,qreal a2,qreal a3,qreal active,qreal total,qreal comsuption);
    void sDirectionData(int direction);
    void sPeopleCountData(int peopleCount);
    void sSpeedData(int speed);
    ///DTU
    void sigSendJsonMsg(QJsonObject msg);
    void sigStartOnlineStatus(int interval);
    void sigStopOnlineStatus();
    void sigStartKpi(int interval);
    void sigStopKpi();
    void sigOnlineStatusTrigger();
    ///FTP
    void sigGetFile(QString localName,QString remoteName );
    void sigStartUploadFile(QString baseDir);
    bool sigAppendUploadFile(QString filePath);
signals:
    ///StartWork trigger signals
    void sigStartInterProtocol();
    void sigStartWebSocketClient();
    void sigStartLogger();
    void sigStartSensorHub();
    void sigStartFtpClient();
    void sigStartPcHelper();
    ///PC Helper
    void deviceDebugModel(bool flag);
    void triggerMicRecord(QString name);
public slots:///PC Helper
    void helperMessage(QJsonObject jsonObj);
    void helperDisconnected();
    void helperConnected();
    void helper_getparameters();
    void helper_setParameter(QJsonObject msgObj);
    void helper_onlinestatus(bool flag);
    void helperRealtimeDataTrigger();
    void helper_setAxis(QJsonObject msgObj);    
    void helper_reportAccDirection();

    void leaveHelperModel();
    void enterHelperModel();
    void gbVibDataHelper(qreal forward, qreal lateral, qreal vertical);
    void addVibDataHelper(qreal forward, qreal lateral, qreal vertical);
    void topMicDataHelper(qreal micRMS);

    void rebootPrepare();

private slots:///MCU Data
    void thermoCoupleData(QString data);
    void infradData(QString data);
    void powerData(QString data);
    void speedData(QString data);
    void peopleCountData(QString data);
    void directionData(QString data);
    void nodeConnectStatus(quint8 node,bool flag);
private slots:///DTU
    void dtuMessage(QJsonObject msgObj);
    void dtuWebSocketConnected();

    void dtuWebSocketDisconnected();
    void sltSendJsonMsg(QJsonObject obj);
    void OnlineStatusTrigger();
    void startOnlineStatus(int elapseSeconds);

    void SWUpdateComplete(int updateStatus);
    void RawDataUploaded(int updateStatus);
    ///DTU CMD
    void dtu_configurationDownload(QJsonObject &obj);
    void dtu_startStatus(QJsonObject &obj);
    void dtu_stopStatus();
    void dtu_rawDataRequest(QJsonObject &obj);
    void dtu_swUpdateRequest(QJsonObject &obj);
    void dtu_timeSync(QJsonObject &obj);
private slots:
    ///Furquency Configure
    void sltgbVibFreq(int freq);
    void sltaddVibFreq(int freq);
    void sltTcFreq(int freq);
    void sltInfraredFreq(int freq);
    void sltKPIFreq(int freq);
    void sltMicFreq(int freq);
private slots:
    ///FTP
    void getFTPFileFinished(QString fileName, bool isSucceed);
    void putFTPFileFinished(QString fileName, bool isSucceed);
    void uploadRawFileCompelete(bool isSucceed);
    void getRawDataList(QDateTime start, QDateTime end);

public:
    QString m_baseDirPath;
    ConfigureParser *m_cp;
    InterProtocol *m_interProtocol;
    DeviceParameters *m_deviceParameters;
    DeviceStatus  *m_deviceStatus;
    RoutineCall *m_routineCall;

    WebSocketClient *m_webSocketClient; ///independence Thread

    DataLogger*   m_dataLogger; ///independence Thread

    SensorHub *m_sensorHub; ///independence Thread
    QTimer *m_kpiTimer;
    QTimer *m_onolineStatusTimer;
    quint32 m_onlineCounter;

    ///Onboard Node
    AccelerateNode *m_leftVibNode;
    AccelerateNode *m_rightVibNode;
    QDomElement m_Accdirection;
    MicNode *m_micNode;
    ///FTP
    FtpClient *m_ftpClient;
    bool isUploadingRawData;
    QString m_softwareUpdater;
    QMap<QString,QString>  m_RawFileMap;

    ///PC Cliet
    WebSocketServer *m_webSocketPcHelper;
    cdcProtocol *m_PcHelperClient;



    bool m_helperConnected;
    QTimer *m_helperRealtimeDataTimer;
    QVariantMap  m_helperRealTimeBuffer;
    bool mSensorStatus[7]={false};//first 5 is from the mcu ,last 2 is VIB1,VIB2
    bool mAllNodeStatus;
    bool m_GlobleNodeConnectStatus;
    ///Globle People Count Number
    quint64 m_TotalPeopleCount;
    QSettings *m_settings;

    void updateGbAccDirection(QString va);
    void updateAddAccDirection(QString va);

    bool m_isFirstPeoplePassed;
    bool m_devLightStatus;
    QTimer *m_peopleDetectTimer;
    void initPeopleCountLogic();
    void peopleCountLogicTimerSlot();
    void startPeopleCountLogic();

    void sltleftVibRemoved();
    void sltrightVibRemoved();
};

#endif // ENGINE_H
