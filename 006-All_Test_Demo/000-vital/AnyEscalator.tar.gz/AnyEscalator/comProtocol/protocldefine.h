#ifndef PROTOCLDEFINE_H
#define PROTOCLDEFINE_H

//#define D_FRAMEHEADER 0x80;
//#define D_FRAMEFOOTER 0x81;
//#define D_FRAMEHEADER_ACK  0xc0;
//#define D_FRAMEFOOTER_ACK  0xc1;

//const unsigned char D_FRAMEHEADER = 0x80;
//const unsigned char D_FRAMEFOOTER = 0x81;
//const unsigned char D_FRAMEHEADER_ACK = 0xc0;
//const unsigned char D_FRAMEFOOTER_ACK = 0xc1;

typedef enum{
    Flag_Normal = 0,
    Flag_Ack = 1,
    Flag_Unknow = 2
} FRAME_FLAG;

typedef enum{
    State_Wait = 0,
    State_Header,
    State_CmdPara,
    State_AddrH,
    State_AddrL,
    State_DatalenH,
    State_DatalenL,
    State_Data,
    State_CRC,
    State_Footer
} FRAME_STATE;

typedef enum{
    Type_Heartbeat = 0x10,
    Type_ConfCmd = 0x04,
    Type_FileTrans = 0x05,
    Type_NONE = 0xff
} FRAME_TYPE;

typedef enum{
    SC_Unknow = 0,
    // UnQueue
    SC_Init = 1,   // 获取设备的基础参数
    SC_Release,
    SC_Connect,
    SC_Disconnect,
    SC_Set,        // 设置寄存器参数
    SC_Get,        // 获取寄存器参数
    SC_Cmd,        // 设备可直接执行的命令，比如创建路径、移动文件/夹，删除文件夹等
    SC_FTP,
    SC_Ls,         // 查询某个路径的文件列表
    SC_Copy,
    SC_Cut,
    SC_Del,
    SC_Msg,        // 消息或调试信息
    SC_Zip,
    SC_Unzip,
    // Queue
    SC_SendFileTest = 20,
    SC_GetFileTest,
    SC_StartGetFile,
    // Father
    SC_SendFile = 40,
    SC_GetFile,
    SC_SendDir,
    SC_GetDir,

}SETCMD_TYPE;

typedef enum{
    Flag_None = 0x00,
    Flag_FileData = 0x01,
    Flag_FileFooter = 0x02,
    Flag_FileMD5 = 0x04,
    Flag_Stop = 0x40,
    Flag_OneTrans = 0x20,
    Flag_ReTrans = 0x10
} FILETRANS_FLAG;

typedef enum{
    Failed = 0,
    Success,
    Start,
    Timeout,
    Stopped,
    Unstart
}TaskState;

#define D_Success           QString("Success")
#define D_Failed            QString("Failed")
#define D_CMDSUBSPLIT  QString("#")
#define D_PARASPLIT    '>'
#define D_TMPSUFFIX         QString(".tmp")

#define D_FRAMEMINLEN       5
#define D_SETFRAME_TIMEOUT  2000
#define D_PACKAGE_SIZE      10240
#define D_PACKAGE_TIMEOUT   500   // 传输1包数据的时延(ms)

inline FRAME_TYPE ToFrameType(quint8 pType)
{
    switch(pType)
    {
    case Type_Heartbeat:
        return Type_Heartbeat;
    case Type_ConfCmd:
        return Type_ConfCmd;
    case Type_FileTrans:
        return Type_FileTrans;
    default:
        return Type_NONE;
    }
    return Type_NONE;
}


inline SETCMD_TYPE StrToSCType(QString pStr)
{
    if(pStr.isEmpty())
        return SC_Unknow;
    if(pStr.compare("Init",Qt::CaseInsensitive) == 0)
        return SC_Init;
    else if(pStr.compare("Set",Qt::CaseInsensitive) == 0)
        return SC_Set;
    else if(pStr.compare("Get",Qt::CaseInsensitive) == 0)
        return SC_Get;
    //
    else if(pStr.compare("Msg",Qt::CaseInsensitive) == 0)
        return SC_Msg;
    else if(pStr.compare("Cmd",Qt::CaseInsensitive) == 0)
        return SC_Cmd;
    else if(pStr.compare("FTP",Qt::CaseInsensitive) == 0)
        return SC_FTP;
    else if(pStr.compare("Ls",Qt::CaseInsensitive) == 0)
        return SC_Ls;
    else if(pStr.compare("SendFileTest",Qt::CaseInsensitive) == 0)
        return SC_SendFileTest;
    else if(pStr.compare("GetFileTest",Qt::CaseInsensitive) == 0)
        return SC_GetFileTest;
    else if(pStr.compare("StartGetFile",Qt::CaseInsensitive) == 0)
        return SC_StartGetFile;
    //
    else if(pStr.compare("SendFile",Qt::CaseInsensitive) == 0)
        return SC_SendFile;
    else if(pStr.compare("GetFile",Qt::CaseInsensitive) == 0)
        return SC_GetFile;
    else if(pStr.compare("GetDir",Qt::CaseInsensitive) == 0)
        return SC_GetDir;
    else if(pStr.compare("SendDir",Qt::CaseInsensitive) == 0)
        return SC_SendDir;
    //
    else if(pStr.compare("Copy",Qt::CaseInsensitive) == 0)
        return SC_Copy;
    else if(pStr.compare("Cut",Qt::CaseInsensitive) == 0)
        return SC_Cut;
    else if(pStr.compare("Del",Qt::CaseInsensitive) == 0)
        return SC_Del;
    //
    else if(pStr.compare("Zip",Qt::CaseInsensitive) == 0)
        return SC_Zip;
    else if(pStr.compare("Unzip",Qt::CaseInsensitive) == 0)
        return SC_Unzip;
    //>
    else if(pStr.compare("Init",Qt::CaseInsensitive) == 0)
        return SC_Init;
    else if(pStr.compare("Release",Qt::CaseInsensitive) == 0)
        return SC_Release;
    else if(pStr.compare("Connect",Qt::CaseInsensitive) == 0)
        return SC_Connect;
    else if(pStr.compare("Disconnect",Qt::CaseInsensitive) == 0)
        return SC_Disconnect;

    return SC_Unknow;
}

inline QString SCTypeToStr(SETCMD_TYPE pType)
{
    switch(pType)
    {
    case SC_Init:return QString("Init");
    case SC_Release:return QString("Release");
    case SC_Connect:return QString("Connect");
    case SC_Disconnect:return QString("Disconnect");
    case SC_Set:return QString("Set");
    case SC_Get:return QString("Get");
    case SC_Cmd:return QString("Cmd");
    case SC_Msg:return QString("Msg");
    case SC_Copy:return QString("Copy");
    case SC_Cut:return QString("Cut");
    case SC_Del:return QString("Del");
    case SC_Zip:return QString("Zip");
    case SC_Unzip:return QString("Unzip");
    case SC_FTP:return QString("FTP");
    case SC_Ls:return QString("Ls");
    case SC_SendFileTest:return QString("SendFileTest");
    case SC_GetFileTest:return QString("GetFileTest");
    case SC_StartGetFile:return QString("StartGetFile");
    case SC_SendFile:return QString("SendFile");
    case SC_GetFile:return QString("GetFile");
    case SC_GetDir:return QString("GetDir");
    case SC_SendDir:return QString("SendDir");

    default:break;
    }
    return QString();
}

typedef enum{
    SUB_Unknow = 0,
    SUB_Connect,
    SUB_RealtimeData,
    SUB_Parameter,
    SUB_Accdirection,
    SUB_Micrecord,
    SUB_Systemcmd,
    SUB_Ls,
    SUB_CdUp,
    SUB_Cd,
}SUBTYPE_TYPE;

inline SUBTYPE_TYPE strTosubType(QString pStr)
{
    if(pStr.isEmpty())
        return SUB_Unknow;
    if(pStr.compare("connect",Qt::CaseInsensitive) == 0)
        return SUB_Connect;
    else if(pStr.compare("realtimeData",Qt::CaseInsensitive) == 0)
        return SUB_RealtimeData;
    else if(pStr.compare("micrecord",Qt::CaseInsensitive) == 0)
        return SUB_Micrecord;
    else if(pStr.compare("systemcmd",Qt::CaseInsensitive) == 0)
        return SUB_Systemcmd;
    else if(pStr.compare("ls",Qt::CaseInsensitive) == 0)
        return SUB_Ls;
    else if(pStr.compare("cdup",Qt::CaseInsensitive) == 0)
        return SUB_CdUp;
    else if(pStr.compare("cd",Qt::CaseInsensitive) == 0)
        return SUB_Cd;
    else if(pStr.compare("parameter",Qt::CaseInsensitive) == 0)
        return SUB_Parameter;
    else if(pStr.compare("accdirection",Qt::CaseInsensitive) == 0)
        return SUB_Accdirection;
    return SUB_Ls;
}

inline QString subTypeToString(SUBTYPE_TYPE pType)
{
    switch(pType)
    {
    case SUB_Connect:return QString("connect");
    case SUB_RealtimeData:return QString("realtimeData");
    case SUB_Micrecord:return QString("micrecord");
    case SUB_Systemcmd:return QString("systemcmd");
    case SUB_Ls:return QString("ls");
    case SUB_CdUp:return QString("cdup");
    case SUB_Cd:return QString("cd");
    case SUB_Parameter:return QString("parameter");
    case SUB_Accdirection:return QString("accdirection");
    default:break;
    }
    return QString();
}



inline quint32 CharToU32(char pNum)
{
    return (quint32)(quint8)(pNum);
}

inline qint64 GetTransTimeout(qint64 pSize)
{
    return qMax((qint64)(pSize * D_PACKAGE_TIMEOUT / D_PACKAGE_SIZE), (qint64)(5000));
}

inline bool StrToLongLong(QString pStr, qint64 &pLongLong)
{
    bool ok = false;
    pLongLong = pStr.toLongLong(&ok,10);
    if(!ok)
        return false;
    return true;
}

#endif // PROTOCLDEFINE_H
