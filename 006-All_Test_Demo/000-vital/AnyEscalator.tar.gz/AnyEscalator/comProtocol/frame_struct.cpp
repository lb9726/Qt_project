#include "frame_struct.h"
#include "../define.h"

FRAME_STRUCT::FRAME_STRUCT(QObject *parent) : QObject(parent)
{
    mFlag = Flag_Normal;
    mType = Type_NONE;
    mCmd = 0;
    mAddr = 0;
    mLength = 0;
    mCRC = 0;    
}

void FRAME_STRUCT::ClearData()
{
    mData.clear();
    mLength = 0;
}

bool FRAME_STRUCT::isRequireFrame()
{
    return (mFlag==Flag_Normal);
}
