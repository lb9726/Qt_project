#ifndef READFILEOP_H
#define READFILEOP_H

#include <QObject>
#include <QFile>
class ReadFileOp : public QObject
{
    Q_OBJECT
public:
    explicit ReadFileOp(QObject *parent = 0);
        ~ReadFileOp();
        void unbind();
        bool bind(QString pSrc);
        void setpos(qint64 pPos);
        bool read(qint64 maxlen);
        int progress();
        QByteArray getmd5() {return QByteArray();}
    public:
        bool        mEnable;
        QFile       mFile;
        qint64      mSize;
        qint64      mPos;
        qint64      mSurplus;
        QByteArray  mCurPack;
   };


#endif // READFILEOP_H
