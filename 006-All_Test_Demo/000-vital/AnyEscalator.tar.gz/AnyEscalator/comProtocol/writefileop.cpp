#include "writefileop.h"
#include "../define.h"

WriteFileOp::WriteFileOp(QObject *parent) : QObject(parent)
{
    mEnable = false;
    unbind();
}
WriteFileOp::~WriteFileOp()
{
    unbind();
}
void WriteFileOp::unbind()
{
    //IDE_TRACE();
    if(mFile.isOpen()){
        mFile.close();

    }
    mEnable = false;
    mSize = mPos = mSurplus = 0;

}
bool WriteFileOp::bind(QString pSrc, qint64 pSize)
{
    unbind();
    if(pSrc.isEmpty())
    {
        IDE_TRACE();
        return false;
    }
    mFile.setFileName(pSrc);
    if(mFile.exists()){
        mFile.remove();
    }
    if(!mFile.open(QFile::WriteOnly))
    {
        IDE_TRACE_STR(pSrc);
        return false;
    }
    IDE_TRACE_STR(pSrc);
    mSurplus = mSize = pSize;
    mEnable = true;
    return true;
}

bool WriteFileOp::write(QByteArray pByteArray, qint64 pPos)
{
    if(!mEnable)
        return false;
    if(pByteArray.isEmpty())
        return true;
//    if(!mFile.open(QFile::WriteOnly))
//    {
//        IDE_TRACE();
//        return false;
//    }
    bool flag = true;
    if(pPos >= 0)
        flag = mFile.seek(pPos);
    if(flag)
    {
        if(mFile.write(pByteArray) <= 0)
        {
            flag = false;
        }
        else
        {
            mFile.flush();
            mPos = mFile.pos();
            mSurplus = mSize - mPos;
        }
    }
    //mFile.close();
    return flag;
}
bool WriteFileOp::repair()  //  将保存的文件恢复
{
    if(!mEnable)
        return false;
    QString tmpSrc = mFile.fileName();
    if(tmpSrc.isEmpty())
        return false;
    return true;//CutFile(tmpSrc+D_TMPSUFFIX, tmpSrc);
}
int WriteFileOp::progress()
{
    int tmpProg = 0;
    if(mEnable)
    {
        if(mSize > 0 && mPos > 0)
        {
            int div = mSize/100;
            if(div > 0)
                tmpProg = mPos / div;
        }
    }
    return tmpProg;
}
