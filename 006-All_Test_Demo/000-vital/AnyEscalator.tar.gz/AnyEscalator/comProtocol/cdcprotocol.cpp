#include "cdcprotocol.h"
//#define CRC
#define D_FRAMEHEADER 0x80;
#define D_FRAMEFOOTER 0x81;
#define D_FRAMEHEADER_ACK  0xc0;
#define D_FRAMEFOOTER_ACK  0xc1;

cdcProtocol::cdcProtocol(QObject *parent) : QObject(parent)
{
    m_FrameState = State_Wait;
    m_CurRevFrame = NULL;
    m_CurSendFrame = NULL;
    m_ReadFileOp = NULL;// ReadFileOp(this);
    m_WriteFileOp = NULL;// WriteFileOp(this);
    m_WaitTimeout = 0;
    m_QueueProgress = 0;
    m_FileTransState = Unstart;
    m_ConfState = Unstart;
    m_SetTaskState = Unstart;
    m_GetTaskState = Unstart;
    m_DevInfoTaskState = Unstart;
    m_HBState = Unstart;
    m_SendDirTaskState = Unstart;
    m_GetDirTaskState = Unstart;
    isConnected = false;
    m_pTcpServer = NULL;
    m_pTcpSocket = NULL;

    initiativeHBEnabled = false;
    initiativeHBCount = 0;
    initiativeHBTimer = NULL;
    m_MaxBlockSize = 4096;
    m_comPort = NULL;
    comPortReopenTimer = new QTimer;
    comPortReopenTimer->setInterval(10000);
    connect(comPortReopenTimer,&QTimer::timeout,this,&cdcProtocol::startWork);
}

void cdcProtocol::init(){
    initiativeHBTimer = new QTimer();
    initiativeHBInterval = 2000;
    connect(initiativeHBTimer,&QTimer::timeout,this,&cdcProtocol::slot_initiativeHBTimeout);
    mDir = QDir("/home/root/data/");
    m_ReadFileOp = new ReadFileOp(this);
    m_WriteFileOp = new WriteFileOp(this);
}

void cdcProtocol::helperConnected(){
    mDir = QDir("/home/root/data/");
    emit sigConnect();
}

void cdcProtocol::helperDisconnected(){
    emit sigDisconnect();
}

void cdcProtocol::initTcpTest(int port)
{
    m_pTcpServer = new QTcpServer();
    if(!m_pTcpServer->listen(QHostAddress::Any,port)){
        IDE_TRACE_STR("Test TCP Server Listen Error!");
    }
    connect(m_pTcpServer,SIGNAL(newConnection()),this,SLOT(newConnectSlot()));
    m_pTcpSocket = NULL;
}

void cdcProtocol::newConnectSlot()
{
    if(m_pTcpSocket){
        m_pTcpSocket->close();
    }
    m_pTcpSocket = m_pTcpServer->nextPendingConnection();
    connect(m_pTcpSocket,SIGNAL(readyRead()),this,SLOT(readMessage()));
    connect(m_pTcpSocket,SIGNAL(disconnected()),this,SLOT(clientDisconnected()));
    isConnected = true;
    IDE_TRACE();
}

void cdcProtocol::clientDisconnected(){
    IDE_TRACE();
    isConnected = false;
}

bool cdcProtocol::OpenCom()
{
    m_comPort = new QSerialPort(this);
    m_comPort->setPortName("/dev/ttyGS0");
    if(m_comPort->open(QIODevice::ReadWrite))
    {
        //设置波特率
        m_comPort->setBaudRate(115200);
        //设置数据位
        m_comPort->setDataBits(QSerialPort::Data8);
        //设置校验位
        m_comPort->setParity(QSerialPort::NoParity);
        //设置流控制
        m_comPort->setFlowControl(QSerialPort::NoFlowControl);
        //设置停止位
        m_comPort->setStopBits(QSerialPort::OneStop);
        connect(m_comPort,&QSerialPort::readyRead,this,&cdcProtocol::readMessage);
        connect(m_comPort,SIGNAL(error(QSerialPort::SerialPortError)),this,SLOT(comportError(QSerialPort::SerialPortError)));
        return true;
    }
    else
    {
        IDE_TRACE();
        delete m_comPort;
        m_comPort = NULL;
        return false;
    }
}

void cdcProtocol::comportError(QSerialPort::SerialPortError error){//
    IDE_TRACE();
    //qDebug()<<error;
    disconnect(m_comPort,&QSerialPort::readyRead,this,&cdcProtocol::readMessage);
    disconnect(m_comPort,SIGNAL(error(QSerialPort::SerialPortError)),this,SLOT(comportError(QSerialPort::SerialPortError)));
    m_comPort->close();
    m_comPort = NULL;
    ////m_HBTimeoutTimer->stop();
    startWork();
}

void cdcProtocol::readMessage()
{
    ///IDE_TRACE();
    ParseFrameBuffer(m_comPort->readAll());
}

quint32 cdcProtocol::SendFrame(FRAME_STRUCT *pFrame)
{
    if(!pFrame)
    {
        return 0;
    }
    pFrame->mFlag = Flag_Normal;
    return SendData(pFrame);
}
quint32 cdcProtocol::ReplyFrame(FRAME_STRUCT *pFrame)
{
    if(!pFrame)
    {
        return 0;
    }
    pFrame->mFlag = Flag_Ack;
    return SendData(pFrame);
}
quint32 cdcProtocol::SendData(FRAME_STRUCT *pFrame)
{
    if(!pFrame)
    {
        IDE_TRACE();
        return 0;
    }
    QByteArray tmpSendData;
    if(pFrame->mFlag == Flag_Normal){
        tmpSendData.append(0x80);
    }else{
        tmpSendData.append(0xc0);
    }
    quint8 tmpFrameType = pFrame->mType;
    tmpSendData.append(tmpFrameType);
    switch(tmpFrameType)
    {
    case Type_Heartbeat:
    case Type_ConfCmd:
    {
        tmpSendData.append(pFrame->mCmd);
        quint16 tmpLenth = pFrame->mData.count();
        tmpSendData.append((quint8)(tmpLenth>>8));
        tmpSendData.append((quint8)(tmpLenth));
        tmpSendData.append(pFrame->mData);
        break;
    }
    case Type_FileTrans:
    {
        tmpSendData.append(pFrame->mCmd);
        tmpSendData.append((quint8)(pFrame->mAddr>>8));
        tmpSendData.append((quint8)(pFrame->mAddr));
        quint16 tmpLenth = pFrame->mData.count();
        tmpSendData.append((quint8)(tmpLenth>>8));
        tmpSendData.append((quint8)(tmpLenth));
        tmpSendData.append(pFrame->mData);
        break;
    }
    default:
    {
        tmpSendData.clear();
        pFrame->deleteLater();
        return 3;
    }
    }
    quint8 tmpCRC = 0;
#ifdef CRC
    int tmpCount = tmpSendData.count();
    for(int i=1;i<tmpCount;i++)
    {
        tmpCRC ^= tmpSendData.at(i);
    }
#endif
    tmpSendData.append(tmpCRC&0x7f);
    if(pFrame->mFlag == Flag_Normal)
        tmpSendData.append(0x81);
    else
        tmpSendData.append(0xc1);

    qint64 tmpLenth = -1;
    ///qDebug()<<"Any SendData:"<<tmpSendData;
    if(m_comPort)
        tmpLenth = m_comPort->write(tmpSendData);
    tmpSendData.clear();
    pFrame->deleteLater();
    return tmpLenth;
}

quint32 cdcProtocol::ParseFrameBuffer(QByteArray pFrameBuffer)
{
    ////qDebug()<<"Any ParseFrameBuffer:"<<pFrameBuffer;
    if(pFrameBuffer.isEmpty())
    {
        pFrameBuffer.clear();
        return 0;
    }
    quint32 tmpCount = pFrameBuffer.count();
    quint8 tmpValue = 0;
    quint32 i = 0;
    ///qDebug()<<"ParseFrameBuffer : "<<pFrameBuffer;
    while(i < tmpCount)
    {
        switch(m_FrameState)
        {
        case State_Wait:
        {
            for(;i<tmpCount;i++)
            {
                tmpValue = (quint8)(pFrameBuffer.at(i));
                FRAME_FLAG tmpFlag = Flag_Unknow;
                if(0x80 == tmpValue)
                    tmpFlag = Flag_Normal;
                else if(0xc0 == tmpValue)
                    tmpFlag = Flag_Ack;
                if(tmpFlag != Flag_Unknow)
                {
                    if(m_CurRevFrame)
                        m_CurRevFrame->deleteLater();
                    m_CurRevFrame = new FRAME_STRUCT();
                    m_CurRevFrame->mFlag = tmpFlag;
                    m_FrameState = State_Header;
                    i++;
                    break;
                }
            }
            break;
        }
        case State_Header:
        {
            m_CurRevFrame->mType = (FRAME_TYPE)(quint8)pFrameBuffer.at(i);  //  通过不同的帧类型确定帧长度
#ifdef CRC
            m_CurRevFrame->mCRC ^= m_CurRevFrame->mType;
#endif
            switch(m_CurRevFrame->mType)
            {
            case Type_Heartbeat:
            case Type_ConfCmd:
            case Type_FileTrans:
            {
                m_FrameState = State_CmdPara;
                i++;
                break;
            }
            default:
            {
                m_FrameState = State_Wait;
                break;
            }
            }
            break;
        }
        case State_CmdPara:
        {
            m_CurRevFrame->mCmd = (quint8)pFrameBuffer.at(i);
            //IDE_TRACE_INT(m_CurRevFrame->mCmd);
            switch(m_CurRevFrame->mType)
            {
            case Type_Heartbeat:
            case Type_ConfCmd:
            {
                m_FrameState = State_DatalenH;
                i++;
                break;
            }
            case Type_FileTrans:
            {
                m_FrameState = State_AddrH;
                i++;
                break;
            }
            default:
            {
                m_FrameState = State_Wait;  //  不需要i++
                break;
            }
            }
            break;
        }
        case State_AddrH:
        {
            tmpValue = (quint8)(pFrameBuffer.at(i++));
            m_CurRevFrame->mAddr = tmpValue*256;
            m_FrameState = State_AddrL;
#ifdef CRC
            m_CurRevFrame->mCRC ^= tmpValue;
#endif
            break;
        }
        case State_AddrL:  //  查找数据长度
        {
            tmpValue = (quint8)(pFrameBuffer.at(i++));
            m_CurRevFrame->mAddr += tmpValue;
            m_FrameState = State_DatalenH;
#ifdef CRC
            m_CurRevFrame->mCRC ^= tmpValue;
#endif
            break;
        }
        case State_DatalenH:
        {
            tmpValue = (quint8)(pFrameBuffer.at(i++));
            m_CurRevFrame->mLength = tmpValue*256;
            m_FrameState = State_DatalenL;
#ifdef CRC
            m_CurRevFrame->mCRC ^= tmpValue;
#endif
            break;
        }
        case State_DatalenL:  //  查找数据长度
        {
            tmpValue = (quint8)(pFrameBuffer.at(i++));
            m_CurRevFrame->mLength += tmpValue;
            m_FrameState = State_Data;
#ifdef CRC
            m_CurRevFrame->mCRC ^= tmpValue;
#endif
            break;
        }
        case State_Data:
        {
            quint16 tmpLen = tmpCount-i;
            //IDE_TRACE_INT(tmpLen);
            if(tmpLen  >= m_CurRevFrame->mLength)
            {
                m_CurRevFrame->mData.append(pFrameBuffer.mid(i, m_CurRevFrame->mLength));
                i += m_CurRevFrame->mLength;
                m_CurRevFrame->mLength = 0;
                m_FrameState = State_CRC;
            }
            else
            {
                m_CurRevFrame->mData.append(pFrameBuffer.mid(i));
                i += tmpLen;
                m_CurRevFrame->mLength -= tmpLen;
            }
#ifdef CRC
            int tmpCount = m_CurRevFrame->mData.count();
            for(int i=0;i<tmpCount;i++)
            {
                m_CurRevFrame->mCRC ^= m_CurRevFrame->mData.at(i);
            }
#endif
            break;
        }
        case State_CRC:
        {
#ifdef CRC
            quint8 tmpCRC = (quint8)pFrameBuffer.at(i);
            if(tmpCRC != m_CurRevFrame->mCRC)
            {
                m_FrameState = State_Wait;  //  不需要i++
                break;
            }
#endif
            m_FrameState = State_Footer;
            i++;
            break;
        }
        case State_Footer:
        {
            tmpValue = (quint8)(pFrameBuffer.at(i));
            if(m_CurRevFrame->mFlag == Flag_Normal)
            {
                if(0x81 == tmpValue)  //  接收到的是正常帧
                {

                    ParseFrame(m_CurRevFrame);
                    m_CurRevFrame = 0;
                    m_FrameState = State_Wait;  //  需要i++
                    i++;
                    break;
                }
            }
            else if(m_CurRevFrame->mFlag == Flag_Ack)
            {
                if(0xc1 == tmpValue)  //  接收到的是正常帧
                {
                    //  入队列
                    ParseFrame(m_CurRevFrame);
                    m_CurRevFrame = 0;
                    m_FrameState = State_Wait;  //  需要i++
                    i++;
                    break;
                }
            }
            else
            {
                IDE_DEBUG(QString("Frame Flag is unknow[%1]").arg(m_CurRevFrame->mFlag));
            }
            m_FrameState = State_Wait;  //  不需要i++
            break;
        }
        default:
        {
            m_FrameState = State_Wait;
            break;
        }
        }
    }
    pFrameBuffer.clear();
    return 1;
}
quint32 cdcProtocol::ParseFrame(FRAME_STRUCT *pFrame)
{
    if(!pFrame)
    {
        IDE_TRACE();
        return 0;
    }
    quint32 ret = 1;
    ///IDE_TRACE();
    switch(pFrame->mType)
    {
    case Type_Heartbeat:
    {
        ret = ParseHeartbeatFrame(pFrame);
        break;
    }
    case Type_ConfCmd:
    {
        ret = ParseConfFrame(pFrame);
        break;
    }
    case Type_FileTrans:
    {
        ret = ParseFileFrame(pFrame);
        break;
    }
    default:
    {
        pFrame->deleteLater();
        return 3;
    }
    }
    return ret;
}

quint32 cdcProtocol::ParseConfFrame(FRAME_STRUCT *pFrame)
{
    if(pFrame->mData.isEmpty()){
        return 0;
    }
    m_RcvConfInfo = ConfigPayload(pFrame->mData.data());
    if(!m_RcvConfInfo.isValid()){
        IDE_TRACE();
        return 0;
    }

    if(pFrame->isRequireFrame())
    {
        //IDE_TRACE();
        //IDE_TRACE_INT(m_RcvConfInfo.mType);
        switch(m_RcvConfInfo.mType)
        {
        //配置信息，实时数据
        case SC_Init:
        {
            IDE_TRACE();
            if(m_RcvConfInfo.mSubType == SUB_Connect){
                m_RcvConfInfo.SetSuccess(true);
                ReplyConfFrame(m_RcvConfInfo, pFrame);
                helperConnected();
            }
            return 1;
        }
        case SC_Set:
        case SC_Get:
        {
            emit helperMsg(m_RcvConfInfo.jsonObj);
            m_RcvConfInfo.SetSuccess(true);
            ReplyConfFrame(m_RcvConfInfo, pFrame);
            return 1;
        }
        case SC_Cmd:
        {
            emit helperMsg(m_RcvConfInfo.jsonObj);
            m_RcvConfInfo.SetSuccess(true);
            ReplyConfFrame(m_RcvConfInfo, pFrame);
            return 1;
        }
        case SC_SendFileTest:  //从机接收到发送文件测试的指令，只要判断是否可以接收此文件即可
        {
            IDE_TRACE();
            QString tmpFilePath = m_RcvConfInfo.getpayloadValue("remotefile").toString();
            qint64 size = m_RcvConfInfo.getpayloadValue("filezise").toInt();
            if(!m_WriteFileOp->bind(tmpFilePath, size))
            {
                IDE_TRACE();
                m_RcvConfInfo.SetSuccess(false);
                ReplyConfFrame(m_RcvConfInfo, pFrame);
                return 0;
            }
            m_RcvConfInfo.SetSuccess(true);
            IDE_TRACE();
            m_FileTransState = Start;
            ReplyConfFrame(m_RcvConfInfo, pFrame);
            IDE_TRACE();
            return 1;
        }
        case SC_GetFileTest:  //  从机接收到接收文件测试的指令，需要将此文件的大小返回
        {
            QString tmpFilePath = m_RcvConfInfo.getpayloadValue("remotefile").toString();
            ///qint64 size = m_RcvConfInfo.getpayloadValue("filezise").toInt();
            QFile file(tmpFilePath);
           // IDE_TRACE_STR(tmpFilePath);
            if(!m_ReadFileOp->bind(tmpFilePath))
            {
                IDE_TRACE();
                m_RcvConfInfo.SetSuccess(false);
            }
            else
            {
                m_RcvConfInfo.setPayloadValueForKey("filesize",QJsonValue(file.size()));
                m_RcvConfInfo.SetSuccess(true);
                //IDE_TRACE_INT(file.size());
            }
            ReplyConfFrame(m_RcvConfInfo, pFrame);
            return 1;
        }
        case SC_StartGetFile:
        {
            if(m_ReadFileOp)
            {
                ///QFileInfo tmpInfo(m_ReadFileOp->mFile);
                ///emit sProgress(QString("Start Get %1 ...").arg(tmpInfo.fileName()), INVALIDRC);
            }
            m_FileTransState = Start;
            SendFileData(pFrame, true);
            return 1;
        }
        case SC_FTP:
        {
            if(m_RcvConfInfo.mSubType == SUB_CdUp){
                if(mDir.cdUp()){
                    m_RcvConfInfo.SetSuccess(true);
                }else{
                    m_RcvConfInfo.SetSuccess(false);
                }
            }else if(m_RcvConfInfo.mSubType == SUB_Cd){
                //IDE_TRACE();
                QString dir = m_RcvConfInfo.getpayloadValue("dir").toString();
                if(mDir.cd(dir)){
                    m_RcvConfInfo.SetSuccess(true);
                    //                    QJsonArray array = listDirFiles();
                    //                    if(!array.isEmpty()){
                    //                        m_RcvConfInfo.SetSuccess(true);
                    //                        m_RcvConfInfo.setPayload(array);
                    //                        m_RcvConfInfo.mSubType = SUB_Ls;
                    //                    }
                }else{
                    m_RcvConfInfo.SetSuccess(false);
                }
            }else if(m_RcvConfInfo.mSubType == SUB_Ls){
                QJsonArray array = listDirFiles();
                if(!array.isEmpty()){
                    m_RcvConfInfo.SetSuccess(true);
                    m_RcvConfInfo.setPayloadValueForKey("files",array);
                    m_RcvConfInfo.setPayloadValueForKey("dir",mDir.absolutePath());
                    m_RcvConfInfo.mSubType = SUB_Ls;
                }
            }else{
                m_RcvConfInfo.SetSuccess(false);
            }
            ReplyConfFrame(m_RcvConfInfo, pFrame);
            return 1;
        }
        default:
        {
            m_RcvConfInfo.SetSuccess(false);
            ReplyConfFrame(m_RcvConfInfo, pFrame);
            return 0;
        }
        }
    }
    else
    {
        bool success = m_RcvConfInfo.isSuccess();
        m_ConfState = Success;//  表明Setcmd已接收到响应
        IDE_TRACE_INT(m_RcvConfInfo.mType);
        switch(m_RcvConfInfo.mType)
        {
        case SC_SendFileTest:   //  主机接收到发送文件测试的响应，如果允许发送，则开始发送
        {
            if(m_FileTransState == Start )
            {
                if(success)
                {
                    ///SendFileData(pFrame, true);
                }
                else
                {
                    m_FileTransState = Failed;
                }
            }
            else
            {
                m_FileTransState = Failed;
            }
            break;
        }
        case SC_GetFileTest:   //  主机接收到接收文件测试的响应，判断文件信息是否可以接收
        {
            if(m_FileTransState == Start)
            {
                if(success)
                {
                    qint64 size = m_RcvConfInfo.getpayloadValue("filesize").toInt();
                    if(size <= 0)
                    {
                        m_FileTransState = Failed;
                        m_WaitTimeout = 0;
                        break;
                    }
                    QString tmpFile = m_RcvConfInfo.getpayloadValue("localfile").toString();
                    /*
                        if(!CheckCapacity(getFileDirectory(tmpFile), size))
                        {
                            m_FileTransState = Failed;
                            m_WaitTimeout = 0;
                            IDE_DEBUG(QString("GetFile -- dev %1 [CapacityErr]").arg(mDevType));
                            break;
                        }*/
                    if(!m_WriteFileOp->bind(tmpFile, size))
                    {
                        m_FileTransState = Failed;
                        break;
                    }
                }
                else
                {
                    m_FileTransState = Failed;
                }
            }
            else
            {
                m_FileTransState = Failed;
            }
            break;
        }
        default:
            break;
        }
        ProcConfQueue(m_RcvConfInfo, success);
        pFrame->deleteLater();
    }
    return 1;
}

QJsonArray cdcProtocol::listDirFiles()
{
    QJsonArray fileArray;
    if(mDir.exists()){
        QFileInfoList infoList = mDir.entryInfoList(QDir::Files|QDir::Dirs|QDir::NoSymLinks|QDir::NoDotAndDotDot);
        for(int i = 0;i<infoList.count();i++)
        {
            QFileInfo fileinfo = (infoList.at(i));
            QJsonObject obj;
            obj.insert("name",fileinfo.fileName());
            obj.insert("isfile",fileinfo.isDir() ? "false":"true");
            fileArray.append(QJsonValue(obj));
        }
    }
    return fileArray;
}

quint32 cdcProtocol::ParseFileFrame(FRAME_STRUCT *pFrame, bool pEmitPrg)
{
    if(pFrame->isRequireFrame())  //对方发来文件，接收
    {
        bool tmpStop = pFrame->mCmd & Flag_Stop;
        if(tmpStop)
        {
            m_WriteFileOp->unbind();
            m_FileTransState = Failed;
            pFrame->deleteLater();

            if(pEmitPrg)
                emit sProgress(m_WriteFileOp->progress());
            return 1;
        }

        quint8 tmpDataPara = pFrame->mCmd & 0x0f;       //  只检测低四位
        quint8 tmpExtPara = pFrame->mCmd & 0xf0;        //  只检测高四位
        switch(tmpDataPara)
        {
        case Flag_FileData:
        case Flag_FileFooter:
        {
            if(m_FileTransState == Start)
            {
                quint8 tmpState = 0;
                if(!(m_WriteFileOp && m_WriteFileOp->mEnable && m_WriteFileOp->write(pFrame->mData)))  //  如果mData是NULL，返回True
                {
                    tmpState = Flag_Stop;
                    m_FileTransState = Failed;
                    m_WriteFileOp->unbind();
                }
                //  清数据
                pFrame->ClearData();
                //  查看扩展参数
                if(tmpExtPara & Flag_OneTrans)  //  如果是单次传输，那么
                    tmpState = Flag_Stop;
                //  修改参数值
                pFrame->mCmd = tmpDataPara + tmpState;
            }
            else
            {
                m_FileTransState = Failed;
                pFrame->mCmd = pFrame->mCmd&0x0f + Flag_Stop;
                pFrame->ClearData();

                if(m_WriteFileOp)
                    m_WriteFileOp->unbind();
            }
            quint32 ret = ReplyFrame(pFrame);
            if(pEmitPrg)
                emit sProgress(m_WriteFileOp->progress());
            return ret;
        }
        case Flag_FileMD5:
        {
            //  不需要理会扩展参数
            //  MD5校验
            if(m_FileTransState == Start)
            {
                if(m_WriteFileOp && m_WriteFileOp->mEnable)
                {
#if 0
                    QByteArray tmpArray = m_WriteFileOp->getmd5();
                    if(tmpArray != pFrame->mData)
                    {
                        pFrame->mData = tmpArray;
                        pFrame->mCmd = pFrame->mCmd&0x0f + Flag_Stop;  //  如果不相等，返回MD5，同时置中止位
                        m_FileTransState = Failed;
                    }
                    else
                    {
                        pFrame->ClearData();
                        m_FileTransState = Success;
                    }
#else
                    pFrame->ClearData();
                    m_FileTransState = Success;
#endif
                }
                else
                {
                    pFrame->mCmd = pFrame->mCmd&0x0f + Flag_Stop;
                    pFrame->ClearData();
                    m_FileTransState = Failed;
                }
            }
            else
            {
                m_FileTransState = Failed;
                pFrame->mCmd = pFrame->mCmd&0x0f + Flag_Stop;
                pFrame->ClearData();
            }
            quint32 ret = ReplyFrame(pFrame);
            if(m_WriteFileOp)
                m_WriteFileOp->unbind();
            if(pEmitPrg)
                emit sProgress(m_WriteFileOp->progress());
            return ret;
        }
        default:
        {
            pFrame->deleteLater();
            return 0;
        }
        }
    }
    else    //  对方发来响应，根据参数启动下次发送
    {
        bool tmpStop = pFrame->mCmd & Flag_Stop;
        if(tmpStop)
        {
            IDE_TRACE();  //  不知道为什么多发了一次stop
            pFrame->deleteLater();
            m_ReadFileOp->unbind();
            m_FileTransState = Failed;

            if(pEmitPrg)
                emit sProgress(m_ReadFileOp->progress());
            return 1;
        }
        //
        quint8 tmpDataPara = pFrame->mCmd & 0x0f;       //  只检测低四位
        switch(tmpDataPara)
        {
        case Flag_FileData:
        {
            quint32 ret = 0;
            if(m_FileTransState == Start)
            {
                ret = SendFileData(pFrame, pEmitPrg);  //  函数里已经有进度信号了。
            }
            else
            {
                pFrame->deleteLater();
                m_ReadFileOp->unbind();
                m_FileTransState = Failed;

                if(pEmitPrg)
                    emit sProgress(m_ReadFileOp->progress());
            }
            return ret;//  如果上次发送文件失败，则重传, 如果是发送方，则在发送最后一帧数据时自动变化为Foot帧
        }
        case Flag_FileFooter: //  当接收到Footer响应时，表示传输完成，开始发送MD5帧
        {
            quint32 ret = 0;
            if(m_FileTransState == Start)
            {
                ret = SendFileMD5(pFrame);
                m_FileTransState = Success;
            }
            else
            {
                m_FileTransState = Failed;
                pFrame->deleteLater();

                if(m_ReadFileOp)
                    m_ReadFileOp->unbind();
            }

            //  当发送MD5响应时，表示传输成功
            if(pEmitPrg)
                emit sProgress(m_ReadFileOp->progress());
            return ret;
        }
        default:
        {
            pFrame->deleteLater();
            return 0;
        }
        }
    }
    pFrame->deleteLater();
    return 0;
}

void cdcProtocol::startInitiativeHB(){
    initiativeHBTimer->setInterval(initiativeHBInterval);
    initiativeHBTimer->start();
    initiativeHBEnabled = true;
    SendHBFrame(initiativeHBInterval,true);
}

void cdcProtocol::stopInitiativeHB(){
    initiativeHBTimer->stop();
    initiativeHBEnabled = false;
}

quint32 cdcProtocol::ParseHeartbeatFrame(FRAME_STRUCT *pFrame)
{
    if(pFrame->mFlag == Flag_Normal)  //  对方主动发来的心跳帧
    {
        ///IDE_TRACE();
        if(!initiativeHBEnabled){
            IDE_TRACE_STR("initiativeHBEnabled");
            startInitiativeHB();
        }else{
            ///IDE_TRACE();
        }
        if(pFrame->mCmd & 0x02)  // 是否响应
        {
            return ReplyHBFrame(pFrame, QByteArray());
        }
    }
    else
    {
        initiativeHBCount = 0;
    }
    pFrame->deleteLater();
    return 0;
}

quint32 cdcProtocol::ReplyHBFrame(FRAME_STRUCT *pFrame, QByteArray pContent)
{
    if(!pFrame)
    {
        pFrame = new FRAME_STRUCT;
        pFrame->mType = Type_Heartbeat;
    }
    pFrame->mData = pContent;
    //IDE_DEBUG(QString("Reply Heartbeat..."));
    return ReplyFrame(pFrame);
}

quint32 cdcProtocol::SendHBFrame(quint32 pTimeout, bool pAck)
{
    FRAME_STRUCT *tmpFrame = new FRAME_STRUCT;
    tmpFrame->mType = Type_Heartbeat;
    if(pTimeout)
    {
        tmpFrame->mCmd = 0x01;
        tmpFrame->mData.resize(4);
        tmpFrame->mData[0] = (quint8)(pTimeout >> 24)&0xff;
        tmpFrame->mData[1] = (quint8)(pTimeout >> 16)&0xff;
        tmpFrame->mData[2] = (quint8)(pTimeout >> 8)&0xff;
        tmpFrame->mData[3] = (quint8)(pTimeout)&0xff;
    }
    else
    {
        tmpFrame->mCmd = 0x00;
        tmpFrame->mData.clear();
    }
    if(pAck)
        tmpFrame->mCmd |= 0x02;
    m_HBState = Start;
    ///IDE_DEBUG(QString("Send Heartbeat[%1]...").arg(pTimeout));
    return SendFrame(tmpFrame);
}

void cdcProtocol::slot_initiativeHBTimeout(){
    initiativeHBCount ++;
    if(initiativeHBCount > 3 ){
        IDE_TRACE_STR("Helper  reply timeout");
        stopInitiativeHB();
        helperDisconnected();
    }else{
        SendHBFrame(0,true);//正常的心跳触发
    }
}

void cdcProtocol::startWork()
{
    if(!OpenCom()){
        IDE_TRACE_STR("Init cdc protocol port failed");
        comPortReopenTimer->start();
    }
}

bool cdcProtocol::sendJson(const QJsonObject &jsonObj,QString subtype){
    ConfigPayload tmpInfo;
    tmpInfo.mType = SC_Get;
    tmpInfo.mSubType = strTosubType(subtype);
    tmpInfo.setPayload(jsonObj);

    FRAME_STRUCT *tmpFrame = new FRAME_STRUCT;
    tmpFrame->mType = Type_ConfCmd;
    tmpFrame->mData = tmpInfo.toFrame();
    return ReplyFrame(tmpFrame);
    IDE_TRACE();
}

quint32 cdcProtocol::SendConfFrame(QString pInstruc)
{
    m_ConfState = Start;
    FRAME_STRUCT *tmpFrame = new FRAME_STRUCT;
    tmpFrame->mType = Type_ConfCmd;
    tmpFrame->mCmd = 0x01;
    tmpFrame->mData = pInstruc.toUtf8();
    return SendFrame(tmpFrame);
}

quint32 cdcProtocol::ReplyConfFrame(ConfigPayload obj, FRAME_STRUCT* pFrame)
{

    pFrame->mData = obj.toFrame();
    return ReplyFrame(pFrame);
}

quint32 cdcProtocol::SendFileData(FRAME_STRUCT* pPreFrame, bool pEmitPrg)
{
    if(!pPreFrame)
        return 0;
    FRAME_STRUCT *tmpFrame = pPreFrame;
    if(tmpFrame->mType == Type_FileTrans && tmpFrame->mCmd & 0x03)  //查看是否为Data或者Footer
    {
        bool tmpReTrans = tmpFrame->mCmd & Flag_ReTrans;
        bool tmpOneTrans = tmpFrame->mCmd & Flag_OneTrans;
        if(!tmpReTrans && !tmpOneTrans)  //如果上帧有错误或者需要断点续传，会返回断点续传位，则发送帧计数的数据段
            tmpFrame->mAddr++;
        tmpFrame->mCmd = Flag_FileData;
    }
    else
    {
        //  如果上一帧不为有效的数据帧，则认为是第一次传输
        tmpFrame->mType = Type_FileTrans;
        tmpFrame->mCmd = Flag_FileData;
        tmpFrame->mAddr = 0;
    }
    tmpFrame->ClearData();
    //  如果文件错误，则发送Stop命令， 从第0帧开始发送
    if(m_ReadFileOp && m_ReadFileOp->mEnable)
    {
        m_ReadFileOp->setpos(tmpFrame->mAddr*m_MaxBlockSize);
        if(m_ReadFileOp->mSurplus > m_MaxBlockSize)
        {
            if(m_ReadFileOp->read(m_MaxBlockSize))
                tmpFrame->mCmd = (tmpFrame->mCmd & 0xf0) + Flag_FileData;
            else
                tmpFrame->mCmd = (tmpFrame->mCmd & 0x0f) + Flag_Stop;
        }
        else
        {
            if(m_ReadFileOp->read(m_ReadFileOp->mSurplus))   //  如果要读取的数据个数为0，返回false
                tmpFrame->mCmd = (tmpFrame->mCmd & 0xf0) + Flag_FileFooter;
            else
                tmpFrame->mCmd = (tmpFrame->mCmd & 0x0f) + Flag_Stop;
        }
        tmpFrame->mData = m_ReadFileOp->mCurPack;
    }
    else
    {
        tmpFrame->mCmd = (tmpFrame->mCmd & 0x0f) + Flag_Stop;
    }
    quint32 ret = SendFrame(tmpFrame);
    if(pEmitPrg && m_ReadFileOp)
        emit sProgress(m_ReadFileOp->progress());
    return ret;
}

quint32 cdcProtocol::SendFileMD5(FRAME_STRUCT* pPreFrame)
{
    if(!pPreFrame)
        return 0;
    FRAME_STRUCT *tmpFrame = pPreFrame;
    if(tmpFrame->mType == Type_FileTrans && tmpFrame->mCmd & 0x03)  //  查看是否为Data或者Footer
    {
        bool tmpReTrans = tmpFrame->mCmd & Flag_ReTrans;
        bool tmpOneTrans = tmpFrame->mCmd & Flag_OneTrans;
        if(tmpReTrans || tmpOneTrans)  //  如果上帧有错误或者需要断点续传，会返回断点续传位，则发送帧计数的数据段
            return SendFileData(tmpFrame, false);
        tmpFrame->mCmd = Flag_FileMD5;
    }
    else
    {
        //  如果上一帧不为有效的数据帧，则认为是第一次传输
        tmpFrame->mType = Type_FileTrans;
        tmpFrame->mCmd = Flag_FileMD5;
        tmpFrame->mAddr = 0;
    }
    tmpFrame->ClearData();
    //  如果文件错误，则发送Stop命令
    if(m_ReadFileOp && m_ReadFileOp->mEnable)
    {
        tmpFrame->mData = m_ReadFileOp->getmd5();
    }
    else
    {
        tmpFrame->mCmd += Flag_Stop;
    }
    return SendFrame(tmpFrame);
}

bool cdcProtocol::SendFile(QString pSrc, QString pDst)
{
    m_FileTransState = Start;
    ConfigPayload tmpInfo;
    tmpInfo.mType = SC_SendFileTest;
    QJsonObject obj;
    obj.insert("remotefile","1.zip");
    obj.insert("localfile","1.zip");
    tmpInfo.setPayload(obj);
    PushConfQueue(tmpInfo);
    return true;
}

bool cdcProtocol::GetFile(QString pSrc, QString pDst)
{
    ConfigPayload tmpInfo;
    tmpInfo.mType = SC_GetFileTest;
    QJsonObject obj;
    obj.insert("remotefile","1.zip");
    obj.insert("localfile","1.zip");
    tmpInfo.setPayload(obj);
    PushConfQueue(tmpInfo);
    return true;
}

void cdcProtocol::StartGetFile()
{
    ConfigPayload tmpInfo;
    tmpInfo.mType = SC_StartGetFile;
    PushConfQueue(tmpInfo);
}

void cdcProtocol::PushConfQueue(ConfigPayload pInfo)
{
    if(pInfo.mType == SC_Unknow)
        return;
    if(m_ConfQueue.isEmpty())
    {
        m_ConfQueue.enqueue(pInfo);
        SendConfFrame(pInfo.toFrame());
    }
    else
    {
        m_ConfQueue.enqueue(pInfo);
    }
}

quint32 cdcProtocol::ProcConfQueue(ConfigPayload &pInfo, bool pSuccess)
{
    if(m_ConfQueue.isEmpty())
        return 0;
    ConfigPayload tmpInfo = m_ConfQueue.head();  //  获取当前正在执行的缓冲指令
    if(tmpInfo.mType != pInfo.mType) //  查看当前处理的指令是否为缓冲区的当前指令
    {
        IDE_TRACE_INT(tmpInfo.mType);
        return 2;
    }

    m_ConfQueue.dequeue();

    // 当前指令收到响应后，发送下一条指令
    if(!m_ConfQueue.isEmpty())
        SendConfFrame(m_ConfQueue.head().toFrame());
    return 1;
}
