#ifndef WRITEFILEOP_H
#define WRITEFILEOP_H

#include <QObject>
#include <QFile>
#include <QDir>

class WriteFileOp : public QObject
{
    Q_OBJECT
public:
    explicit WriteFileOp(QObject *parent = 0);
    ~WriteFileOp();

    void unbind();
    bool bind(QString pSrc, qint64 pSize);
    bool write(QByteArray pByteArray, qint64 pPos=-1);
    bool repair();
    int progress();
    QByteArray getmd5() {return QByteArray();}
public:
    bool        mEnable;
    QFile       mFile;
    qint64      mSize;
    qint64      mPos;
    qint64      mSurplus;
};

#endif // WRITEFILEOP_H
