#ifndef CONFIGPAYLOAD_H
#define CONFIGPAYLOAD_H

#include <QObject>
#include <QJsonDocument>
#include <QJsonObject>
#include "protocldefine.h"

class ConfigPayload
{

public:
    ConfigPayload();
    ConfigPayload(QByteArray json);

    bool isValid();
    bool isSuccess();
    void SetSuccess(bool pFlag);

    QJsonValue getpayloadValue(QString key);
    QJsonObject payload();
    void setPayload(QJsonValue payload);
    QByteArray toFrame();
    bool operator&(const ConfigPayload &s) const;
    bool operator==(const ConfigPayload &s) const;
    bool operator!=(const ConfigPayload &s) const;
    ConfigPayload& operator=(const ConfigPayload &s);
    ConfigPayload& operator=(const QByteArray &json);
    void fromData(QByteArray json);
public:
    bool  isValidFrame;
    QJsonObject jsonObj;
    SETCMD_TYPE mType;
    SUBTYPE_TYPE mSubType;

    void setPayloadValueForKey(QString key, QJsonValue value);
};

#endif // CONFIGPAYLOAD_H
