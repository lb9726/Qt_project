#include "configpayload.h"
#include "../define.h"

ConfigPayload::ConfigPayload()
{
    isValidFrame = false;
}

ConfigPayload::ConfigPayload(QByteArray json)
{
    fromData(json);
}

void ConfigPayload::fromData(QByteArray json)
{
    QJsonDocument doc = QJsonDocument::fromJson(json, NULL);
    if(doc.isNull()){
        isValidFrame = false;
        return;
    }else{
        isValidFrame = true;
    }
    jsonObj = doc.object();

    if(jsonObj.contains("type")){
        if(jsonObj.contains("type")){
            QString msgType = jsonObj.value("type").toString();
            mType = StrToSCType(msgType);
        }else{
            mType =  SC_Unknow;
        }
    }else{
        mType =  SC_Unknow;
    }

    if(jsonObj.contains("subtype")){
        if(jsonObj.contains("subtype")){
            QString msgType = jsonObj.value("subtype").toString();
            mSubType = strTosubType(msgType);
        }else{
            mSubType =  SUB_Unknow;
        }
    }else{
        mSubType =  SUB_Unknow;
    }
}

QJsonValue ConfigPayload::getpayloadValue(QString key)
{
    QJsonObject obj = jsonObj.value("payload").toObject();
    if(!obj.isEmpty()&&obj.contains(key)){
        return obj.value(key);
    }else{
        return QJsonValue();
    }
}

void ConfigPayload::setPayloadValueForKey(QString key, QJsonValue value)
{
    QJsonObject obj = jsonObj.value("payload").toObject();
    if(!obj.isEmpty()){
        obj.insert(key,value);
        jsonObj.insert("payload",obj);
    }else{
        QJsonObject obj2;
        obj2.insert(key,value);
        jsonObj.insert("payload",obj2);
    }
}

bool ConfigPayload::isSuccess()
{
    if(jsonObj.contains("result")){
        int result = jsonObj.value("result").toInt(0);
        return  result == 0 ? false : true;
    }else{
        return false;
    }
}

void ConfigPayload::SetSuccess(bool pFlag)
{
    jsonObj.insert("result",QJsonValue(pFlag ? 1:0));
}

QByteArray ConfigPayload::toFrame()
{
    QString  type = SCTypeToStr(mType);
    if(type.isEmpty()){
        return QByteArray();
    }else{
        QString  subtype = subTypeToString(mSubType);
        if(!subtype.isEmpty()){
            jsonObj.insert("subtype",subtype);
        }
        jsonObj.insert("type",type);
        QJsonDocument doc(jsonObj);
        return doc.toJson(QJsonDocument::Compact);
    }
}

bool ConfigPayload::operator&(const ConfigPayload &s) const
{
    if(mType == s.mType)
        return true;
    return false;
}

bool ConfigPayload::operator==(const ConfigPayload &s) const
{
    if(jsonObj == s.jsonObj)
        return true;
    return false;
}

bool ConfigPayload::operator!=(const ConfigPayload &s) const
{
    return !operator==(s);
}

ConfigPayload &ConfigPayload::operator=(const QByteArray &json)
{
    fromData(json);
    return *this;
}

ConfigPayload &ConfigPayload::operator=(const ConfigPayload &s)
{
    jsonObj = s.jsonObj;
    mType = s.mType;
    mSubType = s.mSubType;
    isValidFrame = s.isValidFrame;
    return *this;
}

QJsonObject ConfigPayload::payload(){
    return jsonObj.value("payload").toObject();
}

void ConfigPayload::setPayload(QJsonValue payload)
{
    jsonObj.insert("payload",payload);
}

bool ConfigPayload::isValid()
{
    return isValidFrame;
}
