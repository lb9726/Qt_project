#include "readfileop.h"
#include "../define.h"

ReadFileOp::ReadFileOp(QObject *parent) : QObject(parent)
{
    mEnable = false;
    unbind();
}

ReadFileOp::~ReadFileOp()
{
    unbind();
}
void ReadFileOp::unbind()
{
    if(mFile.isOpen()){
        mFile.close();
    }
    if(mEnable)
    {
        mEnable = false;
        mCurPack.clear();
        mSize = mPos = mSurplus = 0;
    }
}
bool ReadFileOp::bind(QString pSrc)
{
    unbind();
    if(!QFile::exists(pSrc))
    {
        IDE_TRACE_STR(pSrc);
        return false;
    }
    mFile.setFileName(pSrc);
    if(!mFile.open(QIODevice::ReadOnly))
    {
        IDE_TRACE();
        return false;
    }
    mSurplus = mSize = mFile.size();
    mEnable = true;

    return true;
}
void ReadFileOp::setpos(qint64 pPos)
{
    if(pPos > mSize)
        mPos = mSize;
    else
        mPos = pPos;
    mSurplus = mSize - mPos;
}
bool ReadFileOp::read(qint64 maxlen)
{
    if(!mEnable)
        return false;
    mCurPack.clear();
    if(maxlen <= 0)
        return false;
    if(mPos >= mSize)
    {
        IDE_TRACE();
        return false;
    }

    bool flag = false;
    if(mFile.seek(mPos))
    {
        flag = true;
        mCurPack = mFile.read(maxlen);
    }
    mPos = mFile.pos();
    mSurplus = mSize - mPos;
    ///mFile.close();
    return flag;
}
int ReadFileOp::progress()
{
    int tmpProg = 0;
    if(mEnable)
    {
        if(mSize > 0 && mPos > 0)
        {
            int div = mSize/100;
            if(div > 0)
                tmpProg = mPos / div;
        }
    }
    return tmpProg;
}
