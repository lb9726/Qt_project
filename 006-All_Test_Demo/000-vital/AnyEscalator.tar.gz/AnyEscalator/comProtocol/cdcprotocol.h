#ifndef CDCPROTOCOL_H
#define CDCPROTOCOL_H

#include <QObject>
#include <QSerialPort>
#include <QTimer>
#include <QTcpServer>
#include <QMap>
#include <QTcpSocket>
#include <QFile>
#include <QFileInfo>
#include <QFileInfoList>
#include <QDir>
#include <QQueue>
#include <QJsonDocument>
#include <QJsonObject>
#include "define.h"
#include "protocldefine.h"
#include "readfileop.h"
#include "writefileop.h"
#include "configpayload.h"
#include "frame_struct.h"
#include <QJsonArray>
class cdcProtocol : public QObject
{
    Q_OBJECT
public:
    explicit cdcProtocol(QObject *parent = 0);

    quint32 SendData(FRAME_STRUCT *pFrame);
    quint32 SendFrame(FRAME_STRUCT *pFrame);
    quint32 ReplyFrame(FRAME_STRUCT *pFrame);

    quint32 ParseFrameBuffer(QByteArray pFrameBuffer);
    quint32 ParseFrame(FRAME_STRUCT *pFrame);
    quint32 ParseHeartbeatFrame(FRAME_STRUCT *pFrame);
    //quint32 ParseConfFrame(FRAME_STRUCT *pFrame);
    quint32 ParseFileFrame(FRAME_STRUCT *pFrame, bool pEmitPrg=true);

    quint32 SendFileData(FRAME_STRUCT* pPreFrame, bool pEmitPrg=false);
    quint32 SendFileMD5(FRAME_STRUCT* pPreFrame);

    bool SendConfFrame(QString pInstruc, int pTimeout);
    ///quint32 ReplyConfFrame(QJsonObject obj, FRAME_STRUCT* pFrame);
    quint32 SendConfFrame(QString pInstruc);

    void PushConfQueue(ConfigPayload pInfo);
    quint32 ProcConfQueue(ConfigPayload &pInfo, bool pSuccess);

    void StartGetFile();
    bool SendFile(QString pSrc, QString pDst);
    bool GetFile(QString pSrc, QString pDst);

    quint32 ReplyHBFrame(FRAME_STRUCT *pFrame, QByteArray pContent);
    quint32 SendHBFrame(quint32 pTimeout, bool pAck);

    void SetMaxBlock(qint64 pSize) { m_MaxBlockSize = pSize; }

    quint32 ParseConfFrame(FRAME_STRUCT *pFrame);
    quint32 ReplyConfFrame(ConfigPayload obj, FRAME_STRUCT *pFrame);

    void slot_HB(quint32 pTimeout);
    void slot_HBTimeout(quint32 pID);
    bool WaitHB(quint32 pTimeout);
    bool HB(quint32 pTimeout, bool pWait);
private slots:
    void newConnectSlot();
    void readMessage();
    void clientDisconnected();

signals:
    void sProgress(int);

    void sigConnect();
    void sigDisconnect();
    void helperMsg(QJsonObject jsonObj);
public:
    QQueue<ConfigPayload>      m_ConfQueue;
    FRAME_STATE             m_FrameState;
    qint64                  m_MaxBlockSize;
    QHash<QString, QString> m_DevInfoList;
    FRAME_STRUCT           *m_CurRevFrame;
    FRAME_STRUCT           *m_CurSendFrame;
    ReadFileOp             *m_ReadFileOp;
    WriteFileOp            *m_WriteFileOp;
    ConfigPayload           m_RcvConfInfo;
    ConfigPayload           m_SendConfInfo;

    qint64                  m_WaitTimeout;
    quint32                 m_QueueProgress;
    QStringList             m_LsFileList;

    TaskState               m_FileTransState;
    TaskState               m_ConfState;
    TaskState               m_SetTaskState;
    TaskState               m_GetTaskState;
    TaskState               m_DevInfoTaskState;
    TaskState               m_HBState;
    TaskState               m_SendDirTaskState;
    TaskState               m_GetDirTaskState;

    bool isConnected;
    QTcpServer *m_pTcpServer;
    QTcpSocket *m_pTcpSocket;
    void initTcpTest(int port);

    bool initiativeHBEnabled;
    quint32 initiativeHBCount;
    QTimer* initiativeHBTimer;
    quint32 initiativeHBInterval;
    void startInitiativeHB();
    void stopInitiativeHB();

    QDir mDir;
    QJsonArray listDirFiles();
    void init();
    void helperConnected();
    void helperDisconnected();

    QSerialPort  *m_comPort;
    bool OpenCom();

    QTimer* comPortReopenTimer;
public slots:
    void slot_initiativeHBTimeout();
    void startWork();
    bool sendJson(const QJsonObject &jsonObj, QString subtype);
    void comportError(QSerialPort::SerialPortError error);//

};

#endif // CDCPROTOCOL_H
