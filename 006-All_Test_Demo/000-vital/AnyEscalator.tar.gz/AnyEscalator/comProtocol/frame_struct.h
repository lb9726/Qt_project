#ifndef FRAME_STRUCT_H
#define FRAME_STRUCT_H

#include <QObject>
#include "protocldefine.h"

class FRAME_STRUCT : public QObject
{
    Q_OBJECT
public:
    explicit FRAME_STRUCT(QObject *parent = 0);
    void ClearData();
    bool isRequireFrame();
public:
    FRAME_FLAG                  mFlag;  //>@主从机
    FRAME_TYPE                  mType;
    quint8                      mCmd;
    quint16                     mAddr; //>@帧计数，也可以理解为（文件/寄存器)地址
    quint16                     mLength;  //>@一般用于接收数据计数
    QByteArray                  mData;  //>@包大小，通过mData计算出来
    quint8                      mCRC;
    quint32                     mError; //>@帧执行的错误类型
} ;


#endif // FRAME_STRUCT_H
