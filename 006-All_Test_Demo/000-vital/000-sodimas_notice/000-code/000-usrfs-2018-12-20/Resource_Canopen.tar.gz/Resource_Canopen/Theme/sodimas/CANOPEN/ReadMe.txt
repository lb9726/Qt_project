It's just to match window app (仅仅是为了适配window app)
