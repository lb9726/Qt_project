#include "uivideo.h"

UiVideo::UiVideo(QWidget* parent, Qt::WindowFlags f)
    :QWidget(parent,f)
{

}
