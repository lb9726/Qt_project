#include "uifloor.h"
#include "define.h"
#include "mainwindow.h"
#include <QFont>
#include <QDebug>

UiFloor::UiFloor(QWidget* parent, Qt::WindowFlags f)
    :QWidget(parent, f)
{
    mHundred = 0;
    mTen = 0;
    mSingle = 0;
    mFloorMapLabel = 0;
    isSafFlag = true;
}

void UiFloor::Init(QDomElement pElement)
{
    bool tmpFlag = isVisible();
    QRect tmpRect = gUiLoader->m_themeParser->getComRect(gUiLoader->m_themeLayout, pElement, gUiLoader->m_themeDirection);

    if(!tmpFlag)
    {
        this->setVisible(false);
    }

    mHundLabel = this->findChild<QLabel *>("Hundred");
    if(mHundLabel)
    {
        mHundLabel->setScaledContents(true);
    }
    mTenLabel = this->findChild<QLabel *>("Ten");
    if(mTenLabel)
    {
        mTenLabel->setScaledContents(true);
    }
    mSingleLabel = this->findChild<QLabel *>("Single");
    if(mSingleLabel)
    {
        mSingleLabel->setScaledContents(true);
    }

    /*floor map */
    mFloorMapLabel = this->findChild<QLabel *>("mapLabel");
    if(mFloorMapLabel)
    {
        mFloorMapLabel->setScaledContents(true);
    }

    mTimeText = this->findChild<QLabel *>("label_time");
    mDestText = this->findChild<QLabel *>("label_dest");
    QFont font;
    font.setPixelSize(15);
    if (mTimeText)
    {
        mTimeText->setFont(font);
    }
    if (mDestText)
    {
        mDestText->setFont(font);
    }

    tmpRect.setHeight(tmpRect.height() + mTimeText->height() + mDestText->height());
    this->setGeometry(tmpRect);

    if (mDestText)
    {
        mDestText->setAlignment(Qt::AlignCenter);
        mDestText->setGeometry(0, 162, 240, 20);
    }
    if (mTimeText)
    {
        mTimeText->setAlignment(Qt::AlignCenter);
        mTimeText->setGeometry(0, 185, 240, 20);
    }

    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<mTimeText->geometry();
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<mDestText->geometry();
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<"floor's geometry "<<this->geometry();
    QString tmpThemePath = gUiLoader->m_themeParser->m_FileDir;

    QDomElement tmpRcElement = pElement.firstChildElement("resource");
    QDomNodeList tmpList = tmpRcElement.childNodes();
    for(int i = 0; i<tmpList.count(); ++i)
    {
        QDomElement tmpElement = tmpList.at(i).toElement();
        if(tmpElement.isNull())
        {
            continue;
        }
        QString tmpTagName = tmpElement.tagName();
        int tmpNum = tmpTagName.mid(2).toInt();
        mRcHash.insert(tmpNum, tmpThemePath + tmpElement.text());
    }
    /*floor map*/
    QDomElement tmpRcElement1 = pElement.firstChildElement("Map");
    if(!tmpRcElement1.isNull())
    {
        QDomNodeList tmpList1 = tmpRcElement1 .childNodes();
        for(int i = 0; i < tmpList1.count(); i++)
        {
            QDomElement tmpElement = tmpList1.at(i).toElement();
            if(tmpElement.isNull())
            {
                continue;
            }
            QString tmpTagName = tmpElement.tagName();
            int tmpNum = tmpTagName.mid(2).toInt();
            mFloorHash.insert(tmpNum,tmpElement.text());
            //qDebug()<<"mFloorHash tmpNum = "<<tmpNum;
            //qDebug()<<"mFloorHash tmpElement.text = "<<tmpElement.text();
        }
    }
    updateFloor();//确保更改图片后，能立即刷新到当前的显示内容上
}
//floor map
void UiFloor::initAudio(QDomElement pElement)
{
    QDomElement tmpRcElement = pElement.firstChildElement("Map");
    if(!tmpRcElement.isNull())
    {
        QDomNodeList tmpList = tmpRcElement.childNodes();
        for(int i=0; i<tmpList.count(); i++)
        {
            QDomElement tmpElement = tmpList.at(i).toElement();
            if(tmpElement.isNull())
                continue;
            QString tmpTagName = tmpElement.tagName();
            int tmpNum = tmpTagName.mid(2).toInt();
            mAudioHash.insert(tmpNum, tmpElement.text());
            //qDebug()<<"mAudioHash tmpNum = "<<tmpNum;
            //qDebug()<<"mAudioHash tmpElement.text = "<<tmpElement.text();
        }
    }
}

void UiFloor::updateFloor()
{
    if (isSafFlag) // is Saf protocol
    {
        if(mHundred == 48)
        {
            if(mTen == 48)
            {
                mHundLabel->setGeometry(24, 0, 0, 0);
                mTenLabel->setGeometry(90, 0, 0, 0);
                mSingleLabel->setGeometry(156, 0, 0, 0);

                mHundLabel->setFixedSize(66, 154);
                mTenLabel->setFixedSize(66, 154);
                mSingleLabel->setFixedSize(66, 154);

                mHundLabel->setPixmap(QPixmap());
                mTenLabel->setPixmap(mRcHash.value(mSingle));
                mSingleLabel->setPixmap(QPixmap());
                if (mFloorMapLabel)
                {
                    mFloorMapLabel->setPixmap(QPixmap());
                }
            }
            else
            {
                mHundLabel->setGeometry(24, 0, 0, 0);
                mTenLabel->setGeometry(57, 0, 0, 0);
                mSingleLabel->setGeometry(123, 0, 0, 0);

                mHundLabel->setFixedSize(0, 0);
                mTenLabel->setFixedSize(66, 154);
                mSingleLabel->setFixedSize(66, 154);

                mHundLabel->setPixmap(QPixmap());
                mTenLabel->setPixmap(mRcHash.value(mTen));
                mSingleLabel->setPixmap(mRcHash.value(mSingle));
                if (mFloorMapLabel)
                {
                    mFloorMapLabel->setPixmap(QPixmap());
                }
            }
        }
        else
        {
            mHundLabel->setGeometry(24, 0, 0, 0);
            mTenLabel->setGeometry(90, 0, 0, 0);
            mSingleLabel->setGeometry(156, 0, 0, 0);

            mHundLabel->setFixedSize(66, 154);
            mTenLabel->setFixedSize(66, 154);
            mSingleLabel->setFixedSize(66, 154);

            mHundLabel->setPixmap(mRcHash.value(mHundred));
            mTenLabel->setPixmap(mRcHash.value(mTen));
            mSingleLabel->setPixmap(mRcHash.value(mSingle));
            if (mFloorMapLabel)
            {
                mFloorMapLabel->setPixmap(QPixmap());
            }
        }
    }
    else //  canopen
    {
        if (95 == mHundred && 95 == mTen && 95 == mSingle)
        {
            mHundLabel->setPixmap(QPixmap());
            mTenLabel->setPixmap(QPixmap());
            mSingleLabel->setPixmap(QPixmap());
            return;
        }
        if (48 == mHundred && 95 == mTen && 95 == mSingle) // T95.png is empty
        {
            mHundLabel->setGeometry(24, 0, 0, 0);
            mTenLabel->setGeometry(90, 0, 0, 0);
            mSingleLabel->setGeometry(156, 0, 0, 0);

            mHundLabel->setFixedSize(66, 154);
            mTenLabel->setFixedSize(66, 154);
            mSingleLabel->setFixedSize(66, 154);

            mHundLabel->setPixmap(mRcHash.value(mHundred));
            mTenLabel->setPixmap(mRcHash.value(mTen));
            mSingleLabel->setPixmap(mRcHash.value(mSingle));
            return;
        }
        if (mHundred == 256)
        {
            if (mTen == 256)
            {
                mHundLabel->setGeometry(24, 0, 0, 0);
                mTenLabel->setGeometry(90, 0, 0, 0);
                mSingleLabel->setGeometry(156, 0, 0, 0);

                mHundLabel->setFixedSize(66, 154);
                mTenLabel->setFixedSize(66, 154);
                mSingleLabel->setFixedSize(66, 154);

                mHundLabel->setPixmap(QPixmap());
                mTenLabel->setPixmap(mRcHash.value(mSingle));
                mSingleLabel->setPixmap(QPixmap());
                if (mFloorMapLabel)
                {
                    mFloorMapLabel->setPixmap(QPixmap());
                }
            }
            else
            {
                mHundLabel->setGeometry(24, 0, 0, 0);
                mTenLabel->setGeometry(57, 0, 0, 0);
                mSingleLabel->setGeometry(123, 0, 0, 0);

                mHundLabel->setFixedSize(0, 0);
                mTenLabel->setFixedSize(66, 154);
                mSingleLabel->setFixedSize(66, 154);

                mHundLabel->setPixmap(QPixmap());
                mTenLabel->setPixmap(mRcHash.value(mTen));
                mSingleLabel->setPixmap(mRcHash.value(mSingle));
                if (mFloorMapLabel)
                {
                    mFloorMapLabel->setPixmap(QPixmap());
                }
            }
        }
        else
        {
            mHundLabel->setGeometry(24, 0, 0, 0);
            mTenLabel->setGeometry(90, 0, 0, 0);
            mSingleLabel->setGeometry(156, 0, 0, 0);

            mHundLabel->setFixedSize(66, 154);
            mTenLabel->setFixedSize(66, 154);
            mSingleLabel->setFixedSize(66, 154);

            mHundLabel->setPixmap(mRcHash.value(mHundred));
            mTenLabel->setPixmap(mRcHash.value(mTen));
            mSingleLabel->setPixmap(mRcHash.value(mSingle));
            if (mFloorMapLabel)
            {
                mFloorMapLabel->setPixmap(QPixmap());
            }
        }
    }
}

void UiFloor::setFloor(int pGe, int pShi, int pBai, int frameCount)
{
    int key = getFloorHashKey(frameCount);//floor map
    QString mFloorHashValue = mFloorHash.value(key);

    if(mFloorHashValue.count() == 6)
    {
        mHundred = pBai + 48;
        mTen = pShi + 48;
        mSingle = pGe + 48;
        if(frameCount == 61)
        {
             mHundred = 48;
             mTen = 82;
             mSingle = 66;
        }
        else if(frameCount == 62)
        {
             mHundred = 48;
             mTen = 48;
             mSingle = 80;
        }
        else if(frameCount == 63)
        {
             mHundred = 48;
             mTen = 48;
             mSingle = 76;
        }
        else if(frameCount == 64)
        {
             mHundred = 48;
             mTen = 82;
             mSingle = 72;
        }
        else if(frameCount == 65)
        {
             mHundred = 48;
             mTen = 48;
             mSingle = 72;
        }
        else if(frameCount == 66)
        {
             mHundred = 48;
             mTen = 82;
             mSingle = 74;
        }
        else if(frameCount == 67)
        {
             mHundred = 48;
             mTen = 69;
             mSingle = 83;
        }
        else if(frameCount == 68)
        {
             mHundred = 48;
             mTen = 82;
             mSingle = 67;
        }
        else if(frameCount == 69)
        {
             mHundred = 48;
             mTen = 48;
             mSingle = 84;
        }
        updateFloor();
    }
    else
    {
        //qDebug()<<"mFloorHashValue = "<<mFloorHashValue;
        updateMap(mFloorHashValue);
    }
}

void UiFloor::setTimeAndDest(QString dest, QString time)
{
    if (mDestText && mTimeText)
    {
        mDestText->setText(dest);
        mTimeText->setText(time);
    }
}

//floor map
QString UiFloor::setMapMedia(int key)
{
    QString keyString = QString::number(key);
    QString audioHashValue = mAudioHash.value(key);
    if(keyString != audioHashValue)
    {
        QString path = gUiLoader->m_themeParser->m_FileDir + QString("media/M%1.wav").arg(audioHashValue);
        return path;
    }

    return "false";
}

//floor map
int UiFloor::getFloorHashKey(int frame)
{
    //qDebug()<<"frame = "<<frame;
    int safFrame = frame;
    int key = 1000;
    if(safFrame == 0)
    {
        key = 323248;
    }
    else if(safFrame == 1)
    {
        key = 323249;
    }
    else if(safFrame == 2)
    {
        key = 323250;
    }
    else if(safFrame == 3)
    {
        key = 323251;
    }
    else if(safFrame == 4)
    {
        key = 323252;
    }
    else if(safFrame == 5)
    {
        key = 323253;
    }
    else if(safFrame == 6)
    {
        key = 323254;
    }
    else if(safFrame == 7)
    {
        key = 323255;
    }
    else if(safFrame == 8)
    {
        key = 323256;
    }
    else if(safFrame == 9)
    {
        key = 323257;
    }
    else if(safFrame == 10)
    {
        key = 324948;
    }
    else if(safFrame == 11)
    {
        key = 324949;
    }
    else if(safFrame == 12)
    {
        key = 324950;
    }
    else if(safFrame == 13)
    {
        key = 324951;
    }
    else if(safFrame == 14)
    {
        key = 324952;
    }
    else if(safFrame == 15)
    {
        key = 324953;
    }
    else if(safFrame == 16)
    {
        key = 324954;
    }
    else if(safFrame == 17)
    {
        key = 324955;
    }
    else if(safFrame == 18)
    {
        key = 324956;
    }
    else if(safFrame == 19)
    {
        key = 324957;
    }
    else if(safFrame == 21)
    {
        key = 324549;
    }
    else if(safFrame == 22)
    {
        key = 324550;
    }
    else if(safFrame == 23)
    {
        key = 324551;
    }
    else if(safFrame == 24)
    {
        key = 324552;
    }
    else if(safFrame == 25)
    {
        key = 324553;
    }
    else if(safFrame == 26)
    {
        key = 324554;
    }
    else if(safFrame == 27)
    {
        key = 324555;
    }
    else if(safFrame == 28)
    {
        key = 324556;
    }
    else if(safFrame == 29)
    {
        key = 324557;
    }
    else if(safFrame == 30)
    {
        key = 325048;
    }
    else if(safFrame == 31)
    {
        key = 325049;
    }
    else if(safFrame == 32)
    {
        key = 325050;
    }
    else if(safFrame == 33)
    {
        key = 325051;
    }
    else if(safFrame == 34)
    {
        key = 325052;
    }
    else if(safFrame == 35)
    {
        key = 325053;
    }
    else if(safFrame == 36)
    {
        key = 325054;
    }
    else if(safFrame == 37)
    {
        key = 325055;
    }
    else if(safFrame == 38)
    {
        key = 325056;
    }
    else if(safFrame == 39)
    {
        key = 325057;
    }
    else if(safFrame == 61)
    {
        key = 325449;
    }
    else if(safFrame == 62)
    {
        key = 325450;
    }
    else if(safFrame == 63)
    {
        key = 325451;
    }
    else if(safFrame == 64)
    {
        key = 325452;
    }
    else if(safFrame == 65)
    {
        key = 325453;
    }
    else if(safFrame == 66)
    {
        key = 325454;
    }
    else if(safFrame == 67)
    {
        key = 325455;
    }
    else if(safFrame == 68)
    {
        key = 325456;
    }
    else if(safFrame == 69)
    {
        key = 325457;
    }
    return key;
}

void UiFloor::updateMap(QString path)
{
    QString tmpThemePath = gUiLoader->m_themeParser->m_FileDir;
    QString path1 = tmpThemePath + "floor/" + "T" + path + ".png";
    //qDebug()<<"floor map path1 = "<<path1;
    if (mFloorMapLabel)
    {
        mFloorMapLabel->setGeometry(0, 0, 0, 0);
        mFloorMapLabel->setFixedSize(200, 200);
        mFloorMapLabel->setPixmap(path1);
    }

    mHundLabel->setPixmap(QPixmap());
    mTenLabel->setPixmap(QPixmap());
    mSingleLabel->setPixmap(QPixmap());
}

void UiFloor::setIsSafFlag(bool value)
{
    isSafFlag = value;
}

int UiFloor::getGeWei()
{
    return mSingle - 48;
}

int UiFloor::getShiWei()
{
    return mTen - 48;
}

int UiFloor::getBaiWei()
{
    return mHundred - 48;
}

void UiFloor::setEmptyFloor()
{
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"clear floor";
    mHundLabel->setPixmap(QPixmap());
    mTenLabel->setPixmap(QPixmap());
    mSingleLabel->setPixmap(QPixmap());
}

void UiFloor::setSmallTextEmpty()
{
    if (mDestText && mTimeText)
    {
        mDestText->clear();
        mTimeText->clear();
    }
}
