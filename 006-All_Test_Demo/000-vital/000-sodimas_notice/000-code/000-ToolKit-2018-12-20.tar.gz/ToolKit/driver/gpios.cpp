#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <poll.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include "gpios.h"
#include <QDebug>
#include "common/define.h"
#include <QtMath>

#define    CANOPENILE      "/dev/canopen"
#define    GPIONUM          24
#define    RAW_COUNTS       5
#define    ADC_DATA_PATH(x) QString("/sys/devices/platform/soc/2100000.aips-bus/2198000.adc/iio:device0/in_voltage%1_raw").arg(x)

//sodimas I/O输入总共有24个(0-23) 0无按下 1有按下
//0-11:BC0-BC11
//12-15:Elib1-Elib4
//16-23:8位拨码开关
static unsigned char PreFlag[GPIONUM];
static unsigned char LightSta[16];  //BC0-BC11 Elib1-Elib4按钮输入灯状态处理
static unsigned char GpiosValue[GPIONUM];
static int fd;
static int ledLightOffFlag[12] = {0};
static int ledLightOnFlag[12] = {0};
static unsigned char protection[16] = {0};

/*
特殊按钮的短路      异常值为38左右, 判断值大于28即可 对应gpio1_IO3对应in_voltage3_raw
12路按钮           异常值为38左右, 判断值大于28即可 对应gpio1_IO4对应in_voltage4_raw
箭头和背光的俩个按钮 异常值为55左右, 判断值大于28即可 对应gpio1_IO9对应in_voltage9_raw
*/
static int btnExceptionNum = 28; /* 特殊按钮的短路  12路按钮的异常值*/

Gpios::Gpios(QThread *parent) : QThread(parent)
  , runThreadFlag(true)
  , mDipValue(0)
{
    initGpiosFd();
}

Gpios::~Gpios()
{
    IDE_TRACE();
    setRunThreadFlag(false);
}

int Gpios::sysExecuteKoFile(const char *str)
{
    printf("%s %s\n", __FUNCTION__, str);
    int flag = system(str);
    printf("%s result is %d\n", __FUNCTION__, flag);
    return flag;
}

void Gpios::currentProtectionAllLightOff()
{
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__;
    lseek(fd, 0, SEEK_SET);
    write(fd, protection, 16);
    onSigBtnPressedLightOff(18); // backLight
    onSigBtnPressedLightOff(19); // FLD
    onSigBtnPressedLightOff(20); // FLM
}

void Gpios::setElibLed(bool flag)
{/*操作第16,17位控制canOK和canFailed的灯*/
    unsigned char sta[2];
    int index =  16;
    if (flag)
    {        
        sta[0] = 1;
        sta[1] = 0;
    }
    else
    {
        sta[0] = 0;
        sta[1] = 1;
    }
    if (fd > 0)
    {
        lseek(fd, index, SEEK_SET);
        write(fd, sta, 2);
    }
}

quint8 Gpios::oneGetDialSwitchValue()
{
    quint8 tmpValue = 0;
    if (fd < 0)
    {
        IDE_TRACE_STR(QString("%1 is < 0 ").arg(fd));
        return tmpValue;
    }

    for (int i = 16; i < 24; ++i)
    {
        if (1 == GpiosValue[i])
        {
            tmpValue |= (1<<(i - 16));
        }
        else
        {
            tmpValue &= ~(1<<(i - 16));
        }
    }
    IDE_DEBUG(QString("%1%2").arg(" mDipValue is = ").arg(mDipValue));
    return tmpValue;
}

void Gpios::mySignalFunc(int signum)
{
    if (fd > 0)
    {
        read(fd, GpiosValue, 24);
    }
    else
    {
       IDE_DEBUG(QString("%1%2").arg("fd is smaller than 0 is ").arg(fd));
    }
    for (int i = 0; i < 12; ++i)
    {
        if (0 == GpiosValue[i])
        {
            if (1 == ledLightOffFlag[i])
            {
                ledLightOffFlag[i] = 0;
                lseek(fd, i, SEEK_SET);
                write(fd, &GpiosValue[i], 1);
                qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"set off i = "<<i;
            }
        }
    }
}

void Gpios::initGpiosFd()
{
    int flag;
    int sysFlag;
    memset(PreFlag, 0, 24);
    memset(LightSta, 0, 16);
    signal(SIGIO, mySignalFunc);     // 在应用程序中捕捉SIGIO信号(这个信号是驱动程序发送出来的)

    QString runPath = QString("insmod /usr/bst/usrfs/gpio-sodimas-canopen.ko");

    sysFlag = sysExecuteKoFile(runPath.toLatin1().data());    // 挂载驱动

    fd = open("/dev/canopen", O_RDWR);
    if (fd < 0)
    {
        qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"can not open canopen device!";
        return;
    }
    if (sysFlag != 0)
    {
        qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"load DriverFile is error!";
        return;
    }

    fcntl(fd, F_SETOWN, getpid());      // 将当前进程PID设置为fd文件所对应驱动程序将要发送SIGIO信号进程PID
    flag = fcntl(fd, F_GETFL);          // 获取fd的打开方式
    fcntl(fd, F_SETFL, flag|FASYNC);    // 将fd的打开方式设置为FASYNC, 即支持异步通知
    QThread::msleep(50);
    read(fd, GpiosValue, 24);
    IDE_TRACE_STR(QString("end void Gpios::initGpiosFd()"));
}

void Gpios::run()
{
    IDE_TRACE();
    unsigned char Cnt;
    while (runThreadFlag)
    {
        //sodimas I/O输入总共有24个(0-23) 0无按下 1有按下
        msleep(15);
        for(Cnt = 0; Cnt < 17; ++Cnt) //0-11: BC0-BC11  //12-15: Elib1-Elib4
        {
            if (Cnt < 16)
            {
                if (GpiosValue[Cnt])   // 有按键按下
                {
                    if (0 == PreFlag[Cnt])
                    {
                        /* 可在此处将按钮信息发送给控制柜或是作为事件触发 */
                        if (Cnt < 16) // BC0-BC11 Elib1-Elib4 按钮输入灯状态处理
                        {
                            LightSta[Cnt] ^= 1;
                            if (LightSta[Cnt])
                            {
                                if (Cnt < 12)
                                {
                                    printf("btn%d is pressed\n", Cnt);
                                    emit sigBtnPressed(Cnt+1);
                                }
                                else if (Cnt < 16)
                                {
                                    printf("btn%d is pressed\n", Cnt+25);
                                    emit sigBtnPressed(Cnt+25);
                                }
                            }
                            else
                            {
                                if (Cnt < 12)
                                {
                                    printf("btn%d is cancled\n", Cnt);
                                    emit sigBtnCanceld(Cnt+1);
                                }
                                else if (Cnt < 16)
                                {
                                    emit sigBtnCanceld(Cnt+25);
                                    printf("btn%d is cancled\n", Cnt+25);
                                }
                            }
                        }
                    }
                    PreFlag[Cnt] = 1;  // 记录按下标志                    
                }
                else
                {
                    if (PreFlag[Cnt])   // 松开按键
                    {
                        if (Cnt < 12)
                        {
                            emit sigBtnReleased(Cnt+1);
                            PreFlag[Cnt] = 0; // 清除按下标志
                        }
                        else if (Cnt < 16)
                        {
                            emit sigBtnReleased(Cnt+25);
                            PreFlag[Cnt] = 0; // 清除按下标志
                        }
                    } /*end of if (PreFlag[Cnt])*/
                }
            }
            else if (16 == Cnt) //16-23: 8位拨码开关
            {
                readAdcValue();
                getDialSwitchValue();
            }
        }
    }
}

void Gpios::setLedLightOffFlag(int index, int flag)
{
    printf("%s() index = %d flag = %d\n", __PRETTY_FUNCTION__, index, flag);
    ledLightOffFlag[index - 1] = flag;  // 数组索引需要减掉1
    printf("%s() ledLightOffFlag[%d] = flag = %d\n", __PRETTY_FUNCTION__, index - 1, flag);
}

void Gpios::setRunThreadFlag(bool runflag)
{
    IDE_TRACE();
    runThreadFlag = runflag;
}

void Gpios::getDialSwitchValue()
{    
    quint8 tmpValue = 0;
    for (int i = 16; i < 24; ++i)
    {
        if (1 == GpiosValue[i])
        {
            tmpValue |= (1<<(i - 16));
        }
        else
        {
            tmpValue &= ~(1<<(i - 16));
        }
    }
    if (mDipValue != tmpValue)
    {
        mDipValue = tmpValue;
        emit sigDailChanged(mDipValue);
        qDebug()<<__FUNCTION__<< " mDipValue is changed "<< mDipValue;
    }
}

void Gpios::onSigBtnPressedLightOn(quint8 btnindex)
{
    unsigned char sta = 1;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"will lighton "<<btnindex;
    lseek(fd, btnindex, SEEK_SET);
    write(fd, &sta, 1);
}

void Gpios::onSigBtnPressedLightOff(quint8 btnindex)
{
    unsigned char sta = 0;
    qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"will lightoff "<<btnindex;
    lseek(fd, btnindex, SEEK_SET);
    write(fd, &sta, 1);
}

void Gpios::onSigDailChanged(quint8 pNum)
{

}

int Gpios::getFloorNum(float num)
{
    int tmp = qFloor(num);
    return  tmp;
}

void Gpios::judgeIsProtect(int index, int num)
{
    if (3 == index || 4 == index || 9 == index) /*voltage3 and voltage4*/
    {
        if (num > btnExceptionNum) /*大于异常的临界值*/
        {
            qDebug()<<__PRETTY_FUNCTION__<<"lines = "<<__LINE__<<"send sigNeedProctect"<<"index = "<<index<<"num = "<<num;
            emit sigNeedProctect();
        }
    }
}

void Gpios::readAdcValue()
{
    int fd, ret;
    double tmpValue;
    char data[20];
    int indexStr[3] = {3, 4, 9}; /*ADC对应的索引数值*/
    for (int i = 0; i < 3; ++i)
    {
        const char* tmp = ADC_DATA_PATH(indexStr[i]).toLatin1().data();
        fd = open(tmp, O_RDONLY);
        if (fd < 0)
        {
            perror("open ADC File error");
            printf("indexStr[%d] = %d\n", i, indexStr[i]);
            return;
        }
        ret = read(fd, data, sizeof(data));
        if (ret < 0)
        {
            perror("read data error");
            printf("indexStr[%d] = %d\n", i, indexStr[i]);
            close(fd);
            return;
        }
        /* collect data and calculate the voltage */
        tmpValue = atof(data);
        judgeIsProtect(indexStr[i], getFloorNum(tmpValue));
        close(fd);
    }
}

int Gpios::getIsPressedFlag(int index)
{
    if (GpiosValue[index])
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void Gpios::setLedLightOnFlag(int index, int flag)
{
    printf("%s() index = %d flag = %d\n", __PRETTY_FUNCTION__, index, flag);
    ledLightOnFlag[index - 1] = flag;  // 数组索引需要减掉1
    printf("%s() ledLightOnFlag[%d] = flag = %d\n", __PRETTY_FUNCTION__, index - 1, flag);
}

int Gpios::getLedLightOnFlag(int index)
{
    if (1 == ledLightOnFlag[index - 1])
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int Gpios::getLedLightOffFlag(int index)
{
    if (1 == ledLightOffFlag[index - 1])
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
