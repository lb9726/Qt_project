<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>ColumnArea2</name>
    <message>
        <location filename="ColumnArea2.qml" line="21"/>
        <location filename="ColumnArea2.qml" line="92"/>
        <source>制作升级盘</source>
        <translation>Produce upgrade disk</translation>
    </message>
    <message>
        <location filename="ColumnArea2.qml" line="45"/>
        <location filename="ColumnArea2.qml" line="93"/>
        <source>制作</source>
        <translation> Produce</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="15"/>
        <source>MediaScreenMaintainer</source>
        <translation>MediaScreenMaintainer</translation>
    </message>
    <message>
        <source>  V1.6.0.  仅用于上海贝思特MediaScreen.</source>
        <translation type="vanished">V1.6.0.  just for Shanghai BST MediaScreen.</translation>
    </message>
    <message>
        <source>  V1.7.0.  仅用于上海贝思特MediaScreen.</source>
        <translation type="vanished">V1.7.0.  just for Shanghai BST MediaScreen</translation>
    </message>
    <message>
        <location filename="main.qml" line="82"/>
        <location filename="main.qml" line="321"/>
        <source>选择升级文件</source>
        <translation>Select upgrade file</translation>
    </message>
    <message>
        <location filename="main.qml" line="114"/>
        <location filename="main.qml" line="322"/>
        <source>选择</source>
        <translation>Select</translation>
    </message>
    <message>
        <source>制作升级盘</source>
        <translation type="vanished">Make upgrade disk</translation>
    </message>
    <message>
        <source>制作</source>
        <translation type="vanished">Make</translation>
    </message>
    <message>
        <source>  V1.7.0</source>
        <translation type="vanished">  V1.7.0</translation>
    </message>
    <message>
        <location filename="main.qml" line="15"/>
        <source>  V2.0.0</source>
        <translation>  V2.0.0</translation>
    </message>
    <message>
        <location filename="main.qml" line="41"/>
        <source>供应商:</source>
        <translation>Supplier:</translation>
    </message>
    <message>
        <location filename="main.qml" line="168"/>
        <location filename="main.qml" line="323"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="main.qml" line="224"/>
        <location filename="main.qml" line="324"/>
        <source>制作完毕</source>
        <translation>Production finished</translation>
    </message>
    <message>
        <location filename="main.qml" line="239"/>
        <location filename="main.qml" line="325"/>
        <source>正在检查U盘...</source>
        <translation>Checking U disk...</translation>
    </message>
    <message>
        <location filename="main.qml" line="258"/>
        <location filename="main.qml" line="326"/>
        <source>正在拷贝文件...</source>
        <translation>In the process of Copying.....</translation>
    </message>
    <message>
        <location filename="main.qml" line="271"/>
        <source>生成认证文件</source>
        <translation>Generate printcert</translation>
    </message>
    <message>
        <location filename="main.qml" line="274"/>
        <source>制作成功</source>
        <translation>Sucessfully produced</translation>
    </message>
    <message>
        <location filename="main.qml" line="301"/>
        <location filename="main.qml" line="327"/>
        <source>请选择用于升级的文件</source>
        <translation>Please select file which need to be upgraded</translation>
    </message>
    <message>
        <location filename="main.qml" line="328"/>
        <source>供应商</source>
        <translation>Supplier:</translation>
    </message>
</context>
</TS>
