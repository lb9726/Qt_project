/****************************************************************************
** Meta object code from reading C++ file 'mediascreen.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../mediascreen.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mediascreen.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MediaScreen_t {
    QByteArrayData data[28];
    char stringdata0[349];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MediaScreen_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MediaScreen_t qt_meta_stringdata_MediaScreen = {
    {
QT_MOC_LITERAL(0, 0, 11), // "MediaScreen"
QT_MOC_LITERAL(1, 12, 18), // "clearAudioParament"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 9), // "lan_index"
QT_MOC_LITERAL(4, 42, 25), // "getScrollTextLengthSignal"
QT_MOC_LITERAL(5, 68, 24), // "hasUdiskInsertToComputer"
QT_MOC_LITERAL(6, 93, 9), // "uDiskName"
QT_MOC_LITERAL(7, 103, 8), // "changeUi"
QT_MOC_LITERAL(8, 112, 8), // "setIndex"
QT_MOC_LITERAL(9, 121, 1), // "i"
QT_MOC_LITERAL(10, 123, 8), // "getIndex"
QT_MOC_LITERAL(11, 132, 19), // "getScrollTextLength"
QT_MOC_LITERAL(12, 152, 17), // "getSystemLanguage"
QT_MOC_LITERAL(13, 170, 11), // "setPreIndex"
QT_MOC_LITERAL(14, 182, 11), // "getPreIndex"
QT_MOC_LITERAL(15, 194, 16), // "getIndexIpString"
QT_MOC_LITERAL(16, 211, 5), // "index"
QT_MOC_LITERAL(17, 217, 8), // "getModel"
QT_MOC_LITERAL(18, 226, 12), // "getSplitTime"
QT_MOC_LITERAL(19, 239, 12), // "getSplitDate"
QT_MOC_LITERAL(20, 252, 13), // "getDateFormat"
QT_MOC_LITERAL(21, 266, 5), // "isYmd"
QT_MOC_LITERAL(22, 272, 13), // "getTimeFormat"
QT_MOC_LITERAL(23, 286, 4), // "is12"
QT_MOC_LITERAL(24, 291, 20), // "setUdiskIsInsertFlag"
QT_MOC_LITERAL(25, 312, 4), // "flag"
QT_MOC_LITERAL(26, 317, 10), // "udiskIndex"
QT_MOC_LITERAL(27, 328, 20) // "sendUdiskInformation"

    },
    "MediaScreen\0clearAudioParament\0\0"
    "lan_index\0getScrollTextLengthSignal\0"
    "hasUdiskInsertToComputer\0uDiskName\0"
    "changeUi\0setIndex\0i\0getIndex\0"
    "getScrollTextLength\0getSystemLanguage\0"
    "setPreIndex\0getPreIndex\0getIndexIpString\0"
    "index\0getModel\0getSplitTime\0getSplitDate\0"
    "getDateFormat\0isYmd\0getTimeFormat\0"
    "is12\0setUdiskIsInsertFlag\0flag\0"
    "udiskIndex\0sendUdiskInformation"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MediaScreen[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  104,    2, 0x06 /* Public */,
       4,    0,  107,    2, 0x06 /* Public */,
       5,    1,  108,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       7,    0,  111,    2, 0x0a /* Public */,
       8,    1,  112,    2, 0x0a /* Public */,
      10,    0,  115,    2, 0x0a /* Public */,
      11,    0,  116,    2, 0x0a /* Public */,
      12,    0,  117,    2, 0x0a /* Public */,
      13,    1,  118,    2, 0x0a /* Public */,
      14,    0,  121,    2, 0x0a /* Public */,
      15,    1,  122,    2, 0x0a /* Public */,
      17,    1,  125,    2, 0x0a /* Public */,
      18,    1,  128,    2, 0x0a /* Public */,
      19,    1,  131,    2, 0x0a /* Public */,
      20,    1,  134,    2, 0x0a /* Public */,
      22,    1,  137,    2, 0x0a /* Public */,
      24,    2,  140,    2, 0x0a /* Public */,
      27,    0,  145,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    6,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::QVariant,
    QMetaType::Void,
    QMetaType::Int,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::QVariant,
    QMetaType::QString, QMetaType::Int,   16,
    QMetaType::QVariant, QMetaType::Int,   16,
    QMetaType::QString, QMetaType::Int,   16,
    QMetaType::QString, QMetaType::Int,   16,
    QMetaType::QString, QMetaType::Bool,   21,
    QMetaType::QString, QMetaType::Bool,   23,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString,   25,   26,
    QMetaType::Void,

       0        // eod
};

void MediaScreen::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MediaScreen *_t = static_cast<MediaScreen *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->clearAudioParament((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->getScrollTextLengthSignal(); break;
        case 2: _t->hasUdiskInsertToComputer((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->changeUi(); break;
        case 4: _t->setIndex((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: { QVariant _r = _t->getIndex();
            if (_a[0]) *reinterpret_cast< QVariant*>(_a[0]) = _r; }  break;
        case 6: _t->getScrollTextLength(); break;
        case 7: { int _r = _t->getSystemLanguage();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 8: _t->setPreIndex((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: { QVariant _r = _t->getPreIndex();
            if (_a[0]) *reinterpret_cast< QVariant*>(_a[0]) = _r; }  break;
        case 10: { QString _r = _t->getIndexIpString((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 11: { QVariant _r = _t->getModel((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QVariant*>(_a[0]) = _r; }  break;
        case 12: { QString _r = _t->getSplitTime((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 13: { QString _r = _t->getSplitDate((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 14: { QString _r = _t->getDateFormat((*reinterpret_cast< bool(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 15: { QString _r = _t->getTimeFormat((*reinterpret_cast< bool(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 16: _t->setUdiskIsInsertFlag((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 17: _t->sendUdiskInformation(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MediaScreen::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MediaScreen::clearAudioParament)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (MediaScreen::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MediaScreen::getScrollTextLengthSignal)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (MediaScreen::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MediaScreen::hasUdiskInsertToComputer)) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject MediaScreen::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_MediaScreen.data,
      qt_meta_data_MediaScreen,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MediaScreen::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MediaScreen::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MediaScreen.stringdata0))
        return static_cast<void*>(const_cast< MediaScreen*>(this));
    return QObject::qt_metacast(_clname);
}

int MediaScreen::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
    return _id;
}

// SIGNAL 0
void MediaScreen::clearAudioParament(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MediaScreen::getScrollTextLengthSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}

// SIGNAL 2
void MediaScreen::hasUdiskInsertToComputer(QString _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
