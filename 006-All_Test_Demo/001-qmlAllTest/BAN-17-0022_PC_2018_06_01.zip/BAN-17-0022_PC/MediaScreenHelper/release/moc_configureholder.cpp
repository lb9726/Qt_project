/****************************************************************************
** Meta object code from reading C++ file 'configureholder.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../configureholder.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'configureholder.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ConfigureHolder_t {
    QByteArrayData data[115];
    char stringdata0[1658];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ConfigureHolder_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ConfigureHolder_t qt_meta_stringdata_ConfigureHolder = {
    {
QT_MOC_LITERAL(0, 0, 15), // "ConfigureHolder"
QT_MOC_LITERAL(1, 16, 16), // "copyFileProgress"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 3), // "pro"
QT_MOC_LITERAL(4, 38, 19), // "resetDefaultClicked"
QT_MOC_LITERAL(5, 58, 13), // "resetCanceled"
QT_MOC_LITERAL(6, 72, 17), // "showPreviewSignal"
QT_MOC_LITERAL(7, 90, 19), // "previewCheckedFalse"
QT_MOC_LITERAL(8, 110, 17), // "startPicAnimation"
QT_MOC_LITERAL(9, 128, 19), // "isFullScreenChanges"
QT_MOC_LITERAL(10, 148, 6), // "isfull"
QT_MOC_LITERAL(11, 155, 23), // "horizontalAudioAutoPlay"
QT_MOC_LITERAL(12, 179, 33), // "horizontalFullscreenAudioAuto..."
QT_MOC_LITERAL(13, 213, 21), // "verticalAudioAutoPlay"
QT_MOC_LITERAL(14, 235, 31), // "verticalFullscreenAudioAutoPlay"
QT_MOC_LITERAL(15, 267, 16), // "stopAllAudioPlay"
QT_MOC_LITERAL(16, 284, 25), // "startPlayAfterCloseNormal"
QT_MOC_LITERAL(17, 310, 29), // "startPlayAfterCloseFullScreen"
QT_MOC_LITERAL(18, 340, 15), // "checkFullScreen"
QT_MOC_LITERAL(19, 356, 9), // "createXml"
QT_MOC_LITERAL(20, 366, 3), // "dir"
QT_MOC_LITERAL(21, 370, 15), // "clearParameters"
QT_MOC_LITERAL(22, 386, 6), // "delDir"
QT_MOC_LITERAL(23, 393, 4), // "path"
QT_MOC_LITERAL(24, 398, 9), // "orderFile"
QT_MOC_LITERAL(25, 408, 15), // "copyReourceFile"
QT_MOC_LITERAL(26, 424, 3), // "src"
QT_MOC_LITERAL(27, 428, 3), // "dst"
QT_MOC_LITERAL(28, 432, 11), // "GetFilePath"
QT_MOC_LITERAL(29, 444, 9), // "pFilePath"
QT_MOC_LITERAL(30, 454, 11), // "resetScreen"
QT_MOC_LITERAL(31, 466, 7), // "isReset"
QT_MOC_LITERAL(32, 474, 17), // "sendCheckedSignal"
QT_MOC_LITERAL(33, 492, 18), // "sendCanceledSignal"
QT_MOC_LITERAL(34, 511, 15), // "sendShowPreview"
QT_MOC_LITERAL(35, 527, 23), // "sendPreviewCheckedFalse"
QT_MOC_LITERAL(36, 551, 21), // "sendStartPicAnimation"
QT_MOC_LITERAL(37, 573, 22), // "sendIsFullScreenSignal"
QT_MOC_LITERAL(38, 596, 6), // "isflag"
QT_MOC_LITERAL(39, 603, 25), // "sendCheckFullScreenSignal"
QT_MOC_LITERAL(40, 629, 22), // "sendHorizontalAutoPlay"
QT_MOC_LITERAL(41, 652, 20), // "sendVerticalAutoPlay"
QT_MOC_LITERAL(42, 673, 17), // "sendStopAudioPlay"
QT_MOC_LITERAL(43, 691, 18), // "sendPlayAfterClose"
QT_MOC_LITERAL(44, 710, 24), // "setBrightOrVolumeChanged"
QT_MOC_LITERAL(45, 735, 4), // "para"
QT_MOC_LITERAL(46, 740, 16), // "updateMultiMedia"
QT_MOC_LITERAL(47, 757, 21), // "isMediaContentEnabled"
QT_MOC_LITERAL(48, 779, 14), // "videoOrPicture"
QT_MOC_LITERAL(49, 794, 7), // "isAudio"
QT_MOC_LITERAL(50, 802, 12), // "isfullscreen"
QT_MOC_LITERAL(51, 815, 5), // "paths"
QT_MOC_LITERAL(52, 821, 14), // "retPicturePath"
QT_MOC_LITERAL(53, 836, 20), // "updateParameterBasic"
QT_MOC_LITERAL(54, 857, 19), // "bConfigureParameter"
QT_MOC_LITERAL(55, 877, 17), // "bBrightnessVolume"
QT_MOC_LITERAL(56, 895, 11), // "bScrollText"
QT_MOC_LITERAL(57, 907, 6), // "bTitle"
QT_MOC_LITERAL(58, 914, 9), // "bDateTime"
QT_MOC_LITERAL(59, 924, 8), // "bStandby"
QT_MOC_LITERAL(60, 933, 12), // "isScrollText"
QT_MOC_LITERAL(61, 946, 7), // "isTitle"
QT_MOC_LITERAL(62, 954, 10), // "isDateTime"
QT_MOC_LITERAL(63, 965, 8), // "audioSel"
QT_MOC_LITERAL(64, 974, 21), // "updateParameterBasic1"
QT_MOC_LITERAL(65, 996, 10), // "scrollFlag"
QT_MOC_LITERAL(66, 1007, 9), // "titleFlag"
QT_MOC_LITERAL(67, 1017, 20), // "updateArea1ParaAudio"
QT_MOC_LITERAL(68, 1038, 7), // "audioOn"
QT_MOC_LITERAL(69, 1046, 8), // "audioOff"
QT_MOC_LITERAL(70, 1055, 21), // "updateParameterBasic2"
QT_MOC_LITERAL(71, 1077, 8), // "audiooff"
QT_MOC_LITERAL(72, 1086, 8), // "timeFlag"
QT_MOC_LITERAL(73, 1095, 9), // "audioFlag"
QT_MOC_LITERAL(74, 1105, 22), // "updateBrightnessVolume"
QT_MOC_LITERAL(75, 1128, 11), // "vBrightness"
QT_MOC_LITERAL(76, 1140, 7), // "vVolume"
QT_MOC_LITERAL(77, 1148, 11), // "judgeString"
QT_MOC_LITERAL(78, 1160, 3), // "str"
QT_MOC_LITERAL(79, 1164, 16), // "updateScrollText"
QT_MOC_LITERAL(80, 1181, 11), // "vScrollText"
QT_MOC_LITERAL(81, 1193, 11), // "updateTitle"
QT_MOC_LITERAL(82, 1205, 6), // "vTitle"
QT_MOC_LITERAL(83, 1212, 14), // "updateDateTime"
QT_MOC_LITERAL(84, 1227, 11), // "vTimeFormat"
QT_MOC_LITERAL(85, 1239, 11), // "vDateFormat"
QT_MOC_LITERAL(86, 1251, 13), // "updateStandby"
QT_MOC_LITERAL(87, 1265, 15), // "vStage1Interval"
QT_MOC_LITERAL(88, 1281, 17), // "vStage1Brightness"
QT_MOC_LITERAL(89, 1299, 15), // "vStage2Interval"
QT_MOC_LITERAL(90, 1315, 17), // "vStage2Brightness"
QT_MOC_LITERAL(91, 1333, 21), // "updatePictureInterval"
QT_MOC_LITERAL(92, 1355, 16), // "vPictureInterval"
QT_MOC_LITERAL(93, 1372, 14), // "getPicInterval"
QT_MOC_LITERAL(94, 1387, 14), // "setSystimeText"
QT_MOC_LITERAL(95, 1402, 5), // "ptext"
QT_MOC_LITERAL(96, 1408, 9), // "sysTimeOn"
QT_MOC_LITERAL(97, 1418, 15), // "setCountryIndex"
QT_MOC_LITERAL(98, 1434, 13), // "pCountryIndex"
QT_MOC_LITERAL(99, 1448, 9), // "pYysIndex"
QT_MOC_LITERAL(100, 1458, 10), // "setApnFlag"
QT_MOC_LITERAL(101, 1469, 6), // "pApnOn"
QT_MOC_LITERAL(102, 1476, 15), // "setApnParameter"
QT_MOC_LITERAL(103, 1492, 11), // "papnYysText"
QT_MOC_LITERAL(104, 1504, 11), // "papnJrdText"
QT_MOC_LITERAL(105, 1516, 11), // "papnMccText"
QT_MOC_LITERAL(106, 1528, 11), // "papnMncText"
QT_MOC_LITERAL(107, 1540, 13), // "papnUNameText"
QT_MOC_LITERAL(108, 1554, 14), // "papnPasswdText"
QT_MOC_LITERAL(109, 1569, 14), // "setIpParameter"
QT_MOC_LITERAL(110, 1584, 18), // "pIsAutoSettingFlag"
QT_MOC_LITERAL(111, 1603, 14), // "pIpAddressText"
QT_MOC_LITERAL(112, 1618, 11), // "psubnetText"
QT_MOC_LITERAL(113, 1630, 15), // "pdefaultGateWay"
QT_MOC_LITERAL(114, 1646, 11) // "pdnsService"

    },
    "ConfigureHolder\0copyFileProgress\0\0pro\0"
    "resetDefaultClicked\0resetCanceled\0"
    "showPreviewSignal\0previewCheckedFalse\0"
    "startPicAnimation\0isFullScreenChanges\0"
    "isfull\0horizontalAudioAutoPlay\0"
    "horizontalFullscreenAudioAutoPlay\0"
    "verticalAudioAutoPlay\0"
    "verticalFullscreenAudioAutoPlay\0"
    "stopAllAudioPlay\0startPlayAfterCloseNormal\0"
    "startPlayAfterCloseFullScreen\0"
    "checkFullScreen\0createXml\0dir\0"
    "clearParameters\0delDir\0path\0orderFile\0"
    "copyReourceFile\0src\0dst\0GetFilePath\0"
    "pFilePath\0resetScreen\0isReset\0"
    "sendCheckedSignal\0sendCanceledSignal\0"
    "sendShowPreview\0sendPreviewCheckedFalse\0"
    "sendStartPicAnimation\0sendIsFullScreenSignal\0"
    "isflag\0sendCheckFullScreenSignal\0"
    "sendHorizontalAutoPlay\0sendVerticalAutoPlay\0"
    "sendStopAudioPlay\0sendPlayAfterClose\0"
    "setBrightOrVolumeChanged\0para\0"
    "updateMultiMedia\0isMediaContentEnabled\0"
    "videoOrPicture\0isAudio\0isfullscreen\0"
    "paths\0retPicturePath\0updateParameterBasic\0"
    "bConfigureParameter\0bBrightnessVolume\0"
    "bScrollText\0bTitle\0bDateTime\0bStandby\0"
    "isScrollText\0isTitle\0isDateTime\0"
    "audioSel\0updateParameterBasic1\0"
    "scrollFlag\0titleFlag\0updateArea1ParaAudio\0"
    "audioOn\0audioOff\0updateParameterBasic2\0"
    "audiooff\0timeFlag\0audioFlag\0"
    "updateBrightnessVolume\0vBrightness\0"
    "vVolume\0judgeString\0str\0updateScrollText\0"
    "vScrollText\0updateTitle\0vTitle\0"
    "updateDateTime\0vTimeFormat\0vDateFormat\0"
    "updateStandby\0vStage1Interval\0"
    "vStage1Brightness\0vStage2Interval\0"
    "vStage2Brightness\0updatePictureInterval\0"
    "vPictureInterval\0getPicInterval\0"
    "setSystimeText\0ptext\0sysTimeOn\0"
    "setCountryIndex\0pCountryIndex\0pYysIndex\0"
    "setApnFlag\0pApnOn\0setApnParameter\0"
    "papnYysText\0papnJrdText\0papnMccText\0"
    "papnMncText\0papnUNameText\0papnPasswdText\0"
    "setIpParameter\0pIsAutoSettingFlag\0"
    "pIpAddressText\0psubnetText\0pdefaultGateWay\0"
    "pdnsService"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ConfigureHolder[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      53,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      15,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  279,    2, 0x06 /* Public */,
       4,    0,  282,    2, 0x06 /* Public */,
       5,    0,  283,    2, 0x06 /* Public */,
       6,    0,  284,    2, 0x06 /* Public */,
       7,    0,  285,    2, 0x06 /* Public */,
       8,    0,  286,    2, 0x06 /* Public */,
       9,    1,  287,    2, 0x06 /* Public */,
      11,    0,  290,    2, 0x06 /* Public */,
      12,    0,  291,    2, 0x06 /* Public */,
      13,    0,  292,    2, 0x06 /* Public */,
      14,    0,  293,    2, 0x06 /* Public */,
      15,    0,  294,    2, 0x06 /* Public */,
      16,    0,  295,    2, 0x06 /* Public */,
      17,    0,  296,    2, 0x06 /* Public */,
      18,    0,  297,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      19,    1,  298,    2, 0x0a /* Public */,
      21,    0,  301,    2, 0x0a /* Public */,
      22,    1,  302,    2, 0x0a /* Public */,
      24,    1,  305,    2, 0x0a /* Public */,
      25,    2,  308,    2, 0x0a /* Public */,
      28,    1,  313,    2, 0x0a /* Public */,
      30,    1,  316,    2, 0x0a /* Public */,
      32,    0,  319,    2, 0x0a /* Public */,
      33,    0,  320,    2, 0x0a /* Public */,
      34,    0,  321,    2, 0x0a /* Public */,
      35,    0,  322,    2, 0x0a /* Public */,
      36,    0,  323,    2, 0x0a /* Public */,
      37,    1,  324,    2, 0x0a /* Public */,
      39,    1,  327,    2, 0x0a /* Public */,
      40,    1,  330,    2, 0x0a /* Public */,
      41,    1,  333,    2, 0x0a /* Public */,
      42,    0,  336,    2, 0x0a /* Public */,
      43,    1,  337,    2, 0x0a /* Public */,
      44,    1,  340,    2, 0x0a /* Public */,
      46,    5,  343,    2, 0x0a /* Public */,
      52,    1,  354,    2, 0x0a /* Public */,
      53,   10,  357,    2, 0x0a /* Public */,
      64,    8,  378,    2, 0x0a /* Public */,
      67,    2,  395,    2, 0x0a /* Public */,
      70,    8,  400,    2, 0x0a /* Public */,
      74,    2,  417,    2, 0x0a /* Public */,
      77,    1,  422,    2, 0x0a /* Public */,
      79,    1,  425,    2, 0x0a /* Public */,
      81,    1,  428,    2, 0x0a /* Public */,
      83,    2,  431,    2, 0x0a /* Public */,
      86,    4,  436,    2, 0x0a /* Public */,
      91,    1,  445,    2, 0x0a /* Public */,
      93,    0,  448,    2, 0x0a /* Public */,
      94,    2,  449,    2, 0x0a /* Public */,
      97,    2,  454,    2, 0x0a /* Public */,
     100,    1,  459,    2, 0x0a /* Public */,
     102,    6,  462,    2, 0x0a /* Public */,
     109,    5,  475,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Bool, QMetaType::QString,   20,
    QMetaType::Void,
    QMetaType::Bool, QMetaType::QString,   23,
    QMetaType::Void, QMetaType::QString,   20,
    QMetaType::Bool, QMetaType::QString, QMetaType::QString,   26,   27,
    QMetaType::QString, QMetaType::QString,   29,
    QMetaType::Bool, QMetaType::Bool,   31,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   38,
    QMetaType::Void, QMetaType::Bool,   38,
    QMetaType::Void, QMetaType::Bool,   10,
    QMetaType::Void, QMetaType::Bool,   10,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   10,
    QMetaType::Void, QMetaType::Int,   45,
    QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::QString,   47,   48,   49,   50,   51,
    QMetaType::QVariant, QMetaType::QString,   51,
    QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool,   54,   55,   56,   57,   58,   59,   60,   61,   62,   63,
    QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Int, QMetaType::Int,   54,   55,   56,   57,   60,   61,   65,   66,
    QMetaType::Bool, QMetaType::Bool, QMetaType::Bool,   68,   69,
    QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Int, QMetaType::Int,   54,   58,   59,   62,   63,   71,   72,   73,
    QMetaType::Bool, QMetaType::Int, QMetaType::Int,   75,   76,
    QMetaType::Int, QMetaType::QString,   78,
    QMetaType::Bool, QMetaType::QString,   80,
    QMetaType::Bool, QMetaType::QString,   82,
    QMetaType::Bool, QMetaType::QString, QMetaType::QString,   84,   85,
    QMetaType::Bool, QMetaType::UInt, QMetaType::UChar, QMetaType::UInt, QMetaType::UChar,   87,   88,   89,   90,
    QMetaType::Bool, QMetaType::Int,   92,
    QMetaType::Int,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool,   95,   96,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   98,   99,
    QMetaType::Void, QMetaType::Bool,  101,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,  103,  104,  105,  106,  107,  108,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,  110,  111,  112,  113,  114,

       0        // eod
};

void ConfigureHolder::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ConfigureHolder *_t = static_cast<ConfigureHolder *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->copyFileProgress((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->resetDefaultClicked(); break;
        case 2: _t->resetCanceled(); break;
        case 3: _t->showPreviewSignal(); break;
        case 4: _t->previewCheckedFalse(); break;
        case 5: _t->startPicAnimation(); break;
        case 6: _t->isFullScreenChanges((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->horizontalAudioAutoPlay(); break;
        case 8: _t->horizontalFullscreenAudioAutoPlay(); break;
        case 9: _t->verticalAudioAutoPlay(); break;
        case 10: _t->verticalFullscreenAudioAutoPlay(); break;
        case 11: _t->stopAllAudioPlay(); break;
        case 12: _t->startPlayAfterCloseNormal(); break;
        case 13: _t->startPlayAfterCloseFullScreen(); break;
        case 14: _t->checkFullScreen(); break;
        case 15: { bool _r = _t->createXml((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 16: _t->clearParameters(); break;
        case 17: { bool _r = _t->delDir((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 18: _t->orderFile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 19: { bool _r = _t->copyReourceFile((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 20: { QString _r = _t->GetFilePath((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 21: { bool _r = _t->resetScreen((*reinterpret_cast< bool(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 22: _t->sendCheckedSignal(); break;
        case 23: _t->sendCanceledSignal(); break;
        case 24: _t->sendShowPreview(); break;
        case 25: _t->sendPreviewCheckedFalse(); break;
        case 26: _t->sendStartPicAnimation(); break;
        case 27: _t->sendIsFullScreenSignal((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 28: _t->sendCheckFullScreenSignal((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 29: _t->sendHorizontalAutoPlay((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 30: _t->sendVerticalAutoPlay((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 31: _t->sendStopAudioPlay(); break;
        case 32: _t->sendPlayAfterClose((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 33: _t->setBrightOrVolumeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 34: { bool _r = _t->updateMultiMedia((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 35: { QVariant _r = _t->retPicturePath((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QVariant*>(_a[0]) = _r; }  break;
        case 36: { bool _r = _t->updateParameterBasic((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< bool(*)>(_a[6])),(*reinterpret_cast< bool(*)>(_a[7])),(*reinterpret_cast< bool(*)>(_a[8])),(*reinterpret_cast< bool(*)>(_a[9])),(*reinterpret_cast< bool(*)>(_a[10])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 37: { bool _r = _t->updateParameterBasic1((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< bool(*)>(_a[6])),(*reinterpret_cast< int(*)>(_a[7])),(*reinterpret_cast< int(*)>(_a[8])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 38: { bool _r = _t->updateArea1ParaAudio((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 39: { bool _r = _t->updateParameterBasic2((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< bool(*)>(_a[6])),(*reinterpret_cast< int(*)>(_a[7])),(*reinterpret_cast< int(*)>(_a[8])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 40: { bool _r = _t->updateBrightnessVolume((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 41: { int _r = _t->judgeString((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 42: { bool _r = _t->updateScrollText((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 43: { bool _r = _t->updateTitle((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 44: { bool _r = _t->updateDateTime((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 45: { bool _r = _t->updateStandby((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< quint8(*)>(_a[2])),(*reinterpret_cast< quint32(*)>(_a[3])),(*reinterpret_cast< quint8(*)>(_a[4])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 46: { bool _r = _t->updatePictureInterval((*reinterpret_cast< qint32(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 47: { int _r = _t->getPicInterval();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 48: _t->setSystimeText((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 49: _t->setCountryIndex((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 50: _t->setApnFlag((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 51: _t->setApnParameter((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6]))); break;
        case 52: _t->setIpParameter((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (ConfigureHolder::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::copyFileProgress)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::resetDefaultClicked)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::resetCanceled)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::showPreviewSignal)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::previewCheckedFalse)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::startPicAnimation)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::isFullScreenChanges)) {
                *result = 6;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::horizontalAudioAutoPlay)) {
                *result = 7;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::horizontalFullscreenAudioAutoPlay)) {
                *result = 8;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::verticalAudioAutoPlay)) {
                *result = 9;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::verticalFullscreenAudioAutoPlay)) {
                *result = 10;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::stopAllAudioPlay)) {
                *result = 11;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::startPlayAfterCloseNormal)) {
                *result = 12;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::startPlayAfterCloseFullScreen)) {
                *result = 13;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::checkFullScreen)) {
                *result = 14;
                return;
            }
        }
    }
}

const QMetaObject ConfigureHolder::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_ConfigureHolder.data,
      qt_meta_data_ConfigureHolder,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ConfigureHolder::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ConfigureHolder::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ConfigureHolder.stringdata0))
        return static_cast<void*>(const_cast< ConfigureHolder*>(this));
    return QObject::qt_metacast(_clname);
}

int ConfigureHolder::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 53)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 53;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 53)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 53;
    }
    return _id;
}

// SIGNAL 0
void ConfigureHolder::copyFileProgress(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ConfigureHolder::resetDefaultClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}

// SIGNAL 2
void ConfigureHolder::resetCanceled()
{
    QMetaObject::activate(this, &staticMetaObject, 2, Q_NULLPTR);
}

// SIGNAL 3
void ConfigureHolder::showPreviewSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 3, Q_NULLPTR);
}

// SIGNAL 4
void ConfigureHolder::previewCheckedFalse()
{
    QMetaObject::activate(this, &staticMetaObject, 4, Q_NULLPTR);
}

// SIGNAL 5
void ConfigureHolder::startPicAnimation()
{
    QMetaObject::activate(this, &staticMetaObject, 5, Q_NULLPTR);
}

// SIGNAL 6
void ConfigureHolder::isFullScreenChanges(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void ConfigureHolder::horizontalAudioAutoPlay()
{
    QMetaObject::activate(this, &staticMetaObject, 7, Q_NULLPTR);
}

// SIGNAL 8
void ConfigureHolder::horizontalFullscreenAudioAutoPlay()
{
    QMetaObject::activate(this, &staticMetaObject, 8, Q_NULLPTR);
}

// SIGNAL 9
void ConfigureHolder::verticalAudioAutoPlay()
{
    QMetaObject::activate(this, &staticMetaObject, 9, Q_NULLPTR);
}

// SIGNAL 10
void ConfigureHolder::verticalFullscreenAudioAutoPlay()
{
    QMetaObject::activate(this, &staticMetaObject, 10, Q_NULLPTR);
}

// SIGNAL 11
void ConfigureHolder::stopAllAudioPlay()
{
    QMetaObject::activate(this, &staticMetaObject, 11, Q_NULLPTR);
}

// SIGNAL 12
void ConfigureHolder::startPlayAfterCloseNormal()
{
    QMetaObject::activate(this, &staticMetaObject, 12, Q_NULLPTR);
}

// SIGNAL 13
void ConfigureHolder::startPlayAfterCloseFullScreen()
{
    QMetaObject::activate(this, &staticMetaObject, 13, Q_NULLPTR);
}

// SIGNAL 14
void ConfigureHolder::checkFullScreen()
{
    QMetaObject::activate(this, &staticMetaObject, 14, Q_NULLPTR);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
